// Official export history is an archive; continuing creates an official CLI conversation.
(() => {
  let historyData = null, loading = false, historyError = '', filter = 'all';
  const label = source => source === 'claude-web' ? '官方导出' : source === 'claude-code' ? 'Claude Code' : 'Studio';
  const guarded = fn => async (...args) => { try { await fn(...args); } catch (e) { toast(e.message, true); } };
  async function loadHistory() {
    if (loading) return; loading = true;
    try { historyData = await api('/api/history'); historyError = ''; }
    catch (e) { historyError = e.message; }
    finally { loading = false; if (currentView === 'history') renderHistory(); }
  }
  async function refreshSessions() {
    const data = await api('/api/state'); state.sessions = data.sessions; state.projects = data.projects || []; renderSessions();
    if (state.cur && !state.busy.has(state.cur.id)) await openSession(state.cur.id);
    await loadHistory();
  }
  function report(result) {
    return `新增 ${result.imported || 0} 个，更新 ${result.updated || 0} 个，重复 ${result.unchanged || 0} 个${result.skippedBusy ? `；${result.skippedBusy} 个正在运行，暂未更新` : ''}`;
  }
  function renderHistory() {
    const records = (historyData?.sessions || []).filter(s => filter === 'all' || s.historySource === filter);
    $('#viewHistory').innerHTML = `<div class="studio-page history-page"><div class="studio-page-head"><div><div class="kicker">CLAUDE STUDIO</div><h1>官方对话记录</h1><p>导入官方网页／桌面聊天导出，或刷新本机 Claude Code 会话。记录可以搜索、查看和继续。</p></div><div class="studio-head-actions"><button class="btn" data-history="sync">${ic('refresh')}刷新 Claude Code</button><button class="btn primary" data-history="import">${ic('file')}导入官方记录</button></div></div>${historyError ? `<div class="account-error">${esc(historyError)}</div>` : ''}<div class="card history-guide"><div class="card-h"><h3>${ic('info')}官方网页与桌面聊天</h3></div><p>在官方客户端进入 Settings → Privacy → Export data。收到导出邮件后下载 ZIP，直接导入这里，或选择解压后的 conversations.json。</p><p class="muted small">这里显示已导入的本地快照；继续对话会通过官方订阅建立新的 Claude Code 会话。原附件若没有包含在导出中，需要重新提供。</p><div class="studio-inline-actions"><a class="btn" href="https://claude.ai/settings/privacy" target="_blank" rel="noopener noreferrer">打开官方导出页面 ↗</a><a class="link" href="https://support.claude.com/en/articles/9450526-export-your-claude-data" target="_blank" rel="noopener noreferrer">官方导出说明 ↗</a></div></div><div class="history-toolbar"><div class="studio-filter">${[['all', '全部'], ['claude-web', '官方导出'], ['claude-code', 'Claude Code']].map(([value, text]) => `<button data-history-filter="${value}" class="${filter === value ? 'on' : ''}">${text}</button>`).join('')}</div><span class="muted small">${historyData?.counts?.official || 0} 个官方导出 · ${historyData?.counts?.cli || 0} 个本机 CLI 会话</span></div>${records.length ? `<div class="card history-records">${records.map(s => `<div class="history-record"><button class="history-record-main" data-history-open="${s.id}"><b>${esc(s.title)}</b><small>${label(s.historySource)} · ${new Date(s.updatedAt).toLocaleString('zh-CN')} · ${esc(basename(s.cwd))}</small></button>${s.historyUrl ? `<a class="link" href="${s.historyUrl}" target="_blank" rel="noopener noreferrer">官方原对话 ↗</a>` : ''}<button class="btn" data-history-open="${s.id}">查看 / 继续</button></div>`).join('')}</div>` : `<div class="studio-empty"><h3>${loading ? '读取中…' : '还没有导入记录'}</h3><p>选择官方导出文件，或点击“刷新 Claude Code”读取本机历史。</p><button class="btn" data-history="import">导入 ZIP / JSON</button></div>`}</div>`;
    if (!historyData && !loading) void loadHistory();
  }
  function importDialog() {
    const root = modal(`<form id="historyImportForm"><h3>导入官方对话记录</h3><p>支持官方导出 ZIP 或 conversations.json，最大 128 MB。重复导入会更新快照，并保留你在 Studio 中继续的消息。</p><label class="studio-field">导出文件路径<input name="path" placeholder="C:\\Users\\...\\data-export.zip" spellcheck="false"></label><input id="historyUpload" type="file" accept=".zip,.json" hidden><button type="button" class="btn" id="historyChoose">选择本机文件</button><p id="historyChosen" class="muted small">也可以直接填写文件路径。</p><div class="account-error" id="historyImportError" hidden></div><div class="foot"><button type="button" class="btn" data-close>取消</button><button type="submit" class="btn primary">导入</button></div></form>`);
    const form = root.querySelector('form'), upload = root.querySelector('#historyUpload');
    root.querySelector('#historyChoose').onclick = () => upload.click();
    upload.onchange = () => { form.elements.path.value = ''; root.querySelector('#historyChosen').textContent = upload.files[0]?.name || '未选择文件'; };
    form.onsubmit = async event => {
      event.preventDefault(); const submit = form.querySelector('[type="submit"]'), error = root.querySelector('#historyImportError'); submit.disabled = true; error.hidden = true;
      try {
        const file = upload.files[0]; let body;
        if (form.elements.path.value.trim()) body = { path: form.elements.path.value.trim() };
        else if (file) {
          if (file.size > 128 * 1024 * 1024) throw new Error('导出文件超过 128 MB，请选择较小的导出文件。');
          const dataUrl = await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = () => reject(new Error('无法读取选择的文件')); reader.readAsDataURL(file); });
          body = { filename: file.name, data: String(dataUrl).split(',')[1] };
        } else throw new Error('请选择导出文件或填写文件路径。');
        const result = await api('/api/history/import', { method: 'POST', body });
        await refreshSessions(); root.close(); showView('history'); toast(report(result));
      } catch (e) { error.textContent = e.message; error.hidden = false; }
      finally { submit.disabled = false; }
    };
  }
  VIEWS.push('history'); VIEW_NAMES.history = '官方对话记录'; NAV_ICONS.history = 'history'; RENDER.history = renderHistory;
  const navigation = document.querySelector('.rail [data-view="history"]'); navigation.innerHTML = ic('history'); navigation.onclick = () => showView('history');
  document.addEventListener('click', guarded(async event => {
    const action = event.target.closest('[data-history]')?.dataset.history;
    if (action === 'import') importDialog();
    if (action === 'sync') { const button = event.target.closest('button'); button.disabled = true; try { const result = await api('/api/history/sync-cli', { method: 'POST' }); await refreshSessions(); toast(report(result)); if (result.errors?.length) toast(result.errors.join('\n'), true); } finally { button.disabled = false; } }
    const selected = event.target.closest('[data-history-filter]'); if (selected) { filter = selected.dataset.historyFilter; renderHistory(); }
    const open = event.target.closest('[data-history-open]'); if (open) { showView('chat'); await openSession(open.dataset.historyOpen); }
  }));
  const baseRender = renderSessions;
  renderSessions = function() {
    baseRender();
    for (const item of document.querySelectorAll('#sessList .sess[data-id]')) {
      const record = state.sessions.find(s => s.id === item.dataset.id);
      if (record?.historySource && record.historySource !== 'studio') { item.title = label(record.historySource) + ' · ' + record.title; const text = item.querySelector('.t'); if (text) text.insertAdjacentHTML('beforeend', `<small class="history-source-tag">${label(record.historySource)}</small>`); }
    }
  };
  const baseReady = window.onAppReady; window.onAppReady = () => { baseReady?.(); void loadHistory(); };
  const baseEvent = window.onServerEvent; window.onServerEvent = event => { baseEvent?.(event); if (event.type === 'session' && event.session?.historySource && event.session.historySource !== 'studio') void loadHistory(); };
  const sidebarButton = document.createElement('button'); sidebarButton.className = 'history-sidebar-btn'; sidebarButton.innerHTML = ic('history') + '官方对话记录 / 导入'; sidebarButton.onclick = () => showView('history'); document.querySelector('.sidebar .search')?.before(sidebarButton);
})();
