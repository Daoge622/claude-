// ============ Claude Studio 前端 ============
const $ = s => document.querySelector(s);
const esc = MD.esc;

// ---------- 图标（手绘 SVG 线条图标） ----------
const P = {
  plus: '<path d="M12 5v14M5 12h14"/>',
  edit: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  side: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M9 4v16"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5Z"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/>',
  collapse: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M9 4v16M15 10l-2 2 2 2"/>',
  share: '<path d="M12 3v12M7 8l5-5 5 5"/><path d="M5 13v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5"/>',
  dots: '<circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  up: '<path d="M12 19V5M5 12l7-7 7 7"/>',
  down: '<path d="M12 5v14M5 12l7 7 7-7"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  chev: '<path d="m9 6 6 6-6 6"/>',
  chevd: '<path d="m6 9 6 6 6-6"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2.5"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
  retry: '<path d="M4 12a8 8 0 0 1 14-5.3L20 9M20 4v5h-5M20 12a8 8 0 0 1-14 5.3L4 15M4 20v-5h5"/>',
  pin: '<path d="M9 4h6l-1 6 4 3v2H6v-2l4-3Z"/><path d="M12 15v6"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-9 9"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z"/><path d="M14 3v5h5"/>',
  clip: '<path d="m21 11-8.5 8.5a5 5 0 0 1-7-7L14 4a3.5 3.5 0 0 1 5 5l-8.5 8.5a2 2 0 0 1-3-3L15 7"/>',
  spark: '<path d="M12 3c.8 5 2.4 6.6 7.5 7.5v.9C14.4 12.3 12.8 14 12 19h-.1c-.8-5-2.4-6.7-7.4-7.6v-.9C9.6 9.6 11.2 8 12 3Z"/>',
  terminal: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="m7 9 3 3-3 3M13 15h4"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  pen: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16v4Z"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
  list: '<path d="M9 6h11M9 12h11M9 18h11"/><path d="m3 6 1.5 1.5L7 5M3 12l1.5 1.5L7 11M3 18l1.5 1.5L7 17"/>',
  bot: '<rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 4v4M9 13v1M15 13v1"/>',
  shield: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6Z"/>',
  shieldOk: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6Z"/><path d="m9 12 2 2 4-4"/>',
  bolt: '<path d="M13 3 5 14h6l-1 7 8-11h-6Z"/>',
  unlock: '<rect x="4" y="11" width="16" height="10" rx="2.5"/><path d="M8 11V7a4 4 0 0 1 7.5-2"/>',
  map: '<path d="m9 4-6 2v14l6-2 6 2 6-2V4l-6 2Z"/><path d="M9 4v14M15 6v14"/>',
  warn: '<path d="M12 3 2 20h20Z"/><path d="M12 10v4M12 17v.5"/>',
  brain: '<path d="M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 6 1V5a2 2 0 0 0-3-1ZM15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-6 1"/>',
  question: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 .5c0 1.5-2.5 2-2.5 3.5M12 17v.5"/>',
  download: '<path d="M12 4v12M7 11l5 5 5-5M5 20h14"/>',
  code: '<path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/>',
  bug: '<rect x="7" y="7" width="10" height="13" rx="5"/><path d="M12 7V4M9 4l1 3M15 4l-1 3M3 12h4M17 12h4M4 18l3-2M20 18l-3-2M4 7l3 2M20 7l-3 2"/>',
  palette: '<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 2-2s-1-1.5-1-2.5 1-1.5 2-1.5h2a4 4 0 0 0 4-4c0-4.5-4-8-9-8Z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7.5" r="1"/>',
  rocket: '<path d="M5 15c-1 1-2 5-2 5s4-1 5-2M9 15l-3-3c1-4 5-9 12-9 0 7-5 11-9 12Z"/><circle cx="14" cy="9" r="1.5"/>',
};
function ic(name, cls = 'i') { return `<svg class="${cls}" viewBox="0 0 24 24">${P[name] || ''}</svg>`; }
const ICONS = { copy: ic('copy') };

// ---------- 配置 ----------
const MODELS = [
  { id: '', name: '默认模型', desc: '沿用 Claude Code 当前配置' },
  { id: 'opus', name: 'Claude Opus', desc: '复杂推理与长任务，可用性以官方订阅为准' },
  { id: 'sonnet', name: 'Claude Sonnet', desc: '编程与日常任务，使用官方当前版本' },
  { id: 'haiku', name: 'Claude Haiku', desc: '轻量任务，可用性以官方订阅为准' },
];
const EFFORTS = [
  { id: 'low', name: '低', desc: '快速回答，少量思考', lv: 1 },
  { id: 'medium', name: '中', desc: '平衡速度与质量', lv: 2 },
  { id: 'high', name: '高', desc: '深入思考（推荐）', lv: 3 },
  { id: 'xhigh', name: '超高', desc: '复杂问题，更长思考', lv: 4 },
  { id: 'max', name: '极限', desc: '不计成本的最大推理', lv: 5 },
];
const PERMS = [
  { id: 'default', name: '每次询问', desc: '修改文件、执行命令前都征求同意', icon: 'shieldOk', cls: '' },
  { id: 'acceptEdits', name: '自动编辑', desc: '自动允许编辑文件，命令仍需确认', icon: 'pen', cls: 'edits' },
  { id: 'plan', name: '计划模式', desc: '只读调研并给出方案，不做修改', icon: 'map', cls: 'plan' },
  { id: 'auto', name: '自动模式', desc: '由安全分类器自动判断是否放行', icon: 'bolt', cls: 'edits' },
  { id: 'bypassPermissions', name: '完全访问', desc: '跳过所有确认，可执行任何操作', icon: 'unlock', cls: 'warn' },
];
const SUGGESTS = [
  { icon: 'code', color: '#e6b86a', t: '解释这个项目', d: '梳理当前目录的代码结构与架构', p: '帮我梳理一下当前目录这个项目的结构、技术栈和核心模块。' },
  { icon: 'bug', color: '#e0655f', t: '排查一个 Bug', d: '描述现象，定位根因并修复', p: '我遇到一个 bug：' },
  { icon: 'palette', color: '#e0824f', t: '设计一个页面', d: '做一个美观的现代网页', p: '帮我做一个美观现代的单页网站，主题是：' },
  { icon: 'rocket', color: '#d9c4a8', t: '写个自动化脚本', d: '批量处理文件、定时任务等', p: '帮我写一个脚本，用来' },
];

const defaults = { model: '', effort: 'high', permissionMode: 'default', theme: 'dark', particles: true, density: 1, sendKey: 'enter', fontSize: 15, lastCwd: '', view: 'home', stand: true, closeToTray: false, hotkey: 'Ctrl+Alt+Space', shell: '' };
const cfg = Object.assign({}, defaults, JSON.parse(localStorage.getItem('cs.cfg') || '{}'));
const saveCfg = () => localStorage.setItem('cs.cfg', JSON.stringify(cfg));
if (cfg.model === 'fable') { cfg.model = 'sonnet'; saveCfg(); }

const state = { sessions: [], projects: [], cur: null, messages: [], busy: new Set(), pending: [], home: '', filter: '' };

// ---------- 工具函数 ----------
async function api(path, opts = {}) {
  const res = await fetch(path, { method: opts.method || 'GET', headers: { 'Content-Type': 'application/json' }, body: opts.body ? JSON.stringify(opts.body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}
function toast(msg, err) {
  const el = document.createElement('div');
  el.className = 'toast' + (err ? ' err' : '');
  el.innerHTML = (err ? ic('warn') : ic('check')) + esc(msg);
  $('#toasts').append(el);
  setTimeout(() => { el.style.transition = '.3s'; el.style.opacity = 0; setTimeout(() => el.remove(), 300); }, 2600);
}
function fmtSize(n) { return n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB'; }
function fmtDur(ms) { if (ms == null) return ''; const s = ms / 1000; return s < 60 ? s.toFixed(1) + ' 秒' : Math.floor(s / 60) + ' 分 ' + Math.round(s % 60) + ' 秒'; }
function fmtTok(n) { return n >= 1000 ? (n / 1000).toFixed(1) + 'k' : String(n || 0); }
function ext(name) { const m = /\.([^.]+)$/.exec(name || ''); return m ? m[1].slice(0, 4).toUpperCase() : 'FILE'; }
async function copyText(t) { try { await navigator.clipboard.writeText(t); toast('已复制'); } catch { toast('复制失败', true); } }
function basename(p) { return (p || '').split(/[\\/]/).filter(Boolean).pop() || p; }

// ---------- 主题 / 设置 ----------
function applyCfg() {
  document.documentElement.dataset.theme = cfg.theme;
  document.documentElement.style.setProperty('--fs', cfg.fontSize + 'px');
  Particles.setEnabled(cfg.particles);
  Particles.setDensity(cfg.density);
  Particles.setLight(cfg.theme === 'light');
  $('#railTheme').innerHTML = ic(cfg.theme === 'dark' ? 'sun' : 'moon');
  document.body.classList.toggle('no-stand', cfg.stand === false);
  $('#hint').textContent = `Claude 可能会出错，请核查重要信息 · ${cfg.sendKey === 'enter' ? 'Enter 发送，Shift+Enter 换行' : 'Ctrl+Enter 发送'}`;
  renderPills();
}

// ---------- 静态图标注入 ----------
function mountIcons() {
  $('#railNew').innerHTML = ic('edit');
  $('#footSettings').innerHTML = ic('gear');
  $('#collapseBtn').innerHTML = ic('collapse');
  $('#expandBtn').innerHTML = ic('side');
  $('#newIc').outerHTML = ic('edit');
  $('#searchIc').outerHTML = ic('search');
  $('#exportBtn').innerHTML = ic('share') + '导出';
  $('#moreBtn').innerHTML = ic('dots');
  $('#plusBtn').innerHTML = ic('plus');
  $('#micBtn').innerHTML = ic('mic');
  $('#jumpBtn').innerHTML = ic('down');
  $('#stopBtn').innerHTML = ic('stop') + '<span>停止</span>';
  $('#dropIc').outerHTML = ic('clip');
}

// ---------- 弹出菜单 ----------
let openMenu = null;
function closeMenu() { if (openMenu) { openMenu.el.remove(); openMenu.anchor?.classList.remove('open'); openMenu = null; } }
function showMenu(anchor, html, onPick, place = 'up') {
  if (openMenu?.anchor === anchor) { closeMenu(); return; }
  closeMenu();
  const el = document.createElement('div');
  el.className = 'menu';
  el.innerHTML = html;
  document.body.append(el);
  const r = anchor.getBoundingClientRect(), mr = el.getBoundingClientRect();
  let left = Math.min(r.left, innerWidth - mr.width - 12);
  let top = place === 'up' ? r.top - mr.height - 8 : r.bottom + 8;
  if (top < 8) top = r.bottom + 8;
  el.style.left = Math.max(8, left) + 'px';
  el.style.top = top + 'px';
  anchor.classList.add('open');
  el.addEventListener('click', e => { const it = e.target.closest('[data-v]'); if (it) { closeMenu(); onPick(it.dataset.v); } });
  openMenu = { el, anchor };
}
document.addEventListener('mousedown', e => { if (openMenu && !openMenu.el.contains(e.target) && !openMenu.anchor.contains(e.target)) closeMenu(); });

function renderPills() {
  const m = MODELS.find(x => x.id === cfg.model) || MODELS[0];
  $('#modelPill').innerHTML = `${ic('spark')}${esc(m.id ? m.name.replace('Claude ', '') : '默认')}${ic('chevd', 'i cv')}`;
  const e = EFFORTS.find(x => x.id === cfg.effort) || EFFORTS[2];
  $('#effortPill').innerHTML = `<span class="effort-bars">${[1, 2, 3, 4, 5].map(i => `<i class="${i <= e.lv ? 'on' : ''}"></i>`).join('')}</span>${e.name}${ic('chevd', 'i cv')}`;
  const p = PERMS.find(x => x.id === cfg.permissionMode) || PERMS[0];
  const pill = $('#permPill');
  pill.className = 'pill ' + p.cls;
  pill.innerHTML = `${ic(p.icon)}${p.name}${ic('chevd', 'i cv')}`;
  $('#composer').classList.toggle('bypass', cfg.permissionMode === 'bypassPermissions');
}

$('#modelPill').onclick = e => showMenu(e.currentTarget,
  `<div class="mh">选择模型</div>` + MODELS.map(m => `<button class="mi ${m.id === cfg.model ? 'sel' : ''}" data-v="${m.id}"><span class="m-ic" style="background:var(--hover)">${ic(m.id ? 'spark' : 'gear')}</span><span class="tx">${m.name} ${m.badge ? `<span class="m-badge">${m.badge}</span>` : ''}<small>${m.desc}</small></span>${ic('check', 'i ck')}</button>`).join('') +
  `<div class="sep"></div><div class="mh" style="padding-bottom:8px">切换模型会在下一条消息生效，并保留上下文</div>`,
  v => { cfg.model = v; saveCfg(); renderPills(); toast('已切换到 ' + (MODELS.find(m => m.id === v)?.name)); });

$('#effortPill').onclick = e => showMenu(e.currentTarget,
  `<div class="mh">思考强度</div>` + EFFORTS.map(x => `<button class="mi ${x.id === cfg.effort ? 'sel' : ''}" data-v="${x.id}"><span class="effort-bars" style="width:30px;justify-content:center">${[1, 2, 3, 4, 5].map(i => `<i class="${i <= x.lv ? 'on' : ''}"></i>`).join('')}</span><span class="tx">${x.name}<small>${x.desc}</small></span>${ic('check', 'i ck')}</button>`).join(''),
  v => { cfg.effort = v; saveCfg(); renderPills(); });

$('#permPill').onclick = e => showMenu(e.currentTarget,
  `<div class="mh">权限模式</div>` + PERMS.map(x => `<button class="mi ${x.id === cfg.permissionMode ? 'sel' : ''} ${x.id === 'bypassPermissions' ? 'danger' : ''}" data-v="${x.id}"><span class="m-ic" style="background:var(--hover)">${ic(x.icon)}</span><span class="tx">${x.name}<small>${x.desc}</small></span>${ic('check', 'i ck')}</button>`).join(''),
  v => { if (v === 'bypassPermissions') confirmBypass(); else { cfg.permissionMode = v; saveCfg(); renderPills(); } });

function confirmBypass() {
  modal(`<h3><span class="danger-icon">${ic('unlock')}</span>开启完全访问权限？</h3>
    <p>开启后，Claude 执行<b>任何操作都不再征求你的同意</b>，包括：</p>
    <ul class="risk-list"><li>创建、修改、删除任意文件</li><li>执行任意终端命令、安装软件</li><li>访问网络、推送代码</li></ul>
    <p style="margin-top:12px">建议只在你信任的项目目录、并清楚任务内容时开启。可随时切回"每次询问"。</p>
    <label class="confirm-check"><input type="checkbox" id="bpChk"> 我了解风险，确认开启</label>
    <div class="foot"><button class="btn" data-close>取消</button><button class="btn danger-solid" id="bpOk" disabled>开启完全访问</button></div>`, root => {
    root.querySelector('#bpChk').onchange = e => { root.querySelector('#bpOk').disabled = !e.target.checked; };
    root.querySelector('#bpOk').onclick = () => { cfg.permissionMode = 'bypassPermissions'; saveCfg(); renderPills(); root.close(); toast('已开启完全访问'); };
  });
}

// ---------- 弹窗 ----------
function modal(html, setup) {
  const bg = document.createElement('div');
  bg.className = 'modal-bg';
  bg.innerHTML = `<div class="modal">${html}</div>`;
  bg.close = () => bg.remove();
  bg.addEventListener('mousedown', e => { if (e.target === bg) bg.close(); });
  bg.addEventListener('click', e => { if (e.target.closest('[data-close]')) bg.close(); });
  document.body.append(bg);
  setup?.(bg);
  return bg;
}

function openSettings() { showView('settings'); }
function openSettingsModal() {
  const seg = (key, opts) => `<div class="seg" data-key="${key}">${opts.map(([v, t]) => `<button data-sv="${v}" class="${String(cfg[key]) === String(v) ? 'on' : ''}">${t}</button>`).join('')}</div>`;
  modal(`<h3>${ic('gear')}设置</h3>
    <div class="set-row"><div>外观主题</div>${seg('theme', [['dark', '深色'], ['light', '浅色']])}</div>
    <div class="set-row"><div>粒子特效<small>背景星尘、发送爆发、思考能量流</small></div><button class="switch ${cfg.particles ? 'on' : ''}" data-sw="particles"></button></div>
    <div class="set-row"><div>粒子密度</div>${seg('density', [[0.5, '稀疏'], [1, '标准'], [2, '密集']])}</div>
    <div class="set-row"><div>字体大小</div>${seg('fontSize', [[14, '小'], [15, '中'], [17, '大']])}</div>
    <div class="set-row"><div>发送快捷键</div>${seg('sendKey', [['enter', 'Enter'], ['ctrl', 'Ctrl+Enter']])}</div>
    <div class="set-row" style="border:0"><div>快捷键<small>Ctrl+K 搜索 · Ctrl+Shift+O 新对话 · Ctrl+B 侧边栏 · Esc 停止生成</small></div></div>
    <div class="foot"><button class="btn primary" data-close>完成</button></div>`, root => {
    root.querySelectorAll('.seg').forEach(s => s.onclick = e => {
      const b = e.target.closest('[data-sv]'); if (!b) return;
      const key = s.dataset.key, raw = b.dataset.sv;
      cfg[key] = typeof defaults[key] === 'number' ? Number(raw) : raw;
      s.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b));
      saveCfg(); applyCfg();
    });
    root.querySelectorAll('[data-sw]').forEach(sw => sw.onclick = () => { cfg[sw.dataset.sw] = !cfg[sw.dataset.sw]; sw.classList.toggle('on'); saveCfg(); applyCfg(); });
  });
}

// ---------- 目录选择 ----------
// 先尝试系统原生对话框，失败 / 不支持时回退到内置弹窗
async function pickDir(initial) {
  try {
    const r = await api('/api/pick-dir', { method: 'POST', body: { initial } });
    if (r.path) return r.path;
    if (r.cancelled) return null;
  } catch {}
  return pickDirModal(initial);
}
function pickDirModal(initial) {
  return new Promise(resolve => {
    let cur = initial || state.home;
    const root = modal(`<h3>${ic('folder')}选择工作目录</h3><p style="margin:4px 0 12px">Claude 会在这个目录里读写文件、执行命令。</p>
      <div class="dir-path">${ic('folder')}<input id="dirIn"></div><div class="dir-list" id="dirList"></div>
      <div class="foot"><button class="btn" data-close>取消</button><button class="btn primary" id="dirOk">使用此目录</button></div>`);
    const list = root.querySelector('#dirList'), input = root.querySelector('#dirIn');
    async function load(p) {
      try {
        const r = await api('/api/fs?path=' + encodeURIComponent(p));
        cur = r.path; input.value = r.path;
        list.innerHTML = (r.parent !== null ? `<div class="dir-item" data-p="${esc(r.parent)}">${ic('up')}上一级</div>` : '') +
          (r.dirs.length ? r.dirs.map(d => `<div class="dir-item" data-p="${esc(d.path)}">${ic('folder')}${esc(d.name)}</div>`).join('') : '<div class="dir-item" style="color:var(--text-3)">（没有子目录）</div>');
      } catch (e) { toast(e.message, true); }
    }
    list.onclick = e => { const it = e.target.closest('[data-p]'); if (it) load(it.dataset.p); };
    input.onkeydown = e => { if (e.key === 'Enter') load(input.value); };
    root.querySelector('#dirOk').onclick = () => { root.close(); resolve(cur || input.value); };
    const origClose = root.close; root.close = () => { origClose(); resolve(null); };
    load(cur);
  });
}

// ---------- 会话列表 ----------
function renderSessions() {
  const q = state.filter.trim().toLowerCase();
  const list = state.sessions.filter(s => !q || s.title.toLowerCase().includes(q));
  const pinned = list.filter(s => s.pinned), rest = list.filter(s => !s.pinned);
  const now = Date.now(), day = 86400000;
  const groups = [['今天', x => now - x.updatedAt < day], ['最近 7 天', x => now - x.updatedAt < 7 * day], ['更早', () => true]];
  let html = '';
  const item = s => `<div class="sess ${s.id === state.cur?.id ? 'on' : ''}" data-id="${s.id}">
      <span class="t">${esc(s.title)}</span>${state.busy.has(s.id) ? '<span class="dot"></span>' : ''}
      <span class="acts"><button data-act="pin" title="${s.pinned ? '取消置顶' : '置顶'}">${ic('pin')}</button><button data-act="rename" title="重命名">${ic('pen')}</button><button data-act="del" title="删除">${ic('trash')}</button></span></div>`;
  if (pinned.length) html += `<div class="group-title">置顶</div>` + pinned.map(item).join('');
  const used = new Set();
  for (const [name, fn] of groups) {
    const g = rest.filter(s => !used.has(s.id) && fn(s));
    g.forEach(s => used.add(s.id));
    if (g.length) html += `<div class="group-title">${name}</div>` + g.map(item).join('');
  }
  if (!list.length) html = q ? `<div class="group-title" style="text-align:center;padding-top:40px">没有匹配的对话</div>`
    : `<div class="empty-mini"><img src="/assets/claude/3.png" alt=""><div>还没有对话……<br>快点开始第一段吧。</div></div>`;
  $('#sessList').innerHTML = html;
}

$('#sessList').addEventListener('click', async e => {
  const el = e.target.closest('.sess'); if (!el) return;
  const id = el.dataset.id, s = state.sessions.find(x => x.id === id);
  const act = e.target.closest('[data-act]')?.dataset.act;
  if (act === 'pin') { await api('/api/sessions/' + id, { method: 'PATCH', body: { pinned: !s.pinned } }); s.pinned = !s.pinned; renderSessions(); return; }
  if (act === 'rename') { startRename(el, s); return; }
  if (act === 'del') {
    modal(`<h3>删除对话？</h3><p>「${esc(s.title)}」将被永久删除。</p><div class="foot"><button class="btn" data-close>取消</button><button class="btn danger-solid" id="delOk">删除</button></div>`, root => {
      root.querySelector('#delOk').onclick = async () => {
        root.close();
        await api('/api/sessions/' + id, { method: 'DELETE' });
        state.sessions = state.sessions.filter(x => x.id !== id);
        if (state.cur?.id === id) newChat(); else renderSessions();
      };
    });
    return;
  }
  if (e.target.tagName !== 'INPUT') openSession(id);
});

function startRename(el, s) {
  const t = el.querySelector('.t');
  const inp = document.createElement('input');
  inp.value = s.title;
  t.replaceWith(inp); inp.focus(); inp.select();
  const done = async ok => {
    if (ok && inp.value.trim() && inp.value !== s.title) {
      s.title = inp.value.trim();
      await api('/api/sessions/' + s.id, { method: 'PATCH', body: { title: s.title } });
      if (state.cur?.id === s.id) $('#title').textContent = s.title;
    }
    renderSessions();
  };
  inp.onkeydown = e => { if (e.key === 'Enter') done(true); if (e.key === 'Escape') done(false); };
  inp.onblur = () => done(true);
}

$('#searchInput').oninput = e => { state.filter = e.target.value; renderSessions(); };

async function openSession(id) {
  const r = await api('/api/sessions/' + id);
  state.cur = r.session;
  state.messages = r.messages;
  renderAll();
  scrollBottom(true);
}

function newChat() {
  state.cur = null;
  state.messages = [];
  renderAll();
  $('#input').focus();
}

async function ensureSession() {
  if (state.cur) return state.cur;
  const r = await api('/api/sessions', { method: 'POST', body: { cwd: cfg.lastCwd || state.home, contextDirs: cfg.contextDirs || [] } });
  state.cur = r.session;
  state.sessions.unshift(r.session);
  return state.cur;
}

// ---------- 顶栏 ----------
function renderTop() {
  window.renderChatExtras?.();
  $('#title').textContent = state.cur?.title || '新对话';
  const cwd = state.cur?.cwd || cfg.lastCwd || state.home;
  $('#cwdChip').innerHTML = `${ic('folder')}<span>${esc(cwd)}</span>`;
  $('#cwdChip').title = cwd + '（点击更换）';
}
async function changeCwd() {
  const cur = state.cur?.cwd || cfg.lastCwd || state.home;
  const dir = await pickDir(cur);
  if (!dir) return;
  cfg.lastCwd = dir; saveCfg();
  if (state.cur) {
    await api('/api/sessions/' + state.cur.id, { method: 'PATCH', body: { cwd: dir } });
    state.cur.cwd = dir;
  }
  renderTop();
  toast('工作目录：' + basename(dir));
}
$('#cwdChip').onclick = changeCwd;
$('#title').ondblclick = () => {
  if (!state.cur) return;
  const el = document.querySelector(`.sess[data-id="${state.cur.id}"]`);
  if (el) startRename(el, state.sessions.find(s => s.id === state.cur.id));
};

// ---------- 消息渲染 ----------
const TOOL_META = {
  Bash: ['terminal', '运行命令', i => i.command], PowerShell: ['terminal', '运行命令', i => i.command],
  Read: ['eye', '读取', i => i.file_path], Write: ['file', '写入', i => i.file_path], Edit: ['pen', '编辑', i => i.file_path],
  MultiEdit: ['pen', '编辑', i => i.file_path], NotebookEdit: ['pen', '编辑笔记本', i => i.notebook_path],
  Glob: ['search', '查找文件', i => i.pattern], Grep: ['search', '搜索内容', i => `${i.pattern}${i.path ? '  ' + i.path : ''}`],
  WebFetch: ['globe', '抓取网页', i => i.url], WebSearch: ['globe', '联网搜索', i => i.query],
  Task: ['bot', '子代理', i => i.description], Agent: ['bot', '子代理', i => i.description],
  TodoWrite: ['list', '任务清单', i => `${(i.todos || []).filter(t => t.status === 'completed').length}/${(i.todos || []).length} 已完成`],
  Skill: ['spark', '技能', i => i.skill], AskUserQuestion: ['question', '提问', i => i.questions?.[0]?.question],
  ExitPlanMode: ['map', '提交计划', () => ''], EnterPlanMode: ['map', '进入计划模式', () => ''],
};
function toolMeta(name) { const m = TOOL_META[name]; return m ? { icon: m[0], label: m[1], sum: m[2] } : { icon: 'bolt', label: name, sum: i => JSON.stringify(i || {}).slice(0, 120) }; }

function renderToolBody(b) {
  const inp = b.input || {};
  let html = '';
  if ((b.name === 'Edit') && inp.old_string != null) {
    html += `<div class="lbl">变更</div><pre>${inp.old_string.split('\n').map(l => `<span class="diff-del">- ${esc(l)}</span>`).join('')}${(inp.new_string || '').split('\n').map(l => `<span class="diff-add">+ ${esc(l)}</span>`).join('')}</pre>`;
  } else if (b.name === 'Write' && inp.content != null) {
    html += `<div class="lbl">内容</div><pre>${esc(inp.content.slice(0, 8000))}</pre>`;
  } else if (b.name === 'TodoWrite') {
    html += `<pre>${(inp.todos || []).map(t => `${t.status === 'completed' ? '✅' : t.status === 'in_progress' ? '⏳' : '⬜'} ${esc(t.content)}`).join('\n')}</pre>`;
  } else if (b.input) {
    html += `<div class="lbl">输入</div><pre>${esc(JSON.stringify(inp, null, 2))}</pre>`;
  }
  if (b.result != null && b.name !== 'TodoWrite') html += `<div class="lbl">${b.status === 'error' ? '错误' : '输出'}</div><pre>${esc(b.result) || '<span style="color:var(--text-3)">（无输出）</span>'}</pre>`;
  return html;
}

function renderTool(b, bi) {
  const meta = toolMeta(b.name);
  const sum = b.input ? (meta.sum(b.input) || '') : '';
  const st = b.status === 'running' ? '<span class="spin"></span>' : b.status === 'error' ? ic('x') : ic('check');
  const dur = b.startedAt ? (b.endedAt ? fmtDur(b.endedAt - b.startedAt) : b.status === 'running' ? `<span data-live-start="${b.startedAt}">${fmtDur(Date.now() - b.startedAt)}</span>` : '') : '';
  return `<div class="tool ${b.status} ${b._open ? 'open' : ''}" data-bi="${bi}">
    <div class="tool-head" data-toggle="tool"><span class="tool-ic">${ic(meta.icon)}</span><span class="tool-name">${esc(meta.label)}</span><span class="tool-sum">${esc(String(sum).split('\n')[0])}</span>${dur ? `<span class="tool-dur">${dur}</span>` : ''}<span class="tool-st ${b.status === 'error' ? 'err' : b.status === 'done' ? 'ok' : ''}">${st}</span></div>
    <div class="tool-body">${b._open ? renderToolBody(b) : ''}</div></div>`;
}

function renderThink(b, bi, live) {
  const running = live && b.durationMs == null;
  const label = running ? '正在思考…' : `已思考 ${fmtDur(b.durationMs)}`;
  const body = b.text ? esc(b.text) : `<span class="muted">${running ? '模型正在进行深度推理…' : '本次思考内容已由服务端加密，仅显示耗时与 token 统计。'}</span>`;
  return `<div class="think ${running ? 'running' : ''} ${b._open ? 'open' : ''}" data-bi="${bi}">
    <div class="think-head" data-toggle="think">${ic('chev', 'i chev')}${ic('brain', 'i spark')}<span class="label">${label}</span><span class="meta" data-live-start="${running ? b.startedAt : ''}">${running ? fmtDur(Date.now() - b.startedAt) : ''}</span></div>
    <div class="think-body">${body}</div></div>`;
}

function renderPermission(perm) {
  if (!perm) return '';
  const inp = perm.input || {};
  if (perm.tool === 'AskUserQuestion' && Array.isArray(inp.questions)) {
    return `<div class="perm" data-req="${perm.requestId}"><h4>${ic('question')}Claude 想问你</h4>` + inp.questions.map((q, qi) =>
      `<div style="margin-bottom:10px"><div style="margin-bottom:8px;font-weight:500">${esc(q.question)}</div><div class="q-opts" data-qi="${qi}" data-multi="${q.multiSelect ? 1 : 0}">${(q.options || []).map(o => `<button class="q-opt" data-label="${esc(o.label)}">${esc(o.label)}<small>${esc(o.description || '')}</small></button>`).join('')}</div></div>`).join('') +
      `<div class="row"><button class="btn primary" data-perm="answer">${ic('check')}提交回答</button><button class="btn danger" data-perm="deny">跳过</button></div></div>`;
  }
  if (perm.tool === 'ExitPlanMode') {
    return `<div class="perm" data-req="${perm.requestId}"><h4>${ic('map')}Claude 已制定计划，是否开始执行？</h4><div class="md" style="margin-bottom:12px;max-height:360px;overflow:auto">${MD.render(inp.plan || '')}</div>
      <div class="row"><button class="btn primary" data-perm="allow">${ic('check')}批准并执行</button><button class="btn danger" data-perm="deny">继续规划</button></div></div>`;
  }
  const meta = toolMeta(perm.tool);
  const detail = inp.command || inp.file_path || inp.url || inp.pattern || JSON.stringify(inp, null, 2);
  return `<div class="perm" data-req="${perm.requestId}"><h4>${ic('shield')}Claude 请求「${esc(meta.label)}」权限</h4>
    ${perm.description && perm.description !== detail ? `<div style="font-size:13px;color:var(--text-2);margin-bottom:8px">${esc(perm.description)}</div>` : ''}
    <pre>${esc(String(detail))}</pre>
    <div class="row"><button class="btn primary" data-perm="allow">${ic('check')}允许</button>${perm.suggestions ? `<button class="btn" data-perm="always">本会话始终允许</button>` : ''}<button class="btn danger" data-perm="deny">${ic('x')}拒绝</button></div></div>`;
}

// 思维链：把"推理 / 过程说明 / 工具调用"串成一条中文时间线，最终回答单独显示
function renderChain(m, mi, blocks, live) {
  const steps = blocks.filter(({ b }) => b.type !== 'text' || b.text.trim());
  if (!steps.length) return '';
  const nTools = steps.filter(({ b }) => b.type === 'tool').length;
  const thinkMs = steps.filter(({ b }) => b.type === 'thinking').reduce((s, { b }) => s + (b.durationMs ?? (Date.now() - b.startedAt)), 0);
  const open = m._chainOpen ?? live;
  const lastStep = steps[steps.length - 1].b;
  let now = '';
  if (live) {
    if (lastStep.type === 'thinking' && lastStep.durationMs == null) now = '正在深度推理';
    else if (lastStep.type === 'tool' && lastStep.status === 'running') now = '正在' + toolMeta(lastStep.name).label;
    else now = '正在思考';
  }
  const label = live ? `${now}…` : `思考过程 · ${steps.length} 步`;
  const meta = [nTools ? `${nTools} 次工具调用` : '', thinkMs ? `推理 ${fmtDur(thinkMs)}` : ''].filter(Boolean).join(' · ');
  const items = steps.map(({ b, bi }, k) => {
    const isLast = k === steps.length - 1;
    let body;
    if (b.type === 'thinking') {
      const running = live && b.durationMs == null;
      body = `<div class="st-t">${ic('brain')}<b>深度推理</b><span class="st-m" ${running ? `data-live-start="${b.startedAt}"` : ''}>${running ? fmtDur(Date.now() - b.startedAt) : fmtDur(b.durationMs)}</span></div>` +
        (b.text ? `<div class="st-think">${esc(b.text)}</div>` : `<div class="st-note">${running ? '正在分析问题、规划下一步……' : '已完成推理（该接口不返回推理原文，仅显示耗时）'}</div>`);
    } else if (b.type === 'text') {
      body = `<div class="st-t">${ic('spark')}<b>思路</b></div><div class="md st-say">${MD.render(b.text)}</div>`;
    } else if (b.type === 'interject') {
      body = `<div class="st-t">${ic('spark')}<b>插话</b></div><div class="st-say">${esc(b.text)}</div>`;
    } else {
      body = renderTool(b, bi);
    }
    const running = live && isLast && b.type !== 'interject' && (b.type !== 'tool' || b.status === 'running');
    return `<div class="st ${running ? 'now' : ''} st-${b.type}"><span class="st-dot"></span>${body}</div>`;
  }).join('');
  return `<div class="chain ${live ? 'running' : ''} ${open ? 'open' : ''}">
    <div class="think-head" data-toggle="chain">${ic('chev', 'i chev')}${ic('brain', 'i spark')}<span class="label">${label}</span><span class="meta">${meta}</span></div>
    <div class="chain-body">${items}</div></div>`;
}

function renderAssistant(m, mi) {
  const live = !m.done;
  let inner = '';
  const all = m.blocks.map((b, bi) => ({ b, bi }));
  // 最终回答 = 最后一个工具调用之后的文本；进行中时，最后一段文本也先作为回答流式显示
  let lastTool = -1;
  all.forEach(({ b }, k) => { if (b.type === 'tool' || b.type === 'interject') lastTool = k; });
  const answer = all.slice(lastTool + 1).filter(({ b }) => b.type === 'text');
  const chainBlocks = all.filter(x => !answer.includes(x));
  inner += renderChain(m, mi, chainBlocks, live && !answer.some(({ b }) => b.text));
  for (const { b } of answer) if (b.text) inner += `<div class="md">${MD.render(b.text)}</div>`;
  if (live && m.pendingPermission) inner += renderPermission(m.pendingPermission);
  const last = m.blocks[m.blocks.length - 1];
  if (live && !m.pendingPermission && (!last || last.type === 'tool' && last.status !== 'running' || last.type === 'thinking' && last.durationMs != null)) inner += '<div class="waiting"><i></i><i></i><i></i></div>';
  else if (live && last?.type === 'text') inner = inner.replace(/(<\/(p|li|code|td|h\d)>)(?![\s\S]*<\/(p|li|code|td|h\d)>)/, '<span class="cursor"></span>$1');
  if (m.error) inner += `<div class="a-err">${esc(m.error)}${m.done && mi === state.messages.length - 1 ? `<button class="btn cont-btn" data-act="continue">${ic('retry')}继续</button>` : ''}</div>`;
  const modelName = (m.model || '').replace(/^claude-/, '').replace(/-/g, ' ');
  const toolsN = m.blocks.filter(b => b.type === 'tool').length;
  const out = m.usage?.output_tokens;
  const foot = m.done ? `<div class="a-foot">
      <button class="mini" data-act="copy" title="复制">${ic('copy')}</button>
      <button class="mini" data-act="retry" title="重新生成">${ic('retry')}</button>
      <span class="stat">${[fmtDur(m.durationMs), toolsN ? toolsN + ' 次工具调用' : '', out ? fmtTok(out) + ' tokens' : '', m.thinkingTokens ? '思考 ' + fmtTok(m.thinkingTokens) : '', m.cost ? 'API 估算价值 $' + m.cost.toFixed(4) : ''].filter(Boolean).join(' · ')}</span></div>` : '';
  return `<div class="msg assistant ${live ? 'live' : ''}" data-mi="${mi}"><img class="av" src="/assets/face.webp"><div class="a-body">
    <div class="a-meta"><span class="name">Claude</span>${modelName ? `<span>${esc(modelName)}</span>` : ''}${m.effort ? `<span>· ${EFFORTS.find(e => e.id === m.effort)?.name || m.effort}强度</span>` : ''}</div>
    ${inner}${foot}</div></div>`;
}

function renderUser(m, mi) {
  const atts = (m.attachments || []).map(a => a.isImage
    ? `<img class="att-img" src="${a.url}" data-zoom>`
    : `<div class="att-file"><span class="fi">${ext(a.name)}</span><div style="min-width:0"><div class="nm">${esc(a.name)}</div><small>${fmtSize(a.size)}</small></div></div>`).join('');
  return `<div class="msg user" data-mi="${mi}">${atts ? `<div class="atts">${atts}</div>` : ''}${m.text ? `<div class="bubble">${esc(m.text)}</div>` : ''}
    <div class="user-acts"><button class="mini" data-act="copy-user" title="复制">${ic('copy')}</button><button class="mini" data-act="edit-user" title="编辑后重发">${ic('pen')}</button></div></div>`;
}

function renderWelcome() {
  const h = new Date().getHours();
  const greet = h < 5 ? '夜深了' : h < 11 ? '早上好' : h < 14 ? '中午好' : h < 19 ? '下午好' : '晚上好';
  return `<div class="welcome"><img class="welcome-chibi" id="orb" src="/assets/claude/1.png" alt="">
    <h1>${greet}，今天想<span class="g">构建什么</span>？</h1>
    <p>读代码、跑命令、看图片和文件……这些我都行。说吧，要做什么？</p>
    <div class="suggests">${SUGGESTS.map((s, i) => `<button class="suggest" data-sg="${i}"><span class="ic" style="background:${s.color}22;color:${s.color}">${ic(s.icon)}</span><span><b>${s.t}</b><small>${s.d}</small></span></button>`).join('')}</div></div>`;
}

function renderThread() {
  const th = $('#thread');
  if (!state.messages.length) { th.innerHTML = renderWelcome(); return; }
  th.innerHTML = state.messages.map((m, i) => m.role === 'user' ? renderUser(m, i) : renderAssistant(m, i)).join('');
}

let rafPending = false;
function renderLive() {
  if (rafPending) return;
  rafPending = true;
  requestAnimationFrame(() => {
    rafPending = false;
    const mi = state.messages.length - 1, m = state.messages[mi];
    if (!m || m.role !== 'assistant') return;
    const nearBottom = isNearBottom();
    const el = document.querySelector(`.msg[data-mi="${mi}"]`);
    const html = renderAssistant(m, mi);
    if (el) {
      const tmp = document.createElement('div'); tmp.innerHTML = html;
      const fresh = tmp.firstElementChild; fresh.style.animation = 'none';
      el.replaceWith(fresh);
    } else renderThread();
    if (nearBottom) scrollBottom();
    const live = document.querySelector('.think.running .spark') || document.querySelector('.msg.live .av');
    Particles.setAttractorEl(live);
  });
}

function renderAll() {
  renderSessions(); renderTop(); renderThread(); updateBusyUI();
  window.onStudioContext?.();
}

// 线程内交互
$('#thread').addEventListener('click', async e => {
  const t = e.target;
  const sg = t.closest('[data-sg]');
  if (sg) { const s = SUGGESTS[sg.dataset.sg]; $('#input').value = s.p; autoGrow(); $('#input').focus(); updateSend(); return; }
  const copyBtn = t.closest('[data-copy]');
  if (copyBtn) { copyText(copyBtn.closest('.codeblock').querySelector('code').innerText); return; }
  if (t.matches('[data-zoom]')) { lightbox(t.src); return; }
  const tog = t.closest('[data-toggle]');
  if (tog?.dataset.toggle === 'chain') {
    const box = tog.parentElement, m = state.messages[+box.closest('.msg').dataset.mi];
    m._chainOpen = !box.classList.contains('open');
    box.classList.toggle('open', m._chainOpen);
    return;
  }
  if (tog) {
    const box = tog.parentElement, mi = +box.closest('.msg').dataset.mi, bi = +box.dataset.bi;
    const b = state.messages[mi].blocks[bi];
    b._open = !b._open;
    box.classList.toggle('open', b._open);
    if (tog.dataset.toggle === 'tool') box.querySelector('.tool-body').innerHTML = b._open ? renderToolBody(b) : '';
    return;
  }
  const opt = t.closest('.q-opt');
  if (opt) {
    const grp = opt.parentElement;
    if (grp.dataset.multi !== '1') grp.querySelectorAll('.q-opt').forEach(o => o.classList.remove('sel'));
    opt.classList.toggle('sel');
    return;
  }
  const pb = t.closest('[data-perm]');
  if (pb) { answerPermission(pb.closest('.perm'), pb.dataset.perm); return; }
  const act = t.closest('[data-act]');
  if (act) {
    const mi = +act.closest('.msg').dataset.mi, m = state.messages[mi];
    if (act.dataset.act === 'copy') copyText(m.blocks.filter(b => b.type === 'text').map(b => b.text).join('\n\n'));
    if (act.dataset.act === 'copy-user') copyText(m.text);
    if (act.dataset.act === 'edit-user') { $('#input').value = m.text; autoGrow(); updateSend(); $('#input').focus(); }
    if (act.dataset.act === 'continue') { sendMessage('继续。刚才被中断了，请从中断的地方接着完成。', []); return; }
    if (act.dataset.act === 'retry') {
      const u = [...state.messages.slice(0, mi)].reverse().find(x => x.role === 'user');
      if (u) sendMessage(u.text || '请重新回答上一个问题。', []);
    }
  }
});

async function answerPermission(box, kind) {
  const m = state.messages[state.messages.length - 1];
  const perm = m?.pendingPermission;
  if (!perm) return;
  const body = { requestId: perm.requestId, allow: kind !== 'deny', always: kind === 'always' };
  if (kind === 'answer') {
    const answers = {};
    box.querySelectorAll('.q-opts').forEach(g => {
      const q = perm.input.questions[+g.dataset.qi];
      const sel = [...g.querySelectorAll('.q-opt.sel')].map(o => o.dataset.label);
      if (sel.length) answers[q.question] = sel.join(', ');
    });
    if (!Object.keys(answers).length) { toast('请先选择一个选项', true); return; }
    body.updatedInput = { ...perm.input, answers };
  }
  if (kind === 'deny' && perm.tool === 'ExitPlanMode') body.message = '用户希望继续完善计划，暂不执行。';
  try {
    await api(`/api/sessions/${state.cur.id}/permission`, { method: 'POST', body });
    delete m.pendingPermission;
    renderLive();
  } catch (e) { toast(e.message, true); }
}

function lightbox(src) {
  const el = document.createElement('div');
  el.className = 'lightbox';
  el.innerHTML = `<img src="${src}">`;
  el.onclick = () => el.remove();
  document.body.append(el);
}

// 思考计时器
setInterval(() => {
  document.querySelectorAll('[data-live-start]').forEach(el => { const s = +el.dataset.liveStart; if (s) el.textContent = fmtDur(Date.now() - s); });
}, 100);

// ---------- 滚动 ----------
const scroller = $('#scroller');
function isNearBottom() { return scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < 140; }
function scrollBottom(instant) { scroller.scrollTo({ top: scroller.scrollHeight, behavior: instant ? 'auto' : 'smooth' }); }
scroller.addEventListener('scroll', () => {
  $('#topbar').classList.toggle('scrolled', scroller.scrollTop > 4);
  $('#jumpBtn').classList.toggle('show', !isNearBottom() && state.messages.length > 0);
});
$('#jumpBtn').onclick = () => scrollBottom();

// ---------- 附件 ----------
const MAX_FILE = 50 * 1024 * 1024;
function addFiles(files) {
  for (const f of files) {
    if (f.size > MAX_FILE) { toast(`${f.name} 超过 50MB`, true); continue; }
    const item = { name: f.name || `粘贴图片-${Date.now()}.png`, type: f.type || 'application/octet-stream', size: f.size, isImage: /^image\/(png|jpeg|gif|webp)$/.test(f.type), data: null, preview: null };
    state.pending.push(item);
    const rd = new FileReader();
    rd.onload = () => { const s = String(rd.result); item.data = s.slice(s.indexOf(',') + 1); if (item.isImage) item.preview = s; renderPending(); updateSend(); };
    rd.readAsDataURL(f);
  }
  renderPending(); updateSend();
}
function renderPending() {
  const box = $('#pendingAtts');
  box.hidden = !state.pending.length;
  box.innerHTML = state.pending.map((a, i) => `<div class="patt">${a.isImage && a.preview ? `<img src="${a.preview}" data-zoom>` : `<div class="att-file"><span class="fi">${ext(a.name)}</span><div style="min-width:0"><div class="nm">${esc(a.name)}</div><small>${a.data ? fmtSize(a.size) : '读取中…'}</small></div></div>`}<button class="x" data-rm="${i}">${ic('x')}</button></div>`).join('');
}
$('#pendingAtts').onclick = e => {
  const rm = e.target.closest('[data-rm]');
  if (rm) { state.pending.splice(+rm.dataset.rm, 1); renderPending(); updateSend(); return; }
  if (e.target.matches('[data-zoom]')) lightbox(e.target.src);
};
$('#plusBtn').onclick = e => showMenu(e.currentTarget, `
  <button class="mi" data-v="img"><span class="m-ic" style="background:#e6b86a22;color:#e6b86a">${ic('image')}</span><span class="tx">上传图片<small>也可以直接 Ctrl+V 粘贴</small></span></button>
  <button class="mi" data-v="file"><span class="m-ic" style="background:#e0824f22;color:#e0824f">${ic('clip')}</span><span class="tx">上传文件<small>代码、文档、表格、PDF 等</small></span></button>
  <div class="sep"></div>
  <button class="mi" data-v="dir"><span class="m-ic" style="background:#d9c4a822;color:#d9c4a8">${ic('folder')}</span><span class="tx">更换工作目录<small>${esc(basename(state.cur?.cwd || cfg.lastCwd || state.home))}</small></span></button>`,
  v => { if (v === 'img') $('#imgInput').click(); if (v === 'file') $('#fileInput').click(); if (v === 'dir') changeCwd(); });
$('#fileInput').onchange = e => { addFiles(e.target.files); e.target.value = ''; };
$('#imgInput').onchange = e => { addFiles(e.target.files); e.target.value = ''; };

$('#input').addEventListener('paste', e => {
  const files = [...(e.clipboardData?.files || [])];
  if (files.length) { e.preventDefault(); addFiles(files); toast(`已添加 ${files.length} 个附件`); }
});
let dragDepth = 0;
addEventListener('dragenter', e => { if (e.dataTransfer?.types.includes('Files')) { dragDepth++; $('#dropOverlay').classList.add('show'); } });
addEventListener('dragleave', () => { if (--dragDepth <= 0) { dragDepth = 0; $('#dropOverlay').classList.remove('show'); } });
addEventListener('dragover', e => e.preventDefault());
addEventListener('drop', e => { e.preventDefault(); dragDepth = 0; $('#dropOverlay').classList.remove('show'); if (e.dataTransfer?.files.length) addFiles(e.dataTransfer.files); });

// ---------- 输入框 ----------
const input = $('#input');
function autoGrow() { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, innerHeight * .4) + 'px'; }
function updateSend() {
  const busy = !!(state.cur && state.busy.has(state.cur.id));
  const btn = $('#sendBtn');
  const hasText = !!input.value.trim() || state.pending.length > 0;
  btn.classList.toggle('interject', busy);
  btn.innerHTML = busy ? ic('spark') : ic('up');
  btn.title = busy ? '插话：在 Claude 工作时补充要求（Enter）' : '发送';
  btn.disabled = !hasText;
  $('#stopBtn').hidden = !busy;
  input.placeholder = busy ? 'Claude 正在工作…… 现在输入会作为「插话」补充给它' : '给 Claude 发消息，可粘贴图片、拖入文件…  输入 / 查看命令';
}
$('#stopBtn').onclick = () => stopGen();
input.addEventListener('input', () => { autoGrow(); updateSend(); slashMenu(); });
input.addEventListener('keydown', e => {
  if (e.isComposing) return;
  if (openMenu?.slash && ['ArrowDown', 'ArrowUp', 'Enter', 'Tab'].includes(e.key)) {
    e.preventDefault();
    const items = [...openMenu.el.querySelectorAll('.mi')];
    let i = items.findIndex(x => x.classList.contains('sel'));
    if (e.key === 'ArrowDown') i = (i + 1) % items.length;
    else if (e.key === 'ArrowUp') i = (i - 1 + items.length) % items.length;
    else { items[Math.max(i, 0)]?.click(); return; }
    items.forEach((x, j) => x.classList.toggle('sel', j === i));
    return;
  }
  const wantSend = cfg.sendKey === 'enter' ? (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey) : (e.key === 'Enter' && (e.ctrlKey || e.metaKey));
  if (wantSend) { e.preventDefault(); onSendClick(); }
});

// 斜杠命令
const SLASH = [
  { c: '/new', d: '新建对话', run: () => newChat() },
  { c: '/cwd', d: '更换工作目录', run: () => changeCwd() },
  { c: '/export', d: '导出当前对话为 Markdown', run: () => exportChat() },
  { c: '/theme', d: '切换深色 / 浅色主题', run: () => toggleTheme() },
  { c: '/settings', d: '打开设置', run: () => openSettings() },
  { c: '/compact', d: '压缩上下文（发送给 Claude Code）', send: true },
  { c: '/cost', d: '查看本次会话 API 估算价值（发送给 Claude Code）', send: true },
];
function slashMenu() {
  const v = input.value;
  if (!/^\/\S*$/.test(v)) { if (openMenu?.slash) closeMenu(); return; }
  const list = SLASH.filter(s => s.c.startsWith(v));
  if (!list.length) { if (openMenu?.slash) closeMenu(); return; }
  if (openMenu?.slash) closeMenu();
  showMenu($('#composer'), `<div class="mh">命令</div>` + list.map((s, i) => `<button class="mi ${i === 0 ? 'sel' : ''}" data-v="${s.c}"><span class="tx"><b style="font-family:var(--mono)">${s.c}</b><small>${s.d}</small></span></button>`).join(''), c => {
    const s = SLASH.find(x => x.c === c);
    if (s.send) { input.value = s.c; onSendClick(); return; }
    input.value = ''; autoGrow(); updateSend(); s.run();
  });
  openMenu.slash = true;
}

function onSendClick() {
  const busy = !!(state.cur && state.busy.has(state.cur.id));
  const text = input.value.trim();
  if (!text && !state.pending.length) return;
  if (state.pending.some(a => !a.data)) { toast('附件还在读取中…', true); return; }
  const r = $('#sendBtn').getBoundingClientRect();
  Particles.burst(r.left + r.width / 2, r.top + r.height / 2, 70);
  const atts = state.pending.map(a => ({ name: a.name, type: a.type, data: a.data }));
  input.value = ''; state.pending = []; renderPending(); autoGrow(); closeMenu();
  sendMessage(text, atts, { interject: busy });
}
$('#sendBtn').onclick = onSendClick;

async function sendMessage(text, attachments, { interject = false } = {}) {
  try {
    const s = await ensureSession();
    if (interject) {
      await api(`/api/sessions/${s.id}/send`, { method: 'POST', body: { text, attachments, interject: true, model: cfg.model || undefined, effort: cfg.effort, permissionMode: cfg.permissionMode } });
      toast('已插话，Claude 会在当前步骤后处理');
      return;
    }
    state.busy.add(s.id);
    updateBusyUI();
    await api(`/api/sessions/${s.id}/send`, { method: 'POST', body: { text, attachments, model: cfg.model || undefined, effort: cfg.effort, permissionMode: cfg.permissionMode } });
  } catch (e) {
    if (interject) { toast('插话失败：' + e.message, true); return; }
    if (state.cur) state.busy.delete(state.cur.id);
    updateBusyUI();
    toast('发送失败：' + e.message, true);
  }
}
async function stopGen() {
  if (!state.cur) return;
  await api(`/api/sessions/${state.cur.id}/stop`, { method: 'POST' }).catch(() => {});
  toast('正在停止…');
}

function updateBusyUI() {
  const busy = !!(state.cur && state.busy.has(state.cur.id));
  document.body.classList.toggle('busy', busy);
  Particles.setBusy(busy, document.querySelector('.msg.live .av') || $('#composer'));
  updateSend();
  window.onBusyChange?.();
}

// ---------- 语音输入 ----------
let rec = null;
$('#micBtn').onclick = () => {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { toast('当前浏览器不支持语音识别，请使用 Edge 或 Chrome', true); return; }
  if (rec) { rec.stop(); return; }
  rec = new SR();
  rec.lang = 'zh-CN'; rec.interimResults = true; rec.continuous = true;
  const base = input.value;
  rec.onresult = e => { let t = ''; for (const r of e.results) t += r[0].transcript; input.value = base + t; autoGrow(); updateSend(); };
  rec.onend = () => { rec = null; $('#micBtn').classList.remove('rec'); };
  rec.onerror = e => toast('语音识别出错：' + e.error, true);
  rec.start();
  $('#micBtn').classList.add('rec');
  toast('正在聆听，再次点击结束');
};

// ---------- 导出 ----------
function exportChat() {
  if (!state.messages.length) { toast('当前对话为空', true); return; }
  let md = `# ${state.cur?.title || '对话'}\n\n`;
  for (const m of state.messages) {
    if (m.role === 'user') md += `## 🧑 用户\n\n${m.text || ''}\n${(m.attachments || []).map(a => `\n> 附件：${a.name}`).join('')}\n\n`;
    else {
      md += `## ✦ Claude\n\n`;
      for (const b of m.blocks) {
        if (b.type === 'text') md += b.text + '\n\n';
        if (b.type === 'tool') md += `> 🔧 ${toolMeta(b.name).label}：\`${String(b.input ? toolMeta(b.name).sum(b.input) : '').split('\n')[0]}\`\n\n`;
      }
    }
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([md], { type: 'text/markdown' }));
  a.download = (state.cur?.title || 'chat').replace(/[\\/:*?"<>|]/g, '_') + '.md';
  a.click();
  toast('已导出 Markdown');
}
$('#exportBtn').onclick = exportChat;
$('#moreBtn').onclick = e => showMenu(e.currentTarget, `
  <button class="mi" data-v="export">${ic('download')}<span class="tx">导出为 Markdown</span></button>
  <button class="mi" data-v="copy">${ic('copy')}<span class="tx">复制全部对话</span></button>
  <button class="mi" data-v="pin">${ic('pin')}<span class="tx">${state.sessions.find(s => s.id === state.cur?.id)?.pinned ? '取消置顶' : '置顶对话'}</span></button>
  <div class="sep"></div>
  <button class="mi danger" data-v="del">${ic('trash')}<span class="tx">删除对话</span></button>`, async v => {
  if (!state.cur && v !== 'export') { toast('当前还没有对话', true); return; }
  if (v === 'export') exportChat();
  if (v === 'copy') copyText(state.messages.map(m => m.role === 'user' ? '用户：' + m.text : 'Claude：' + m.blocks.filter(b => b.type === 'text').map(b => b.text).join('\n')).join('\n\n'));
  if (v === 'pin') document.querySelector(`.sess[data-id="${state.cur.id}"] [data-act="pin"]`)?.click();
  if (v === 'del') document.querySelector(`.sess[data-id="${state.cur.id}"] [data-act="del"]`)?.click();
}, 'down');

// ---------- 布局按钮 ----------
function toggleSide() {
  const c = $('#app').classList.toggle('collapsed');
  $('#expandBtn').style.display = c ? '' : 'none';
}
function toggleTheme() { cfg.theme = cfg.theme === 'dark' ? 'light' : 'dark'; saveCfg(); applyCfg(); }
$('#collapseBtn').onclick = toggleSide;
$('#expandBtn').onclick = toggleSide;
$('#railNew').onclick = () => { showView('chat'); newChat(); };
$('#newChat').onclick = newChat;
function focusSearch() { showView('chat'); if ($('#app').classList.contains('collapsed')) toggleSide(); $('#searchInput').focus(); }
$('#railTheme').onclick = toggleTheme;
$('#footSettings').onclick = openSettings;

addEventListener('keydown', e => {
  const k = e.key.toLowerCase();
  if ((e.ctrlKey || e.metaKey) && k === 'k') { e.preventDefault(); focusSearch(); }
  else if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && k >= '1' && k <= '5') { e.preventDefault(); showView(VIEWS[+k - 1]); }
  else if ((e.ctrlKey || e.metaKey) && e.shiftKey && k === 'o') { e.preventDefault(); showView('chat'); newChat(); }
  else if ((e.ctrlKey || e.metaKey) && k === 'b') { e.preventDefault(); toggleSide(); }
  else if (k === 'escape') {
    if (document.querySelector('.lightbox')) document.querySelector('.lightbox').remove();
    else if (document.querySelector('.modal-bg')) document.querySelector('.modal-bg').close();
    else if (openMenu) closeMenu();
    else if (currentView === 'chat' && state.cur && state.busy.has(state.cur.id)) stopGen();
  }
});

// ---------- 服务端事件 ----------
function connectEvents() {
  const es = new EventSource('/api/events');
  es.onopen = () => { $('#cliInfo').textContent = '本地 CLI · 已连接'; };
  es.onerror = () => { $('#cliInfo').textContent = '连接中断，正在重连…'; };
  es.onmessage = ev => {
    const e = JSON.parse(ev.data);
    const sid = e.sessionId;
    try { window.onServerEvent?.(e); } catch (err) { console.error(err); }
    if (sid == null) return;
    if (e.session) {
      const i = state.sessions.findIndex(s => s.id === sid);
      if (i >= 0) state.sessions[i] = e.session; else state.sessions.unshift(e.session);
      if (state.cur?.id === sid) { state.cur = e.session; renderTop(); }
    }
    if (e.type === 'turn_start') { state.busy.add(sid); state.sessions.sort((a, b) => b.updatedAt - a.updatedAt); renderSessions(); }
    if (e.type === 'turn_end') { state.busy.delete(sid); renderSessions(); if (e.error && state.cur?.id !== sid) toast(e.error, true); }
    if (state.cur?.id !== sid) return;

    const m = state.messages[state.messages.length - 1];
    switch (e.type) {
      case 'turn_start':
        state.messages.push(e.user, e.assistant);
        renderThread(); scrollBottom(); updateBusyUI();
        break;
      case 'model': if (m) { m.model = e.model; renderLive(); } break;
      case 'block_start': if (m) { m.blocks[e.index] = e.block; renderLive(); } break;
      case 'delta': if (m?.blocks[e.index]) { m.blocks[e.index].text += e.text; renderLive(); } break;
      case 'block_stop': if (m?.blocks[e.index]) { m.blocks[e.index].durationMs = e.durationMs; renderLive(); } break;
      case 'thinking_tokens': if (m) m.thinkingTokens = e.value; break;
      case 'tool_input': { const b = m?.blocks.find(x => x.id === e.id); if (b) { b.input = e.input; renderLive(); } break; }
      case 'tool_result': { const b = m?.blocks.find(x => x.id === e.id); if (b) { b.result = e.result; b.status = e.status; b.endedAt = e.endedAt; renderLive(); } break; }
      case 'turn_progress': if (m) { m.cost = e.cost; m.usage = e.usage; } break;
      case 'permission': if (m) { m.pendingPermission = e; renderLive(); } break;
      case 'permission_done': if (m) { delete m.pendingPermission; renderLive(); } break;
      case 'turn_end':
        if (m) {
          Object.assign(m, { done: true, cost: e.cost, usage: e.usage, durationMs: e.durationMs });
          if (e.error) m.error = e.error;
          delete m.pendingPermission;
          m.blocks.forEach(b => { if (b.type === 'tool' && b.status === 'running') { b.status = e.error ? 'error' : 'done'; b.endedAt ||= Date.now(); } if (b.type === 'thinking' && b.durationMs == null) b.durationMs = Date.now() - b.startedAt; });
          renderLive();
        }
        updateBusyUI();
        break;
    }
  };
}

// ---------- 启动 ----------
(async function init() {
  mountIcons();
  applyCfg();
  try {
    const st = await api('/api/state');
    state.sessions = st.sessions;
    state.home = st.home;
    state.projects = st.projects || [];
    st.sessions.filter(s => s.busy).forEach(s => state.busy.add(s.id));
  } catch (e) { toast('无法连接本地服务：' + e.message, true); }
  renderAll();
  connectEvents();
  window.onAppReady?.();
  const openId = new URLSearchParams(location.search).get('open');
  if (openId && state.sessions.some(s => s.id === openId)) { showView('chat'); await openSession(openId); if (new URLSearchParams(location.search).get('chain')) { state.messages.forEach(m => m._chainOpen = true); renderThread(); } }
  input.focus();
})();
