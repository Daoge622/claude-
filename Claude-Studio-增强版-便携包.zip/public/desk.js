// 桌面桥接：Tauri 壳下接管窗口按钮 / 托盘事件；浏览器中隐藏窗口按钮
(() => {
  const T = window.__TAURI__;
  const Desk = {
    isTauri: !!T,
    win: null,
    async invoke(cmd, args) {
      if (!T?.core?.invoke) return null;
      try { return await T.core.invoke(cmd, args); } catch (e) { console.warn('invoke', cmd, e); return null; }
    },
    // 把桌面相关设置同步给 Rust 端（托盘关闭行为、全局快捷键）
    syncSettings(cfg) {
      return Desk.invoke('apply_settings', { closeToTray: !!cfg.closeToTray, hotkey: cfg.hotkey || '' });
    },
    async version() {
      try { return await T?.app?.getVersion?.(); } catch { return null; }
    },
  };
  window.Desk = Desk;

  function setup() {
    document.body.classList.toggle('is-tauri', Desk.isTauri);
    if (!Desk.isTauri) return;
    const w = T.window?.getCurrentWindow?.();
    Desk.win = w;
    const $ = id => document.getElementById(id);
    $('winMin').onclick = () => w?.minimize();
    $('winMax').onclick = () => w?.toggleMaximize();
    $('winClose').onclick = () => w?.close();
    // 托盘菜单「新对话」等由 Rust 端 emit
    T.event?.listen?.('tray-action', e => window.onTrayAction?.(e.payload));
    w?.onResized?.(async () => {
      document.body.classList.toggle('maximized', !!(await w.isMaximized?.()));
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setup);
  else setup();
})();
