// 轻量 Markdown 渲染器（无外部依赖），含代码高亮
(() => {
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  const KW = new Set(('const let var function return if else for while do break continue switch case default new class extends import from export async await try catch finally throw typeof instanceof in of this super null undefined true false yield static public private protected interface type enum implements def lambda pass elif with as is not and or None True False self fn mut impl struct pub use mod match loop go func package defer chan select map range string int bool float void char long echo local then fi done esac').split(' '));

  function highlight(code) {
    const re = /(\/\/[^\n]*|#(?![\w{])[^\n]*|\/\*[\s\S]*?\*\/|<!--[\s\S]*?-->)|("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`)|(\b\d+(?:\.\d+)?\b)|([A-Za-z_$][\w$]*)(?=\s*\()|([A-Za-z_$][\w$]*)/g;
    let out = '', last = 0, m;
    while ((m = re.exec(code))) {
      out += esc(code.slice(last, m.index));
      const t = esc(m[0]);
      if (m[1]) out += `<span class="tk-c">${t}</span>`;
      else if (m[2]) out += `<span class="tk-s">${t}</span>`;
      else if (m[3]) out += `<span class="tk-n">${t}</span>`;
      else if (m[4]) out += KW.has(m[4]) ? `<span class="tk-k">${t}</span>` : `<span class="tk-f">${t}</span>`;
      else if (m[5]) out += KW.has(m[5]) ? `<span class="tk-k">${t}</span>` : t;
      last = re.lastIndex;
    }
    return out + esc(code.slice(last));
  }

  function inline(s) {
    const codes = [];
    s = s.replace(/`([^`\n]+)`/g, (_, c) => { codes.push(c); return `\u0000${codes.length - 1}\u0000`; });
    s = esc(s);
    s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, '<img alt="$1" src="$2" style="max-width:100%;border-radius:10px">');
    s = s.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (_, t, u) => /^(https?:|mailto:|\/|#)/.test(u) ? `<a href="${u}" target="_blank" rel="noopener">${t}</a>` : `${t} (${u})`);
    s = s.replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g, '$1<a href="$2" target="_blank" rel="noopener">$2</a>');
    s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/__([^_]+)__/g, '<strong>$1</strong>');
    s = s.replace(/(^|[^*\w])\*([^*\n]+)\*(?!\w)/g, '$1<em>$2</em>');
    s = s.replace(/~~([^~]+)~~/g, '<del>$1</del>');
    return s.replace(/\u0000(\d+)\u0000/g, (_, i) => `<code>${esc(codes[i])}</code>`);
  }

  function render(src) {
    const lines = src.replace(/\r\n?/g, '\n').split('\n');
    let html = '', i = 0;
    const listStack = [];
    const closeLists = (indent = -1) => {
      while (listStack.length && listStack[listStack.length - 1].indent > indent) html += `</li></${listStack.pop().tag}>`;
    };
    while (i < lines.length) {
      const line = lines[i];
      // 代码块
      const fence = line.match(/^\s*(```|~~~)\s*([\w+#.-]*)/);
      if (fence) {
        closeLists();
        const lang = fence[2] || 'text';
        const buf = [];
        i++;
        while (i < lines.length && !lines[i].trim().startsWith(fence[1])) buf.push(lines[i++]);
        const unclosed = i >= lines.length;
        i++;
        const code = buf.join('\n');
        html += `<div class="codeblock"><div class="cb-head">${esc(lang)}<button data-copy>${ICONS.copy}复制</button></div><pre><code>${highlight(code)}${unclosed ? '' : ''}</code></pre></div>`;
        continue;
      }
      if (!line.trim()) { closeLists(); i++; continue; }
      const h = line.match(/^(#{1,6})\s+(.*)/);
      if (h) { closeLists(); html += `<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`; i++; continue; }
      if (/^\s*([-*_])\s*\1\s*\1[\s\1]*$/.test(line)) { closeLists(); html += '<hr>'; i++; continue; }
      // 表格
      if (line.includes('|') && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(lines[i + 1])) {
        closeLists();
        const cells = l => l.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim());
        html += '<table><thead><tr>' + cells(line).map(c => `<th>${inline(c)}</th>`).join('') + '</tr></thead><tbody>';
        i += 2;
        while (i < lines.length && lines[i].includes('|') && lines[i].trim()) { html += '<tr>' + cells(lines[i]).map(c => `<td>${inline(c)}</td>`).join('') + '</tr>'; i++; }
        html += '</tbody></table>';
        continue;
      }
      if (/^\s*>/.test(line)) {
        closeLists();
        const buf = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) buf.push(lines[i++].replace(/^\s*>\s?/, ''));
        html += `<blockquote>${render(buf.join('\n'))}</blockquote>`;
        continue;
      }
      const li = line.match(/^(\s*)([-*+]|\d+[.)])\s+(.*)/);
      if (li) {
        const indent = li[1].length, tag = /\d/.test(li[2]) ? 'ol' : 'ul';
        const top = listStack[listStack.length - 1];
        if (!top || indent > top.indent) { html += `<${tag}>`; listStack.push({ indent, tag }); }
        else { closeLists(indent); html += '</li>'; }
        let text = li[3];
        const task = text.match(/^\[([ xX])\]\s+(.*)/);
        if (task) text = `<input type="checkbox" disabled ${task[1] !== ' ' ? 'checked' : ''}> ` + inline(task[2]);
        else text = inline(text);
        html += `<li>${text}`;
        i++;
        continue;
      }
      if (listStack.length && /^\s+\S/.test(line)) { html += ' ' + inline(line.trim()); i++; continue; }
      closeLists();
      const buf = [line];
      i++;
      while (i < lines.length && lines[i].trim() && !/^(\s*(```|~~~|#{1,6}\s|>|[-*+]\s|\d+[.)]\s))/.test(lines[i]) && !(lines[i].includes('|') && lines[i + 1] && /^\s*\|?\s*:?-{2,}/.test(lines[i + 1]))) buf.push(lines[i++]);
      html += `<p>${buf.map(inline).join('<br>')}</p>`;
    }
    closeLists();
    return html;
  }

  window.MD = { render, esc, highlight };
})();
