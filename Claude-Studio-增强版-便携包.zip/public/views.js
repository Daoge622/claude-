// ============ 多页面：首页 / Agent 执行 / 项目文件 / 设置（复用 app.js 的全局状态与工具函数） ============
Object.assign(P, {
  home: '<path d="M4 11 12 4l8 7v8a1 1 0 0 1-1 1h-4v-6h-6v6H5a1 1 0 0 1-1-1Z"/>',
  chat: '<path d="M4 6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H9l-5 4Z"/>',
  activity: '<path d="M3 12h4l3-7 4 14 3-7h4"/>',
  play: '<path d="M7 5v14l12-7Z"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 5v6h-6"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  monitor: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.5"/>',
  db: '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
  key: '<rect x="2" y="7" width="20" height="10" rx="2"/><path d="M6 11h1M10 11h1M14 11h1M18 11h1M7 14h10"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  history: '<path d="M4 12a8 8 0 1 0 2.3-5.7L4 8.5M4 4v4.5h4.5M12 8v4l3 2"/>',
});

const VIEWS = ['home', 'chat', 'agent', 'files', 'settings'];
const VIEW_NAMES = { home: '首页', chat: '对话', agent: 'Agent 执行', files: '项目文件', settings: '设置' };
const NAV_ICONS = { home: 'home', chat: 'chat', agent: 'activity', files: 'folder', settings: 'gear' };
let currentView = null;
const vs = { stats: null, jobs: new Map(), jobOut: new Map(), agentSid: null, agentMsgs: null, agentFilter: 'all', selJob: null, cli: null,
  account: null, accountLoading: false, accountError: '', loginCode: '', accountCodeOpen: false,
  files: { root: '', expanded: new Set(), cache: new Map(), sel: null, preview: null, hidden: false } };

function showView(v) {
  if (!VIEWS.includes(v)) v = 'home';
  const changed = currentView !== v;
  currentView = v;
  cfg.view = v; saveCfg();
  document.querySelectorAll('.view').forEach(el => el.classList.toggle('on', el.dataset.view === v));
  document.querySelectorAll('.rail .nav').forEach(b => b.classList.toggle('on', b.dataset.view === v));
  $('#tbView').textContent = VIEW_NAMES[v];
  if (changed || v !== 'chat') RENDER[v]?.();
  if (v === 'chat') setTimeout(() => input.focus(), 0);
}
const RENDER = {
  home: () => renderHome(),
  chat: () => { renderChatExtras(); scrollBottom(true); },
  agent: () => renderAgent(),
  files: () => renderFiles(),
  settings: () => renderSettings(),
};
document.querySelectorAll('.rail .nav').forEach(b => {
  b.innerHTML = ic(NAV_ICONS[b.dataset.view]);
  b.onclick = () => showView(b.dataset.view);
});

// ---------- 通用 ----------
const fmtCost = c => '$' + (c || 0).toFixed(c >= 100 ? 0 : c >= 1 ? 2 : 4);
const fmtNum = n => (n || 0) >= 1e6 ? (n / 1e6).toFixed(2) + 'M' : fmtTok(n);
const fmtPct = x => (x * 100).toFixed(x >= .995 || x === 0 ? 0 : 1) + '%';
function fmtTime(t) { const d = new Date(t); return d.toTimeString().slice(0, 8); }
function fmtAgo(t) {
  const s = (Date.now() - t) / 1000;
  if (s < 60) return '刚刚'; if (s < 3600) return Math.floor(s / 60) + ' 分钟前';
  if (s < 86400) return Math.floor(s / 3600) + ' 小时前'; if (s < 86400 * 30) return Math.floor(s / 86400) + ' 天前';
  return new Date(t).toLocaleDateString();
}
function hitRate(u) { const d = (u?.input || 0) + (u?.cacheRead || 0) + (u?.cacheWrite || 0); return d ? u.cacheRead / d : 0; }
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
function emptyState(text, img = '/assets/claude/3.png') { return `<div class="empty"><img src="${img}" alt=""><div>${text}</div></div>`; }
async function loadStats() { try { vs.stats = await api('/api/stats'); } catch {} return vs.stats; }
let accountPoll = 0;
function acceptAccount(account) {
  vs.account = account; vs.accountError = '';
  if (account.login?.status !== 'pending') { vs.loginCode = ''; vs.accountCodeOpen = false; }
  renderAccountCards();
  clearTimeout(accountPoll);
  accountPoll = 0;
  if (account.login?.status === 'pending') accountPoll = setTimeout(() => { accountPoll = 0; loadAccount(); }, 2000);
}
async function loadAccount(refresh = false) {
  if (vs.accountLoading) return vs.account;
  vs.accountLoading = true; renderAccountCards();
  try { acceptAccount(await api('/api/account' + (refresh ? '?refresh=1' : ''))); }
  catch (e) { vs.accountError = e.message; }
  finally {
    vs.accountLoading = false; renderAccountCards();
    if (vs.account?.login?.status === 'pending' && !accountPoll) accountPoll = setTimeout(() => { accountPoll = 0; loadAccount(); }, 3000);
  }
  return vs.account;
}
const LIMIT_LABELS = { five_hour: '当前 5 小时', seven_day: '每周 · 全部模型', seven_day_opus: '每周 · Opus', seven_day_sonnet: '每周 · Sonnet', seven_day_overage_included: '每周（含额外用量）', overage: '额外用量' };
function accountDate(t) {
  return Number.isFinite(t) ? new Date(t).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false }) : '等待官方数据';
}
function officialLoginUrl(raw) {
  try {
    const u = new URL(raw);
    return u.protocol === 'https:' && (u.hostname === 'claude.ai' || u.hostname.endsWith('.claude.ai') || u.hostname === 'anthropic.com' || u.hostname.endsWith('.anthropic.com')) ? u.href : '';
  } catch { return ''; }
}
function accountCardContent() {
  const a = vs.account, pending = a?.login?.status === 'pending', ready = !!a?.ready;
  const plan = { pro: 'Claude Pro', max: 'Claude Max', team: 'Claude Team', enterprise: 'Claude Enterprise' }[a?.auth?.subscriptionType?.toLowerCase()] || (a?.auth?.subscriptionType ? 'Claude ' + a.auth.subscriptionType : 'Claude 官方订阅');
  const windows = [...(a?.limits?.windows || [])];
  for (const type of ['five_hour', 'seven_day']) if (!windows.some(w => w.type === type)) windows.push({ type, usedPercent: null, resetsAt: null });
  windows.sort((x, y) => Object.keys(LIMIT_LABELS).indexOf(x.type) - Object.keys(LIMIT_LABELS).indexOf(y.type));
  const loginUrl = officialLoginUrl(a?.login?.url);
  const error = vs.accountError || a?.login?.error || a?.error || a?.limits?.error;
  return `<div class="card-h"><h3>${ic('key')}官方账号与限额</h3><span class="account-badge ${ready && !pending ? 'connected' : ''}">${pending ? '正在登录' : ready ? esc(plan) : a ? '未连接' : '检测中'}</span><button class="link" data-aa="refresh" ${vs.accountLoading ? 'disabled' : ''} title="刷新官方登录状态与限额">${ic('refresh')}刷新</button></div>
    <div class="account-identity"><span>${pending ? '请在浏览器完成 Claude 官方登录' : ready ? esc(a.auth?.email || '已连接官方订阅') : '登录 Claude Pro / Max，使用你的官方订阅额度'}</span>${ready && !pending ? '<span class="ok-t">已连接</span>' : ''}</div>
    ${!ready && !pending ? '<div class="note">对话需要先登录 Claude 官方账号。订阅用量与 Claude 网页端共享。</div>' : ''}
    ${pending ? `<div class="note">浏览器登录完成后会自动更新状态。${loginUrl ? ` <a class="account-link" href="${esc(loginUrl)}" target="_blank" rel="noopener noreferrer">打开官方登录页面 ↗</a>` : '正在等待官方登录页面…'}</div>
      <details class="account-code" ${vs.accountCodeOpen ? 'open' : ''}><summary>登录页面要求手动粘贴授权码？</summary><label>按官方登录页面提示粘贴授权码<input type="text" data-account-code value="${esc(vs.loginCode)}" autocomplete="off" spellcheck="false" placeholder="授权码"></label><button class="btn" data-aa="code" ${vs.accountLoading ? 'disabled' : ''}>提交授权码</button></details>` : ''}
    ${error ? `<div class="account-error" role="alert">${esc(error)}</div>` : ''}
    <div class="account-windows">${windows.map(w => {
      const known = typeof w.usedPercent === 'number' && Number.isFinite(w.usedPercent);
      const pct = known ? Math.max(0, w.usedPercent) : null;
      const exceeded = w.status === 'rejected' || w.status === 'exceeded' || (known && pct >= 100);
      return `<div class="account-window ${exceeded ? 'at-limit' : ''}"><div class="account-window-head"><span>${esc(LIMIT_LABELS[w.type] || w.type)}</span><b>${known ? pct.toLocaleString('zh-CN', { maximumFractionDigits: 1 }) + '% 已用' : '等待官方数据'}</b></div>${known ? `<div class="meter" role="progressbar" aria-label="${esc(LIMIT_LABELS[w.type] || w.type)}已用" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.min(100, pct)}"><i style="width:${Math.min(100, pct)}%"></i></div>` : '<div class="account-unknown">官方暂未返回此限额的使用比例</div>'}<small>${w.resetsAt ? '重置：' + accountDate(w.resetsAt) : '重置时间：等待官方数据'}${exceeded ? ' · 已达限额' : ''}</small></div>`;
    }).join('')}</div>
    <div class="account-foot"><small>${a?.limits?.updatedAt ? '官方数据更新：' + accountDate(a.limits.updatedAt) : '尚未读取到官方限额；点击刷新或查看官方用量页面'}${a?.isolated ? ' · 使用官方连接' : ''}</small><div class="account-actions">${!pending ? `<button class="btn" data-aa="login" ${vs.accountLoading || state.busy.size ? 'disabled' : ''}>${ic('key')}${ready ? '切换官方账号' : '登录官方账号'}</button>` : ''}<a class="btn" href="https://claude.ai/settings/usage" target="_blank" rel="noopener noreferrer">官方用量页面 ↗</a></div></div>`;
}
function renderAccountCards() {
  const activeCode = document.activeElement?.matches('[data-account-code]') ? document.activeElement : null;
  const selection = activeCode ? [activeCode.selectionStart, activeCode.selectionEnd] : null;
  const activeCard = activeCode?.closest('[data-account-card]');
  document.querySelectorAll('[data-account-card]').forEach(box => { box.innerHTML = accountCardContent(); });
  if (activeCard && selection) { const code = activeCard.querySelector('[data-account-code]'); code?.focus(); code?.setSelectionRange(...selection); }
}
async function handleAccountAction(e) {
  const action = e.target.closest('[data-aa]')?.dataset.aa;
  if (!action) return;
  if (action === 'refresh') { await loadAccount(true); return; }
  if (vs.accountLoading) return;
  if (action === 'code' && !vs.loginCode.trim()) { toast('请粘贴官方页面提供的授权码', true); return; }
  vs.accountLoading = true; vs.accountError = ''; renderAccountCards();
  try {
    const path = action === 'code' ? '/api/account/login/code' : '/api/account/login';
    acceptAccount(await api(path, { method: 'POST', ...(action === 'code' ? { body: { code: vs.loginCode.trim() } } : {}) }));
  } catch (er) { vs.accountError = er.message; }
  finally { vs.accountLoading = false; renderAccountCards(); }
}
for (const view of [$('#viewHome'), $('#viewSettings')]) {
  view.addEventListener('click', handleAccountAction);
  view.addEventListener('input', e => { if (e.target.matches('[data-account-code]')) vs.loginCode = e.target.value; });
  view.addEventListener('toggle', e => { if (e.target.matches('.account-code')) vs.accountCodeOpen = e.target.open; }, true);
}
async function refreshState() {
  try {
    const st = await api('/api/state');
    state.projects = st.projects || [];
    for (const s of st.sessions) { const i = state.sessions.findIndex(x => x.id === s.id); if (i >= 0) state.sessions[i] = s; }
  } catch {}
}
async function setWorkDir(dir) {
  cfg.lastCwd = dir; saveCfg();
  if (state.cur) { await api('/api/sessions/' + state.cur.id, { method: 'PATCH', body: { cwd: dir } }); state.cur.cwd = dir; }
  renderTop();
  toast('工作目录：' + basename(dir));
}
async function openProject(dir) {
  cfg.lastCwd = dir; saveCfg();
  showView('chat'); newChat(); renderTop();
  toast('已切换到项目 ' + basename(dir));
}

// ---------- Claude 娘状态 ----------
const STATUS = {
  idle: { label: '空闲', tip: '随时待命' },
  think: { label: '思考中', tip: '正在推理' },
  tool: { label: '调用工具', tip: '' },
  wait: { label: '等待授权', tip: '需要你确认' },
  error: { label: '出错了', tip: '上一轮中断' },
};
function chatStatus() {
  if (!state.cur) return { k: 'idle' };
  const m = state.messages[state.messages.length - 1];
  if (!state.busy.has(state.cur.id)) return { k: m?.role === 'assistant' && m.error ? 'error' : 'idle' };
  if (m?.pendingPermission) return { k: 'wait' };
  const last = m?.blocks?.[m.blocks.length - 1];
  if (last?.type === 'tool' && last.status === 'running') return { k: 'tool', tip: toolMeta(last.name).label };
  return { k: 'think' };
}
function renderChatExtras() {
  const st = chatStatus(), S = STATUS[st.k];
  const badge = $('#agentBadge');
  badge.className = 'agent-badge st-' + st.k;
  const face = { think: 2, tool: 2, wait: 2, error: 3 }[st.k] || (state.messages.at(-1)?.done ? 4 : 0);
  badge.innerHTML = `<img src="${face ? '/assets/claude/face-' + face + '.png' : '/assets/face.webp'}" alt=""><span class="ab-dot"></span><span class="ab-label">${S.label}${st.tip ? ' · ' + esc(st.tip) : ''}</span>`;
  badge.title = 'Claude 娘：' + S.label;
  const u = state.cur ? state.sessions.find(s => s.id === state.cur.id)?.usage || state.cur.usage : null;
  const chip = $('#usageChip');
  chip.hidden = !u?.turns;
  if (u?.turns) chip.innerHTML = `${ic('activity')}<span>${fmtNum(u.input + u.output + u.cacheRead + u.cacheWrite)} tok · API 估算 ${fmtCost(u.cost)}</span>`;
  chip.title = '本会话 Token 与 API 估算价值；官方订阅限额见首页或设置';
}
$('#usageChip').onclick = () => { vs.agentSid = state.cur?.id; showView('agent'); };
$('#agentBadge').onclick = () => { if (state.cur) { vs.agentSid = state.cur.id; showView('agent'); } };

function renderTitleStatus() {
  const busyN = state.busy.size, jobsN = [...vs.jobs.values()].filter(j => j.running).length;
  const el = $('#tbStatus');
  el.className = 'tb-status' + (busyN || jobsN ? ' busy' : '');
  el.innerHTML = busyN || jobsN ? `<i></i>${[busyN ? busyN + ' 个对话进行中' : '', jobsN ? jobsN + ' 个命令运行中' : ''].filter(Boolean).join(' · ')}` : '<i></i>空闲';
  el.onclick = () => showView('agent');
}
window.renderChatExtras = renderChatExtras;
window.onBusyChange = () => { renderChatExtras(); renderTitleStatus(); renderAccountCards(); if (currentView === 'home') renderHomeStand(); };

// ---------- 首页 ----------
function greeting() {
  const h = new Date().getHours();
  if (h < 5) return ['这么晚还不睡？', '……真拿你没办法。说吧，要我帮你做什么。'];
  if (h < 11) return ['早上好。', '才不是特意在等你呢，只是刚好醒着而已。今天的任务是？'];
  if (h < 14) return ['中午好。', '吃过饭了吗？吃完就把要做的事交给我吧。'];
  if (h < 19) return ['下午好。', '效率最高的时间段，别浪费了。有什么要处理的？'];
  return ['晚上好。', '又要加班？……行吧，我陪你把它做完。'];
}
function homeSub() {
  const n = state.busy.size;
  if (n) return `我正在处理 ${n} 个任务，别催，马上就好。`;
  const last = state.sessions[0];
  if (last && Date.now() - last.updatedAt < 3 * 86400000) return `上次的「${esc(last.title)}」还没收尾吧？要继续的话点下面。`;
  return greeting()[1];
}
function renderHomeStand() {
  const img = $('#standImg'); if (!img) return;
  const busy = state.busy.size > 0;
  const want = busy ? '/assets/stand-think.webp' : '/assets/stand-read.webp';
  if (!img.src.endsWith(want)) { img.classList.add('swap'); setTimeout(() => { img.src = want; img.classList.remove('swap'); }, 220); }
  const bub = $('#standBubble');
  if (bub) bub.textContent = busy ? '嗯……让我想想。' : '有事就说，我在听。';
  const sub = $('#homeSub'); if (sub) sub.innerHTML = homeSub();
}
function renderHome() {
  const [hi] = greeting();
  const st = vs.stats, today = new Date(), dk = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  const td = st?.byDay?.[dk];
  const recent = state.sessions.slice(0, 6), projects = state.projects.slice(0, 6);
  $('#viewHome').innerHTML = `<div class="home">
    <div class="home-main">
      <div class="hello">
        <div class="kicker">${today.toLocaleDateString('zh-CN', { month: 'long', day: 'numeric', weekday: 'long' })}</div>
        <h1>${hi}<span class="g">今天做什么？</span></h1>
        <p id="homeSub">${homeSub()}</p>
      </div>
      <div class="quick">
        <button class="qa" data-qa="new">${ic('edit')}<b>新对话</b><small>Ctrl+Shift+O</small></button>
        <button class="qa" data-qa="open">${ic('folder')}<b>打开项目</b><small>选择工作目录</small></button>
        <button class="qa" data-qa="resume" ${recent[0] ? '' : 'disabled'}>${ic('history')}<b>继续上次</b><small>${recent[0] ? esc(recent[0].title) : '暂无'}</small></button>
        <button class="qa" data-qa="shell">${ic('terminal')}<b>运行命令</b><small>Shell 控制台</small></button>
      </div>
      <div class="card account-card" data-account-card>${accountCardContent()}</div>
      <div class="home-grid">
        <div class="card">
          <div class="card-h"><h3>${ic('chat')}最近会话</h3><button class="link" data-qa="chat">全部</button></div>
          ${recent.length ? `<div class="rows">${recent.map(s => `<button class="row-item" data-sid="${s.id}">
            <span class="ri-t">${state.busy.has(s.id) ? '<span class="dot"></span>' : ''}${esc(s.title)}</span>
            <span class="ri-m">${esc(basename(s.cwd))} · ${fmtAgo(s.updatedAt)}</span></button>`).join('')}</div>` : emptyState('还没有会话。<br>第一句话总得有人先说吧？')}
        </div>
        <div class="card">
          <div class="card-h"><h3>${ic('folder')}最近项目</h3><button class="link" data-qa="files">文件</button></div>
          ${projects.length ? `<div class="rows">${projects.map(p => `<button class="row-item" data-proj="${esc(p.path)}" ${p.exists ? '' : 'disabled'}>
            <span class="ri-t">${esc(p.name)}</span><span class="ri-m" title="${esc(p.path)}">${esc(p.path)}${p.exists ? '' : '（不存在）'}</span></button>`).join('')}</div>` : emptyState('还没打开过项目。')}
        </div>
      </div>
      <div class="card usage-sum">
        <div class="card-h"><h3>${ic('activity')}本地用量记录</h3><button class="link" data-qa="agent">详情</button></div>
        <div class="kpis">
          <div class="kpi"><small>今日 API 估算价值</small><b>${fmtCost(td?.cost)}</b><span>${td?.turns || 0} 轮</span></div>
          <div class="kpi"><small>历史 API 估算价值</small><b>${fmtCost(st?.total.cost)}</b><span>${st?.total.turns || 0} 轮 · ${st?.sessions || 0} 个会话</span></div>
          <div class="kpi"><small>累计 Token</small><b>${fmtNum(st ? st.total.input + st.total.output + st.total.cacheRead + st.total.cacheWrite : 0)}</b><span>输出 ${fmtNum(st?.total.output)}</span></div>
          <div class="kpi"><small>缓存命中率</small><b>${fmtPct(st?.hitRate || 0)}</b><span class="meter"><i style="width:${(st?.hitRate || 0) * 100}%"></i></span></div>
        </div>
        <p class="usage-note">美元数值是 CLI 记录的 API 估算价值；官方订阅按上方使用比例与重置时间显示限额。</p>
      </div>
    </div>
    <div class="home-stand">
      <div class="stand-glow"></div>
      <img id="standImg" src="${state.busy.size ? '/assets/stand-think.webp' : '/assets/stand-read.webp'}" alt="Claude 娘">
      <div class="stand-bubble" id="standBubble">${state.busy.size ? '嗯……让我想想。' : '有事就说，我在听。'}</div>
    </div>
  </div>`;
  window.onStudioHome?.();
  if (!st) loadStats().then(() => currentView === 'home' && renderHome());
}
$('#viewHome').addEventListener('click', async e => {
  const qa = e.target.closest('[data-qa]')?.dataset.qa;
  if (qa === 'new') { showView('chat'); newChat(); }
  else if (qa === 'open') { const d = await pickDir(cfg.lastCwd || state.home); if (d) openProject(d); }
  else if (qa === 'resume' && state.sessions[0]) { showView('chat'); openSession(state.sessions[0].id); }
  else if (qa === 'shell') { showView('agent'); setTimeout(() => $('#shellCmd')?.focus(), 50); }
  else if (qa) showView(qa);
  const sid = e.target.closest('[data-sid]')?.dataset.sid;
  if (sid) { showView('chat'); openSession(sid); }
  const pj = e.target.closest('[data-proj]')?.dataset.proj;
  if (pj) openProject(pj);
});

// ---------- Agent 执行 ----------
async function loadAgentMsgs() {
  if (!vs.agentSid) { vs.agentMsgs = null; return; }
  if (vs.agentSid === state.cur?.id) { vs.agentMsgs = state.messages; return; }
  try { vs.agentMsgs = (await api('/api/sessions/' + vs.agentSid)).messages; } catch { vs.agentMsgs = []; }
}
const refetchAgent = debounce(async () => { await loadAgentMsgs(); if (currentView === 'agent') renderTimeline(); }, 800);

async function renderAgent() {
  if (!vs.agentSid || !state.sessions.some(s => s.id === vs.agentSid)) vs.agentSid = state.cur?.id || [...state.busy][0] || state.sessions[0]?.id || null;
  const root = $('#viewAgent');
  if (!root.querySelector('.agent')) {
    root.innerHTML = `<div class="agent">
      <div class="ag-col">
        <div class="card ag-timeline">
          <div class="card-h"><h3>${ic('activity')}工具调用时间线</h3>
            <select id="agSess" class="sel"></select>
            <div class="seg" id="agFilter"><button data-f="all">全部</button><button data-f="running">运行中</button><button data-f="error">失败</button></div>
          </div>
          <div class="tl" id="agTl"></div>
        </div>
      </div>
      <div class="ag-col">
        <div class="card ag-tasks"><div class="card-h"><h3>${ic('clock')}后台任务</h3></div><div id="agTasks"></div></div>
        <div class="card ag-shell">
          <div class="card-h"><h3>${ic('terminal')}Shell 控制台</h3>
            <select id="shellKind" class="sel">${(state.platform === 'win32' || navigator.platform.startsWith('Win')) ? '<option value="powershell">PowerShell</option><option value="cmd">cmd</option>' : '<option value="sh">sh</option>'}</select></div>
          <div class="sh-cwd">${ic('folder')}<input id="shellCwd" spellcheck="false"><button class="icon-btn" id="shellPick" title="选择目录">${ic('dots')}</button></div>
          <div class="sh-out" id="shellOut"></div>
          <form class="sh-in" id="shellForm"><span>›</span><input id="shellCmd" placeholder="输入命令，Enter 执行 · ↑ 历史" spellcheck="false" autocomplete="off"><button class="btn primary" type="submit">${ic('play')}运行</button></form>
        </div>
        <div class="card ag-usage"><div class="card-h"><h3>${ic('db')}用量</h3><button class="link" id="usageTableBtn">表格</button></div><div id="agUsage"></div></div>
      </div>
    </div>`;
    $('#agSess').onchange = async e => { vs.agentSid = e.target.value; await loadAgentMsgs(); renderTimeline(); };
    $('#agFilter').onclick = e => { const b = e.target.closest('[data-f]'); if (!b) return; vs.agentFilter = b.dataset.f; renderTimeline(); };
    $('#agTl').onclick = onTimelineClick;
    $('#agTasks').onclick = onTasksClick;
    $('#shellForm').onsubmit = runShell;
    $('#shellCmd').onkeydown = shellHistoryKey;
    $('#shellPick').onclick = async () => { const d = await pickDir($('#shellCwd').value); if (d) $('#shellCwd').value = d; };
    $('#usageTableBtn').onclick = () => { vs.usageTable = !vs.usageTable; renderUsage(); };
    if (cfg.shell) $('#shellKind').value = cfg.shell;
    $('#shellKind').onchange = e => { cfg.shell = e.target.value; saveCfg(); };
  }
  if (!$('#shellCwd').value) $('#shellCwd').value = state.cur?.cwd || cfg.lastCwd || state.home;
  await loadAgentMsgs();
  renderTimeline(); renderTasks(); renderShellOut(); renderUsage();
  loadStats().then(() => currentView === 'agent' && renderUsage());
}

function renderTimeline() {
  const sel = $('#agSess'); if (!sel) return;
  sel.innerHTML = state.sessions.length ? state.sessions.map(s => `<option value="${s.id}" ${s.id === vs.agentSid ? 'selected' : ''}>${state.busy.has(s.id) ? '● ' : ''}${esc(s.title)}</option>`).join('') : '<option>（无会话）</option>';
  $('#agFilter').querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.f === vs.agentFilter));
  if (vs.agentSid === state.cur?.id) vs.agentMsgs = state.messages;
  const msgs = vs.agentMsgs || [];
  const items = [];
  msgs.forEach((m, mi) => {
    if (m.role === 'user') { items.push({ kind: 'user', m, mi, at: m.at }); return; }
    m.blocks.forEach((b, bi) => {
      if (b.type === 'tool') items.push({ kind: 'tool', b, mi, bi, at: b.startedAt || m.startedAt });
      else if (b.type === 'interject') items.push({ kind: 'interject', b, mi, bi, at: b.at });
    });
    if (m.error) items.push({ kind: 'error', m, mi, at: m.startedAt + (m.durationMs || 0) });
    if (m.done && !m.error) items.push({ kind: 'done', m, mi, at: m.startedAt + (m.durationMs || 0) });
  });
  const f = vs.agentFilter;
  const shown = items.filter(it => f === 'all' || (f === 'running' ? it.kind === 'tool' && it.b.status === 'running' : (it.kind === 'tool' && it.b.status === 'error') || it.kind === 'error'));
  const tl = $('#agTl');
  if (!shown.length) { tl.innerHTML = emptyState(msgs.length ? '这里没有符合条件的记录。' : '选一个会话，我把每一步都摊开给你看。'); return; }
  const nearBottom = tl.scrollHeight - tl.scrollTop - tl.clientHeight < 80;
  tl.innerHTML = shown.map(it => {
    const t = it.at ? `<span class="tl-time">${fmtTime(it.at)}</span>` : '<span class="tl-time"></span>';
    if (it.kind === 'user') return `<div class="tl-it tl-user">${t}<span class="tl-dot"></span><div class="tl-body"><b>用户</b><span class="tl-sum">${esc((it.m.text || '[附件]').slice(0, 160))}</span></div></div>`;
    if (it.kind === 'interject') return `<div class="tl-it tl-user">${t}<span class="tl-dot"></span><div class="tl-body"><b>插话</b><span class="tl-sum">${esc(it.b.text.slice(0, 160))}</span></div></div>`;
    if (it.kind === 'error') return `<div class="tl-it tl-error">${t}<span class="tl-dot"></span><div class="tl-body"><b>中断</b><span class="tl-sum">${esc(it.m.error.slice(0, 200))}</span></div></div>`;
    if (it.kind === 'done') return `<div class="tl-it tl-done">${t}<span class="tl-dot"></span><div class="tl-body"><b>本轮完成</b><span class="tl-sum">${[fmtDur(it.m.durationMs), it.m.cost ? 'API 估算价值 ' + fmtCost(it.m.cost) : '', it.m.usage?.output_tokens ? fmtTok(it.m.usage.output_tokens) + ' 输出 tokens' : ''].filter(Boolean).join(' · ')}</span></div></div>`;
    const b = it.b, meta = toolMeta(b.name), sum = b.input ? String(meta.sum(b.input) || '').split('\n')[0] : '';
    const dur = b.endedAt && b.startedAt ? fmtDur(b.endedAt - b.startedAt) : b.status === 'running' && b.startedAt ? `<span data-live-start="${b.startedAt}"></span>` : '';
    return `<div class="tl-it tl-tool ${b.status} ${b._agOpen ? 'open' : ''}" data-mi="${it.mi}" data-bi="${it.bi}">${t}<span class="tl-dot"></span>
      <div class="tl-body"><div class="tl-head">${ic(meta.icon)}<b>${esc(meta.label)}</b><span class="tl-sum mono">${esc(sum)}</span><span class="tl-dur">${dur}</span>${b.status === 'running' ? '<span class="spin"></span>' : b.status === 'error' ? ic('x', 'i err') : ic('check', 'i ok')}</div>
      ${b._agOpen ? `<div class="tool-body tl-detail">${renderToolBody(b)}</div>` : ''}</div></div>`;
  }).join('');
  if (nearBottom) tl.scrollTop = tl.scrollHeight;
}
function onTimelineClick(e) {
  const it = e.target.closest('.tl-tool'); if (!it || e.target.closest('.tl-detail')) return;
  const b = vs.agentMsgs?.[+it.dataset.mi]?.blocks[+it.dataset.bi]; if (!b) return;
  b._agOpen = !b._agOpen; renderTimeline();
}

function renderTasks() {
  const box = $('#agTasks'); if (!box) return;
  const busy = state.sessions.filter(s => state.busy.has(s.id));
  const jobs = [...vs.jobs.values()].sort((a, b) => b.startedAt - a.startedAt).slice(0, 12);
  if (!busy.length && !jobs.length) { box.innerHTML = emptyState('没有进行中的任务。<br>……闲着也挺好的。'); return; }
  box.innerHTML = `<div class="rows">` +
    busy.map(s => `<div class="task"><span class="tk-ic busy">${ic('chat')}</span><div class="tk-t"><b>${esc(s.title)}</b><small>对话 · ${esc(basename(s.cwd))}</small></div>
      <button class="mini" data-open="${s.id}" title="打开">${ic('eye')}</button><button class="mini" data-stop="${s.id}" title="停止">${ic('stop')}</button></div>`).join('') +
    jobs.map(j => `<div class="task ${vs.selJob === j.id ? 'sel' : ''}" data-job="${j.id}"><span class="tk-ic ${j.running ? 'busy' : j.code === 0 ? 'ok' : 'err'}">${ic('terminal')}</span>
      <div class="tk-t"><b class="mono">${esc(j.cmd.split('\n')[0])}</b><small>${j.running ? `运行中 · <span data-live-start="${j.startedAt}"></span>` : `退出码 ${j.code ?? '?'} · ${fmtDur(j.endedAt - j.startedAt)}`} · ${esc(basename(j.cwd))}</small></div>
      ${j.running ? `<button class="mini" data-kill="${j.id}" title="结束">${ic('stop')}</button>` : `<button class="mini" data-rm="${j.id}" title="移除">${ic('x')}</button>`}</div>`).join('') + `</div>`;
}
async function onTasksClick(e) {
  const t = e.target.closest('[data-open],[data-stop],[data-kill],[data-rm],[data-job]'); if (!t) return;
  if (t.dataset.open) { showView('chat'); openSession(t.dataset.open); return; }
  if (t.dataset.stop) { await api(`/api/sessions/${t.dataset.stop}/stop`, { method: 'POST' }).catch(() => {}); toast('正在停止…'); return; }
  if (t.dataset.kill) { await api(`/api/jobs/${t.dataset.kill}/kill`, { method: 'POST' }).catch(er => toast(er.message, true)); return; }
  if (t.dataset.rm) { await api(`/api/jobs/${t.dataset.rm}`, { method: 'DELETE' }).catch(() => {}); vs.jobs.delete(t.dataset.rm); vs.jobOut.delete(t.dataset.rm); if (vs.selJob === t.dataset.rm) vs.selJob = null; renderTasks(); renderShellOut(); return; }
  if (t.dataset.job) { await selectJob(t.dataset.job); }
}
async function selectJob(id) {
  vs.selJob = id;
  if (!vs.jobOut.has(id)) { try { const r = await api('/api/jobs/' + id); vs.jobOut.set(id, r.output); vs.jobs.set(id, r.job); } catch {} }
  renderTasks(); renderShellOut();
}
async function loadJobs() {
  try { const r = await api('/api/jobs'); vs.jobs = new Map(r.jobs.map(j => [j.id, j])); } catch {}
  renderTitleStatus();
}
function renderShellOut() {
  const out = $('#shellOut'); if (!out) return;
  const j = vs.jobs.get(vs.selJob);
  if (!j) { out.innerHTML = `<div class="sh-empty">在下面输入命令。输出会实时显示在这里，也会出现在「后台任务」里。</div>`; return; }
  const text = vs.jobOut.get(j.id) || '';
  out.innerHTML = `<div class="sh-cmd"><span>${esc(j.cwd)}</span> › <b>${esc(j.cmd)}</b></div><pre>${esc(text.slice(-120000))}</pre>` +
    (j.running ? '<div class="sh-run"><span class="spin"></span>运行中…</div>' : `<div class="sh-exit ${j.code === 0 ? 'ok' : 'err'}">退出码 ${j.code ?? '?'} · ${fmtDur(j.endedAt - j.startedAt)}</div>`);
  out.scrollTop = out.scrollHeight;
}
const shellHist = JSON.parse(localStorage.getItem('cs.shellHist') || '[]');
let histIdx = -1;
function shellHistoryKey(e) {
  if (e.key === 'ArrowUp' && shellHist.length) { e.preventDefault(); histIdx = Math.min(histIdx + 1, shellHist.length - 1); e.target.value = shellHist[histIdx]; }
  else if (e.key === 'ArrowDown') { e.preventDefault(); histIdx = Math.max(histIdx - 1, -1); e.target.value = histIdx >= 0 ? shellHist[histIdx] : ''; }
}
async function runShell(e) {
  e.preventDefault();
  const cmd = $('#shellCmd').value.trim(); if (!cmd) return;
  const cwd = $('#shellCwd').value.trim() || state.home;
  if (shellHist[0] !== cmd) { shellHist.unshift(cmd); shellHist.length = Math.min(shellHist.length, 50); localStorage.setItem('cs.shellHist', JSON.stringify(shellHist)); }
  histIdx = -1;
  try {
    const r = await api('/api/shell', { method: 'POST', body: { cmd, cwd, shell: $('#shellKind').value, sessionId: state.cur?.id } });
    vs.jobs.set(r.job.id, r.job);
    if (!vs.jobOut.has(r.job.id)) vs.jobOut.set(r.job.id, '');
    vs.selJob = r.job.id;
    $('#shellCmd').value = '';
    renderTasks(); renderShellOut(); renderTitleStatus();
  } catch (er) { toast(er.message, true); }
}

// 本地用量：Token、缓存与 CLI 记录的 API 估算价值
function renderUsage() {
  const box = $('#agUsage'); if (!box) return;
  const st = vs.stats;
  if (!st) { box.innerHTML = '<div class="sh-empty">加载中…</div>'; return; }
  const sess = state.sessions.find(s => s.id === vs.agentSid)?.usage;
  const t = st.total;
  const days = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000);
    const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    days.push({ k, label: `${d.getMonth() + 1}/${d.getDate()}`, u: st.byDay[k] });
  }
  const max = Math.max(...days.map(d => d.u?.cost || 0), 0);
  const kpi = (label, val, sub) => `<div class="kpi"><small>${label}</small><b>${val}</b>${sub ? `<span>${sub}</span>` : ''}</div>`;
  const chart = vs.usageTable
    ? `<table class="u-table"><thead><tr><th>日期</th><th>API 估算价值</th><th>轮次</th><th>输入</th><th>输出</th><th>缓存读</th><th>缓存写</th></tr></thead><tbody>${days.filter(d => d.u).reverse().map(d => `<tr><td>${d.k}</td><td>${fmtCost(d.u.cost)}</td><td>${d.u.turns}</td><td>${fmtNum(d.u.input)}</td><td>${fmtNum(d.u.output)}</td><td>${fmtNum(d.u.cacheRead)}</td><td>${fmtNum(d.u.cacheWrite)}</td></tr>`).join('') || '<tr><td colspan="7">近 14 天没有记录</td></tr>'}</tbody></table>`
    : `<div class="bars-wrap"><div class="bars-h"><span>近 14 天每日 API 估算价值</span><span class="mono">${max ? '峰值 ' + fmtCost(max) : ''}</span></div>
      <div class="bars" id="usageBars">${days.map((d, i) => `<div class="bar-hit" data-i="${i}"><div class="bar" style="height:${max && d.u?.cost ? Math.max(2, d.u.cost / max * 100) : 0}%"></div></div>`).join('')}</div>
      <div class="bars-x">${days.map((d, i) => `<span>${i % 3 === 1 || i === 13 ? d.label : ''}</span>`).join('')}</div><div class="bar-tip" id="barTip" hidden></div></div>`;
  box.innerHTML = `<div class="kpis k3">
      ${kpi('历史 API 估算价值', fmtCost(t.cost), `${t.turns} 轮`)}
      ${kpi('输入 / 输出', `${fmtNum(t.input)} / ${fmtNum(t.output)}`, 'tokens')}
      ${kpi('缓存读 / 写', `${fmtNum(t.cacheRead)} / ${fmtNum(t.cacheWrite)}`, 'tokens')}
    </div>
    <div class="hit"><div class="hit-h"><span>缓存命中率</span><b>${fmtPct(st.hitRate)}</b></div><div class="meter"><i style="width:${st.hitRate * 100}%"></i></div>
      <small>= 缓存读 ÷（输入 + 缓存读 + 缓存写）${sess?.turns ? ` · 当前会话 ${fmtPct(hitRate(sess))} · API 估算价值 ${fmtCost(sess.cost)}` : ''}</small></div>
    ${chart}<p class="usage-note">本地记录包含历史会话。官方订阅限额请查看首页或设置中的官方账号卡片。</p>`;
  const bars = $('#usageBars');
  if (bars) {
    const tip = $('#barTip');
    bars.onmousemove = e => {
      const h = e.target.closest('.bar-hit'); if (!h) { tip.hidden = true; return; }
      const d = days[+h.dataset.i], u = d.u;
      tip.innerHTML = `<b>${d.k}</b><div>API 估算价值 <span class="mono">${fmtCost(u?.cost)}</span></div><div>${u ? `${u.turns} 轮 · 输出 ${fmtNum(u.output)} tok` : '无记录'}</div>`;
      tip.hidden = false;
      const r = h.getBoundingClientRect(), pr = bars.parentElement.getBoundingClientRect();
      tip.style.left = Math.min(Math.max(r.left - pr.left + r.width / 2, 60), pr.width - 60) + 'px';
      h.parentElement.querySelectorAll('.bar-hit').forEach(x => x.classList.toggle('hov', x === h));
    };
    bars.onmouseleave = () => { tip.hidden = true; bars.querySelectorAll('.hov').forEach(x => x.classList.remove('hov')); };
  }
}

// ---------- 项目 / 文件 ----------
const fsx = vs.files;
async function loadDir(p) {
  if (fsx.cache.has(p)) return fsx.cache.get(p);
  const r = await api('/api/files?path=' + encodeURIComponent(p));
  fsx.cache.set(p, r.entries);
  return r.entries;
}
async function setRoot(p) {
  fsx.root = p; fsx.expanded = new Set([p]); fsx.cache.clear(); fsx.sel = null; fsx.preview = null;
  try { await loadDir(p); } catch (e) { toast(e.message, true); }
  renderFiles();
}
function renderFiles() {
  const root = $('#viewFiles');
  if (!fsx.root) { fsx.root = state.cur?.cwd || cfg.lastCwd || state.projects[0]?.path || state.home; setRoot(fsx.root); return; }
  if (!root.querySelector('.files')) {
    root.innerHTML = `<div class="files">
      <div class="card fl-side">
        <div class="card-h"><h3>${ic('folder')}工作区</h3><button class="link" id="flOpen">打开文件夹</button></div>
        <select class="sel ws-sel" id="flWs"></select>
        <div class="fl-tools"><label class="confirm-check"><input type="checkbox" id="flHidden"> 显示隐藏文件</label><button class="mini" id="flRefresh" title="刷新">${ic('refresh')}</button></div>
        <div class="tree" id="flTree"></div>
      </div>
      <div class="card fl-main" id="flMain"></div>
    </div>`;
    $('#flOpen').onclick = async () => { const d = await pickDir(fsx.root); if (d) setRoot(d); };
    $('#flWs').onchange = e => setRoot(e.target.value);
    $('#flHidden').onchange = e => { fsx.hidden = e.target.checked; renderTree(); };
    $('#flRefresh').onclick = () => { fsx.cache.clear(); Promise.all([...fsx.expanded].map(p => loadDir(p).catch(() => {}))).then(renderTree); };
    $('#flTree').onclick = onTreeClick;
    $('#flMain').onclick = onPreviewClick;
  }
  const opts = [fsx.root, ...state.projects.map(p => p.path).filter(p => p.toLowerCase() !== fsx.root.toLowerCase())];
  $('#flWs').innerHTML = opts.map(p => `<option value="${esc(p)}" ${p === fsx.root ? 'selected' : ''}>${esc(basename(p))} — ${esc(p)}</option>`).join('');
  renderTree(); renderPreview();
}
function renderTree() {
  const tree = $('#flTree'); if (!tree) return;
  const walk = (dir, depth) => {
    const ents = fsx.cache.get(dir);
    if (!ents) return `<div class="tr-it muted" style="--d:${depth}">加载中…</div>`;
    const list = ents.filter(e => fsx.hidden || !e.hidden);
    if (!list.length) return `<div class="tr-it muted" style="--d:${depth}">（空）</div>`;
    return list.map(e => {
      const open = e.dir && fsx.expanded.has(e.path);
      return `<div class="tr-it ${e.dir ? 'dir' : 'file'} ${fsx.sel === e.path ? 'sel' : ''}" style="--d:${depth}" data-p="${esc(e.path)}" data-dir="${e.dir ? 1 : 0}" title="${esc(e.path)}">
        ${e.dir ? ic('chev', 'i tr-chev' + (open ? ' open' : '')) : '<span class="tr-sp"></span>'}${ic(e.dir ? 'folder' : 'file', 'i tr-ic')}<span class="tr-n">${esc(e.name)}</span></div>` + (open ? walk(e.path, depth + 1) : '');
    }).join('');
  };
  tree.innerHTML = `<div class="tr-it dir root ${fsx.sel === fsx.root ? 'sel' : ''}" style="--d:0" data-p="${esc(fsx.root)}" data-dir="1" data-root="1">${ic('folder', 'i tr-ic')}<span class="tr-n"><b>${esc(basename(fsx.root))}</b></span></div>` + walk(fsx.root, 1);
}
async function onTreeClick(e) {
  const it = e.target.closest('.tr-it[data-p]'); if (!it) return;
  const p = it.dataset.p;
  fsx.sel = p;
  if (it.dataset.dir === '1') {
    if (!it.dataset.root) { if (fsx.expanded.has(p)) fsx.expanded.delete(p); else { fsx.expanded.add(p); renderTree(); try { await loadDir(p); } catch (er) { toast(er.message, true); } } }
    fsx.preview = { dir: true, path: p };
  } else {
    fsx.preview = { loading: true, path: p };
    renderTree(); renderPreview();
    try { fsx.preview = await api('/api/file?path=' + encodeURIComponent(p)); } catch (er) { fsx.preview = { path: p, error: er.message }; }
  }
  renderTree(); renderPreview();
}
function renderPreview() {
  const box = $('#flMain'); if (!box) return;
  const pv = fsx.preview;
  if (!pv) { box.innerHTML = emptyState('在左边选一个文件，我帮你看看。', '/assets/claude/3.png'); return; }
  const isDir = !!pv.dir;
  const head = `<div class="pv-h"><div class="pv-t">${ic(isDir ? 'folder' : 'file')}<b>${esc(basename(pv.path))}</b><small class="mono">${esc(pv.path)}${pv.size != null ? ' · ' + fmtSize(pv.size) : ''}</small></div>
    <div class="pv-acts">
      <button class="btn" data-pa="ref">${ic('link')}引用到对话</button>
      <button class="btn" data-pa="cwd">${ic('folder')}设为工作目录</button>
      <button class="mini" data-pa="copy" title="复制路径">${ic('copy')}</button>
    </div></div>`;
  let body;
  if (pv.loading) body = '<div class="sh-empty">读取中…</div>';
  else if (pv.error) body = `<div class="a-err">${esc(pv.error)}</div>`;
  else if (isDir) { const n = fsx.cache.get(pv.path)?.length; body = `<div class="sh-empty">目录${n != null ? ` · ${n} 项` : ''}。「设为工作目录」会让 Claude 在这里读写文件、执行命令。</div>`; }
  else if (pv.image) body = `<div class="pv-img"><img src="/api/file?raw=1&path=${encodeURIComponent(pv.path)}" data-zoom alt=""></div>`;
  else if (pv.binary) body = '<div class="sh-empty">二进制文件，无法预览。</div>';
  else if (pv.tooLarge) body = '<div class="sh-empty">文件超过 512 KB，不在这里预览。可以「引用到对话」让 Claude 读取。</div>';
  else if (/\.(md|markdown)$/i.test(pv.path) && !fsx.rawMd) body = `<div class="pv-md md">${MD.render(pv.text)}</div><button class="link pv-toggle" data-pa="raw">查看源码</button>`;
  else {
    const lines = pv.text.split('\n');
    const code = pv.text.length < 200000 ? MD.highlight(pv.text) : esc(pv.text);
    body = `<div class="pv-code"><pre class="ln">${lines.map((_, i) => i + 1).join('\n')}</pre><pre class="code">${code}</pre></div>` + (/\.(md|markdown)$/i.test(pv.path) ? '<button class="link pv-toggle" data-pa="raw">渲染预览</button>' : '');
  }
  box.innerHTML = head + `<div class="pv-body">${body}</div>`;
}
async function onPreviewClick(e) {
  if (e.target.matches('[data-zoom]')) { lightbox(e.target.src); return; }
  const a = e.target.closest('[data-pa]')?.dataset.pa; if (!a) return;
  const pv = fsx.preview; if (!pv) return;
  if (a === 'raw') { fsx.rawMd = !fsx.rawMd; renderPreview(); return; }
  if (a === 'copy') { copyText(pv.path); return; }
  if (a === 'cwd') { const dir = pv.dir ? pv.path : pv.path.replace(/[\\/][^\\/]*$/, ''); await setWorkDir(dir).catch(er => toast(er.message, true)); return; }
  if (a === 'ref') {
    showView('chat');
    const ref = '`' + pv.path + '` ';
    const pos = input.selectionStart ?? input.value.length;
    input.value = input.value.slice(0, pos) + (pos && !/\s$/.test(input.value.slice(0, pos)) ? ' ' : '') + ref + input.value.slice(pos);
    autoGrow(); updateSend(); input.focus();
    toast('已引用 ' + basename(pv.path));
  }
}

// ---------- 设置 ----------
function segHtml(key, opts) { return `<div class="seg" data-key="${key}">${opts.map(([v, t]) => `<button data-sv="${v}" class="${String(cfg[key]) === String(v) ? 'on' : ''}">${t}</button>`).join('')}</div>`; }
function swHtml(key) { return `<button class="switch ${cfg[key] ? 'on' : ''}" data-sw="${key}"></button>`; }
function renderSettings() {
  const cli = vs.cli;
  const perm = PERMS.find(p => p.id === cfg.permissionMode) || PERMS[0];
  $('#viewSettings').innerHTML = `<div class="settings">
    <nav class="set-nav">${[['s-account', 'key', '官方账号'], ['s-look', 'palette', '外观'], ['s-chat', 'chat', '对话默认'], ['s-cli', 'terminal', 'CLI'], ['s-desk', 'monitor', '桌面'], ['s-data', 'db', '数据'], ['s-about', 'info', '关于']].map(([id, i, t]) => `<a href="#${id}" data-jump="${id}">${ic(i)}${t}</a>`).join('')}</nav>
    <div class="set-body" id="setBody">
      <section id="s-account" class="card account-card" data-account-card>${accountCardContent()}</section>
      <section id="s-look" class="card"><h3>${ic('palette')}外观</h3>
        <div class="set-row"><div>主题</div>${segHtml('theme', [['dark', '深色'], ['light', '浅色']])}</div>
        <div class="set-row"><div>首页立绘<small>关闭后首页只显示信息卡片</small></div>${swHtml('stand')}</div>
        <div class="set-row"><div>粒子特效<small>背景星尘、发送爆发、思考能量流</small></div>${swHtml('particles')}</div>
        <div class="set-row"><div>粒子密度</div>${segHtml('density', [[0.5, '稀疏'], [1, '标准'], [2, '密集']])}</div>
        <div class="set-row"><div>字体大小</div>${segHtml('fontSize', [[14, '小'], [15, '中'], [17, '大']])}</div>
      </section>
      <section id="s-chat" class="card"><h3>${ic('chat')}对话默认</h3>
        <div class="set-row"><div>模型<small>切换后下一条消息生效，保留上下文</small></div>${segHtml('model', MODELS.map(m => [m.id, m.id ? m.name.replace('Claude ', '') : '默认']))}</div>
        <div class="set-row"><div>思考强度</div>${segHtml('effort', EFFORTS.map(e => [e.id, e.name]))}</div>
        <div class="set-row"><div>权限模式<small>${esc(perm.desc)}</small></div>${segHtml('permissionMode', PERMS.map(p => [p.id, p.name]))}</div>
        <div class="set-row"><div>发送快捷键</div>${segHtml('sendKey', [['enter', 'Enter'], ['ctrl', 'Ctrl+Enter']])}</div>
        <div class="set-row"><div>默认工作目录<small class="mono">${esc(cfg.lastCwd || state.home)}</small></div><button class="btn" data-sa="cwd">${ic('folder')}更改</button></div>
      </section>
      <section id="s-cli" class="card"><h3>${ic('terminal')}Claude Code CLI</h3>
        ${cli ? `<div class="set-row"><div>状态</div><span class="${cli.ok ? 'ok-t' : 'err-t'}">${cli.ok ? '可用' : '不可用：' + esc(cli.error || '')}</span></div>
        <div class="set-row"><div>版本</div><span class="mono">${esc(cli.version || '—')}</span></div>
        <div class="set-row"><div>路径</div><span class="mono small">${cli.paths.map(esc).join('<br>') || '—'}</span></div>
        <div class="set-row"><div>Node.js / 平台</div><span class="mono">${esc(cli.node)} · ${esc(cli.platform)}</span></div>` : '<div class="set-row"><div>正在检测…</div></div>'}
        <div class="set-row" style="border:0"><div>本地服务端口<small>Claude Studio 后端（Node）</small></div><span class="mono">${cli?.port || location.port}</span></div>
        <div class="foot-l"><button class="btn" data-sa="cli">${ic('refresh')}重新检测</button></div>
      </section>
      <section id="s-desk" class="card"><h3>${ic('monitor')}桌面</h3>
        ${Desk.isTauri ? '' : '<div class="note">当前运行在浏览器中。以下选项在桌面客户端（Tauri）里生效。</div>'}
        <div class="set-row"><div>关闭窗口时最小化到托盘<small>托盘菜单：显示 / 新对话 / 退出</small></div>${swHtml('closeToTray')}</div>
        <div class="set-row"><div>全局显隐快捷键<small>在任何地方呼出 / 隐藏窗口</small></div><input class="kbd-in mono" id="hotkeyIn" value="${esc(cfg.hotkey)}" spellcheck="false"></div>
        <div class="set-row" style="border:0"><div>应用内快捷键<small>Ctrl+1…5 切换页面 · Ctrl+K 搜索 · Ctrl+Shift+O 新对话 · Ctrl+B 侧边栏 · Esc 停止生成</small></div></div>
      </section>
      <section id="s-data" class="card"><h3>${ic('db')}数据</h3>
        <div class="set-row"><div>数据目录<small class="mono">${esc(cli?.data || '—')}</small></div>${cli?.data ? `<button class="mini" data-sa="copydata" title="复制路径">${ic('copy')}</button>` : ''}</div>
        <div class="set-row"><div>会话 / 消息</div><span class="mono">${vs.stats ? `${vs.stats.sessions} / ${vs.stats.messages}` : '—'}</span></div>
        <div class="set-row"><div>历史 API 估算价值<small>CLI 记录的估算数值</small></div><span class="mono">${vs.stats ? fmtCost(vs.stats.total.cost) : '—'}</span></div>
        <div class="set-row" style="border:0"><div>重置界面偏好<small>清除本机保存的主题、模型等偏好（不删除会话）</small></div><button class="btn danger" data-sa="reset">重置</button></div>
      </section>
      <section id="s-about" class="card about"><img src="/assets/claude/4.png" alt="">
        <div><h3>Claude Studio</h3><p>基于 Claude Code CLI 的桌面 Agent 客户端。<br>版本 <span class="mono" id="appVer">${Desk.isTauri ? '…' : 'Web'}</span> · 驱动协议 stream-json</p>
        <p class="muted">……才不是为了让你夸我才做得这么用心的。</p></div></section>
    </div></div>`;
  if (!cli) api('/api/cli').then(r => { vs.cli = r; if (currentView === 'settings') renderSettings(); }).catch(() => {});
  if (!vs.stats) loadStats().then(() => currentView === 'settings' && renderSettings());
  if (Desk.isTauri) Desk.version().then(v => { const el = $('#appVer'); if (el && v) el.textContent = v; });
}
$('#viewSettings').addEventListener('click', async e => {
  const j = e.target.closest('[data-jump]');
  if (j) { e.preventDefault(); document.getElementById(j.dataset.jump)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
  const b = e.target.closest('.seg [data-sv]');
  if (b) {
    const key = b.parentElement.dataset.key, raw = b.dataset.sv;
    if (key === 'permissionMode' && raw === 'bypassPermissions') { confirmBypass(); return; }
    cfg[key] = typeof defaults[key] === 'number' ? Number(raw) : raw;
    saveCfg(); applyCfg(); renderSettings();
    return;
  }
  const sw = e.target.closest('[data-sw]');
  if (sw) { cfg[sw.dataset.sw] = !cfg[sw.dataset.sw]; saveCfg(); applyCfg(); Desk.syncSettings(cfg); renderSettings(); return; }
  const a = e.target.closest('[data-sa]')?.dataset.sa;
  if (a === 'cwd') { const d = await pickDir(cfg.lastCwd || state.home); if (d) { await setWorkDir(d); renderSettings(); } }
  if (a === 'cli') { vs.cli = null; renderSettings(); api('/api/cli?refresh=1').then(r => { vs.cli = r; renderSettings(); }); }
  if (a === 'copydata') copyText(vs.cli.data);
  if (a === 'reset') modal(`<h3>重置界面偏好？</h3><p>主题、模型、权限模式等偏好会恢复默认。会话记录不受影响。</p><div class="foot"><button class="btn" data-close>取消</button><button class="btn danger-solid" id="rsOk">重置</button></div>`, root => {
    root.querySelector('#rsOk').onclick = () => { localStorage.removeItem('cs.cfg'); location.reload(); };
  });
});
$('#viewSettings').addEventListener('change', e => {
  if (e.target.id === 'hotkeyIn') { cfg.hotkey = e.target.value.trim(); saveCfg(); Desk.syncSettings(cfg); toast('快捷键已保存'); }
});

// ---------- 服务端事件 ----------
const refreshHome = debounce(async () => { await Promise.all([loadStats(), refreshState()]); if (currentView === 'home') renderHome(); if (currentView === 'agent') renderUsage(); renderChatExtras(); }, 1200);
let statusRaf = 0;
function scheduleStatus() {
  if (statusRaf) return;
  statusRaf = requestAnimationFrame(() => {
    statusRaf = 0;
    renderChatExtras(); renderTitleStatus();
    if (currentView === 'agent') { if (vs.agentSid === state.cur?.id) renderTimeline(); renderTasks(); }
  });
}
window.onServerEvent = e => {
  if (e.type === 'account' && e.account) { acceptAccount(e.account); return; }
  if (e.type === 'job') {
    vs.jobs.set(e.job.id, e.job);
    if (!vs.jobOut.has(e.job.id)) vs.jobOut.set(e.job.id, '');
    if (currentView === 'agent') { renderTasks(); if (vs.selJob === e.job.id) renderShellOut(); }
    renderTitleStatus();
    return;
  }
  if (e.type === 'job_output') {
    vs.jobOut.set(e.id, ((vs.jobOut.get(e.id) || '') + e.data).slice(-256 * 1024));
    if (currentView === 'agent' && vs.selJob === e.id) renderShellOutDebounced();
    return;
  }
  if (e.sessionId == null) return;
  if (e.type === 'turn_end' || e.type === 'turn_start' || e.type === 'session') refreshHome();
  if (currentView === 'agent' && e.sessionId === vs.agentSid && e.sessionId !== state.cur?.id && e.type !== 'delta') refetchAgent();
  scheduleStatus();
};
const renderShellOutDebounced = debounce(renderShellOut, 60);
window.onTrayAction = a => {
  if (a === 'new-chat') { showView('chat'); newChat(); }
  else if (VIEWS.includes(a)) showView(a);
};
window.onAppReady = () => {
  showView(new URLSearchParams(location.search).get('view') || cfg.view || 'home');
  renderTitleStatus();
  loadJobs();
  loadStats().then(() => { if (currentView === 'home') renderHome(); });
  loadAccount();
  Desk.syncSettings(cfg);
};
