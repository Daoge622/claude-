// 粒子系统：漂浮星尘 + 鼠标排斥 + 发送爆发 + 思考时的能量流
(() => {
  const cv = document.getElementById('particles');
  const ctx = cv.getContext('2d');
  const COLORS = [[224, 130, 79], [230, 184, 106], [243, 233, 220], [243, 233, 220]];
  let W, H, DPR, dots = [], sparks = [], mouse = { x: -9999, y: -9999 };
  let enabled = true, density = 1, energy = 0, targetEnergy = 0, attractor = null, light = false;

  function resize() {
    DPR = Math.min(devicePixelRatio || 1, 2);
    W = innerWidth; H = innerHeight;
    cv.width = W * DPR; cv.height = H * DPR;
    cv.style.width = W + 'px'; cv.style.height = H + 'px';
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    seed();
  }
  function seed() {
    const n = Math.round((W * H) / 14000 * density);
    dots = Array.from({ length: n }, () => ({
      x: Math.random() * W, y: Math.random() * H,
      vx: (Math.random() - .5) * .15, vy: (Math.random() - .5) * .15,
      r: Math.random() * 1.6 + .3, c: COLORS[(Math.random() * COLORS.length) | 0],
      a: Math.random() * .5 + .15, tw: Math.random() * Math.PI * 2,
    }));
  }

  function burst(x, y, n = 60) {
    if (!enabled) return;
    for (let i = 0; i < n; i++) {
      const ang = Math.random() * Math.PI * 2, sp = Math.random() * 5 + 1.5;
      sparks.push({ x, y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp - 1.5, life: 1, r: Math.random() * 2.2 + .6, c: COLORS[(Math.random() * 3) | 0] });
    }
  }

  function frame(t) {
    requestAnimationFrame(frame);
    ctx.clearRect(0, 0, W, H);
    if (!enabled) return;
    energy += (targetEnergy - energy) * .03;
    const sp = 1 + energy * 5;
    ctx.globalCompositeOperation = light ? 'source-over' : 'lighter';

    for (const d of dots) {
      d.tw += .02;
      // 鼠标排斥
      const dx = d.x - mouse.x, dy = d.y - mouse.y, dist2 = dx * dx + dy * dy;
      if (dist2 < 16000) { const f = (16000 - dist2) / 16000 * .6; const dd = Math.sqrt(dist2) || 1; d.vx += dx / dd * f; d.vy += dy / dd * f; }
      // 思考时向能量核心螺旋汇聚
      if (attractor && energy > .05) {
        const ax = attractor.x - d.x, ay = attractor.y - d.y, ad = Math.hypot(ax, ay) || 1;
        d.vx += (ax / ad * .02 - ay / ad * .03) * energy;
        d.vy += (ay / ad * .02 + ax / ad * .03) * energy;
        if (ad < 30) { d.x = Math.random() * W; d.y = Math.random() < .5 ? -5 : H + 5; }
      }
      d.vx *= .96; d.vy *= .96;
      d.x += d.vx * sp + (d.vx === 0 ? 0 : 0); d.y += d.vy * sp;
      d.x += Math.sin(d.tw * .3) * .05; d.y -= .03;
      if (d.x < -10) d.x = W + 10; if (d.x > W + 10) d.x = -10;
      if (d.y < -10) d.y = H + 10; if (d.y > H + 10) d.y = -10;
      const alpha = d.a * .75 * (.6 + .4 * Math.sin(d.tw)) * (light ? .7 : 1) * (1 + energy * .8);
      ctx.fillStyle = `rgba(${d.c[0]},${d.c[1]},${d.c[2]},${Math.min(alpha, 1)})`;
      ctx.beginPath(); ctx.arc(d.x, d.y, d.r * (1 + energy * .4), 0, 6.283); ctx.fill();
    }
    // 近邻连线（能量越高越明显）
    if (energy > .1 && dots.length < 400) {
      ctx.lineWidth = .5;
      for (let i = 0; i < dots.length; i += 2) for (let j = i + 1; j < Math.min(i + 12, dots.length); j++) {
        const a = dots[i], b = dots[j], dx = a.x - b.x, dy = a.y - b.y, d2 = dx * dx + dy * dy;
        if (d2 < 9000) { ctx.strokeStyle = `rgba(230,184,106,${(1 - d2 / 9000) * .22 * energy})`; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
      }
    }
    for (let i = sparks.length - 1; i >= 0; i--) {
      const s = sparks[i];
      s.x += s.vx; s.y += s.vy; s.vy += .06; s.vx *= .98; s.life -= .018;
      if (s.life <= 0) { sparks.splice(i, 1); continue; }
      ctx.fillStyle = `rgba(${s.c[0]},${s.c[1]},${s.c[2]},${s.life})`;
      ctx.beginPath(); ctx.arc(s.x, s.y, s.r * s.life + .3, 0, 6.283); ctx.fill();
    }
    ctx.globalCompositeOperation = 'source-over';
  }

  addEventListener('resize', resize);
  addEventListener('mousemove', e => { mouse.x = e.clientX; mouse.y = e.clientY; });
  addEventListener('mouseleave', () => { mouse.x = mouse.y = -9999; });
  resize();
  requestAnimationFrame(frame);

  window.Particles = {
    burst,
    setBusy(on, el) {
      targetEnergy = on ? 1 : 0;
      if (el) { const r = el.getBoundingClientRect(); attractor = { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }
      if (!on) attractor = null;
    },
    setAttractorEl(el) { if (el && targetEnergy) { const r = el.getBoundingClientRect(); attractor = { x: r.left + r.width / 2, y: r.top + r.height / 2 }; } },
    setEnabled(v) { enabled = v; if (!v) ctx.clearRect(0, 0, W, H); },
    setDensity(v) { density = v; seed(); },
    setLight(v) { light = v; },
  };
})();
