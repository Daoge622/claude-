// Local workspace features. All task status and outputs come from saved sessions/files.
(() => {
  const studio = { data: null, loading: null, error: '', projectId: null, artifacts: [], artifactPath: '', artifactFilter: 'all', artifactLoading: false, artifactError: '', draft: null, contextTab: 'progress', outputPath: '', outputs: [], outputError: '', searchSeq: 0, searchResults: null, history: [], historyPos: -1, navigating: false };
  const DAY_NAMES = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
  const normPath = p => String(p || '').replace(/\\/g, '/').replace(/\/$/, '').toLowerCase();
  const projectFor = p => studio.data?.projects?.filter(x => normPath(p) === normPath(x.path) || normPath(p).startsWith(normPath(x.path) + '/')).sort((a, b) => b.path.length - a.path.length)[0];
  const currentPath = () => state.cur?.cwd || cfg.lastCwd || state.home;
  const shanghaiDate = () => new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Shanghai' });
  const dateTime = t => t ? new Date(t).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false }) : '—';
  const guarded = fn => async (...args) => { try { return await fn(...args); } catch (e) { toast(e.message || '操作失败', true); } };
  const field = (label, name, value = '', opts = '') => `<label class="studio-field">${label}<input name="${name}" value="${esc(value)}" ${opts}></label>`;
  const textarea = (label, name, value = '', rows = 4) => `<label class="studio-field">${label}<textarea name="${name}" rows="${rows}">${esc(value)}</textarea></label>`;
  const buttons = '<div class="foot"><button type="button" class="btn" data-close>取消</button><button type="submit" class="btn primary">保存</button></div>';
  const rawUrl = p => '/api/file?raw=1&path=' + encodeURIComponent(p);
  function webPreviewUrl(path) { const i = Math.max(path.lastIndexOf('\\'), path.lastIndexOf('/')); return '/api/preview/' + encodeURIComponent(path.slice(0, i + 1)) + '/' + encodeURIComponent(path.slice(i + 1)); }
  function pageHeader(title, desc, actions = '') { return `<div class="studio-page-head"><div><div class="kicker">CLAUDE STUDIO</div><h1>${title}</h1><p>${desc}</p></div><div class="studio-head-actions">${actions}</div></div>`; }
  function localEmpty(title, desc, action = '') { return `<div class="studio-empty"><div class="studio-empty-icon">${ic('folder')}</div><h3>${title}</h3><p>${desc}</p>${action}</div>`; }
  function errorBox() { return studio.error ? `<div class="account-error" role="alert">${esc(studio.error)} <button class="link" data-studio="refresh">重试</button></div>` : ''; }
  async function loadStudio(resetDraft = false) {
    if (studio.loading) return studio.loading;
    studio.loading = api('/api/studio/state').then(data => {
      studio.data = data; studio.error = '';
      if (!studio.draft || resetDraft) studio.draft = structuredClone(data.customization || {});
      renderCurrent(); renderContext(); return data;
    }).catch(e => { studio.error = e.message; renderCurrent(); throw e; }).finally(() => { studio.loading = null; });
    return studio.loading;
  }
  function renderCurrent() { if (['projects', 'artifacts', 'scheduled', 'customize'].includes(currentView)) RENDER[currentView](); }
  function ensureData() { if (!studio.data && !studio.loading) loadStudio().catch(() => {}); }
  function sessionsFor(project) { return state.sessions.filter(s => normPath(s.cwd) === normPath(project.path) || normPath(s.cwd).startsWith(normPath(project.path) + '/')); }

  // Projects store local folders and instructions; existing conversations are grouped by folder.
  function renderProjects() {
    const projects = studio.data?.projects || [], selected = projects.find(x => x.id === studio.projectId);
    $('#viewProjects').innerHTML = `<div class="studio-page">${pageHeader('Projects · 项目', '为工作文件夹保存说明，让同一个项目的对话和成果集中显示。', '<button class="btn" data-studio="new-project">' + ic('plus') + '新建项目</button>')}${errorBox()}<div class="studio-project-layout"><div class="studio-project-list">${projects.length ? projects.map(p => `<button class="card studio-project ${selected?.id === p.id ? 'selected' : ''}" data-project="${p.id}"><span class="studio-project-icon">${ic('folder')}</span><div><h3>${esc(p.name)}</h3><p>${esc(p.description || '本地工作区')}</p><small class="mono">${esc(p.path)}</small><span class="studio-count">${sessionsFor(p).length} 个对话</span></div></button>`).join('') : localEmpty('你的第一个项目', '选择一个已有的文件夹，再添加项目说明。', '<button class="btn" data-studio="new-project">创建项目</button>')}</div><div class="card studio-project-detail">${selected ? `<div class="card-h"><h3>${ic('folder')}${esc(selected.name)}</h3><button class="link" data-studio="edit-project" data-id="${selected.id}">编辑</button><button class="link err-t" data-studio="delete-project" data-id="${selected.id}">删除</button></div><p>${esc(selected.description || '')}</p><p class="mono small">${esc(selected.path)}</p><div class="studio-inline-actions"><button class="btn" data-studio="project-chat" data-id="${selected.id}">新建项目对话</button><button class="btn" data-studio="project-artifacts" data-id="${selected.id}">查看成果</button><button class="btn" data-studio="project-files" data-id="${selected.id}">浏览文件</button></div><h4>项目说明</h4><div class="studio-prose">${esc(selected.instructions || '尚未添加。编辑项目后，说明会用于该目录的新对话。')}</div><h4>项目对话</h4><div class="studio-chat-list">${sessionsFor(selected).map(s => `<button data-studio="open-chat" data-id="${s.id}">${ic('chat')}<span>${esc(s.title)}</span><small>${dateTime(s.updatedAt)}</small></button>`).join('') || '<p class="muted small">还没有对话。点击“新建项目对话”开始。</p>'}</div>` : localEmpty('选择一个项目', '项目说明、相关对话和工作文件会显示在这里。')}</div></div></div>`;
    ensureData();
  }
  function projectForm(project = {}) {
    modal(`<form id="studioProjectForm"><h3>${project.id ? '编辑项目' : '创建项目'}</h3>${field('项目名称', 'name', project.name, 'required maxlength="100"')}${field('工作文件夹', 'path', project.path || currentPath(), 'required')}<button type="button" class="btn" id="studioPickProject">${ic('folder')}选择文件夹</button>${textarea('简介', 'description', project.description, 2)}${textarea('项目说明 · 用于此目录的对话', 'instructions', project.instructions, 5)}${buttons}</form>`, root => {
      const form = root.querySelector('form');
      root.querySelector('#studioPickProject').onclick = guarded(async () => { const p = await pickDir(form.elements.path.value); if (p) form.elements.path.value = p; });
      form.onsubmit = guarded(async e => {
        e.preventDefault(); const body = Object.fromEntries(new FormData(form)); body.name = body.name.trim(); body.path = body.path.trim();
        if (!body.name || !body.path) throw new Error('请输入项目名称并选择工作文件夹');
        const button = form.querySelector('[type="submit"]'); button.disabled = true;
        try { const r = await api('/api/studio/projects' + (project.id ? '/' + project.id : ''), { method: project.id ? 'PATCH' : 'POST', body }); studio.projectId = r.project?.id || r.id || project.id; await loadStudio(); root.close(); toast('项目已保存'); } finally { button.disabled = false; }
      });
    });
  }

  // Artifacts are indexed from real project/workspace files and previewed locally.
  async function scanArtifacts(path = studio.artifactPath || currentPath(), projectId = null) {
    studio.artifactPath = path; studio.artifactLoading = true; studio.artifactError = ''; renderArtifacts();
    try { const r = await api('/api/studio/artifacts?' + (projectId ? 'projectId=' + encodeURIComponent(projectId) : 'path=' + encodeURIComponent(path))); studio.artifacts = r.artifacts || []; }
    catch (e) { studio.artifactError = e.message; studio.artifacts = []; }
    finally { studio.artifactLoading = false; if (currentView === 'artifacts') renderArtifacts(); }
  }
  function renderArtifacts() {
    const artifacts = studio.artifacts.filter(a => studio.artifactFilter === 'all' || a.kind === studio.artifactFilter);
    $('#viewArtifacts').innerHTML = `<div class="studio-page">${pageHeader('Artifacts · 成果', '查看工作区中真实生成的图片、文档、网页和代码。', '<button class="btn" data-studio="pick-artifacts">' + ic('folder') + '选择文件夹</button><button class="btn" data-studio="scan-artifacts">' + ic('refresh') + '刷新</button>')}<div class="studio-artifact-toolbar"><select id="studioArtifactProject"><option value="">当前工作区</option>${(studio.data?.projects || []).map(p => `<option value="${p.id}" ${normPath(p.path) === normPath(studio.artifactPath) ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select><span class="mono small">${esc(studio.artifactPath || currentPath())}</span><div class="studio-filter">${[['all', '全部'], ['image', '图片'], ['video', '视频'], ['audio', '音频'], ['document', '文档'], ['web', '网页'], ['code', '代码']].map(([kind, name]) => `<button class="${studio.artifactFilter === kind ? 'on' : ''}" data-artifact-filter="${kind}">${name}</button>`).join('')}</div></div>${studio.artifactError ? `<div class="account-error">${esc(studio.artifactError)}</div>` : ''}${studio.artifactLoading ? '<div class="sh-empty">正在扫描工作区…</div>' : artifacts.length ? `<div class="studio-artifact-grid">${artifacts.map(a => `<button class="card studio-artifact" data-artifact="${esc(a.path)}"><div class="studio-artifact-thumb">${a.kind === 'image' ? `<img src="${rawUrl(a.path)}" alt="${esc(a.name)}" loading="lazy">` : ic(a.kind === 'web' ? 'globe' : a.kind === 'code' ? 'code' : 'file')}</div><h3>${esc(a.name)}</h3><small>${esc(a.ext || a.kind)} · ${fmtSize(a.size || 0)}</small><small>${dateTime(a.mtime)}</small></button>`).join('')}</div>` : localEmpty('这个工作区暂时没有成果', '选择项目文件夹，或让 Claude 完成一个任务后刷新成果列表。')}</div>`;
    $('#studioArtifactProject').onchange = guarded(async e => { const project = studio.data?.projects?.find(p => p.id === e.target.value); await scanArtifacts(project?.path || currentPath(), project?.id); });
    ensureData();
  }
  async function previewArtifact(path) {
    const a = [...studio.artifacts, ...studio.outputs].find(x => x.path === path) || { path, name: basename(path) }, url = rawUrl(path), web = a.kind === 'web' || /\.html?$/i.test(path), preview = web ? webPreviewUrl(path) : url;
    const root = modal(`<div class="studio-preview"><div class="card-h"><h3>${ic('file')}${esc(a.name)}</h3><button class="icon-btn" data-close title="关闭">${ic('x')}</button></div><div id="studioPreviewBody" class="studio-preview-body">读取中…</div><div class="studio-inline-actions"><a class="btn" href="${preview}" target="_blank" rel="noopener noreferrer">打开文件 ↗</a><a class="btn" href="${url}" download="${esc(a.name)}">${ic('download')}下载</a><button class="btn" id="studioReference">引用到对话</button></div></div>`);
    root.classList.add('studio-preview-modal'); const body = root.querySelector('#studioPreviewBody');
    root.querySelector('#studioReference').onclick = () => { root.close(); showView('chat'); input.value += (input.value ? '\n' : '') + '`' + path + '`'; autoGrow(); updateSend(); input.focus(); };
    if (a.kind === 'image' || /\.(png|jpe?g|webp|gif|bmp)$/i.test(path)) body.innerHTML = `<img src="${url}" alt="${esc(a.name)}">`;
    else if (a.kind === 'video') body.innerHTML = `<video src="${url}" controls preload="metadata"></video>`;
    else if (a.kind === 'audio' || /\.(mp3|wav|ogg|m4a|flac)$/i.test(path)) body.innerHTML = `<audio src="${url}" controls preload="metadata"></audio>`;
    else if (web) body.innerHTML = `<iframe src="${preview}" title="${esc(a.name)}" sandbox="allow-scripts"></iframe>`;
    else if (/\.pdf$/i.test(path)) body.innerHTML = `<iframe src="${url}" title="${esc(a.name)}"></iframe>`;
    else {
      try { const file = await api('/api/file?path=' + encodeURIComponent(path)); body.innerHTML = file.text != null ? /\.(md|markdown)$/i.test(path) ? `<div class="md">${MD.render(file.text)}</div>` : `<pre>${esc(file.text)}</pre>` : '<div class="sh-empty">此文件请使用“打开文件”或“下载”。</div>'; }
      catch (e) { body.textContent = e.message; }
    }
  }

  // Scheduled tasks run only after users explicitly save them, in Shanghai time.
  function cadenceLabel(s) { return s.cadence === 'once' ? `一次 · ${s.date || ''} ${s.time}` : s.cadence === 'weekly' ? `每${DAY_NAMES[Number(s.weekday)]} ${s.time}` : s.cadence === 'weekdays' ? `工作日 ${s.time}` : `每天 ${s.time}`; }
  function renderScheduled() {
    const schedules = studio.data?.schedules || [];
    $('#viewScheduled').innerHTML = `<div class="studio-page">${pageHeader('Scheduled · 定时任务', '让 Claude 按时处理本地任务。时间采用 Asia/Shanghai，应用需要保持运行。', '<button class="btn" data-studio="new-schedule">' + ic('plus') + '新建任务</button>')}${errorBox()}${schedules.length ? `<div class="studio-schedule-list">${schedules.map(s => `<div class="card studio-schedule"><div class="studio-schedule-main"><div class="card-h"><h3>${ic('clock')}${esc(s.name)}</h3><span class="account-badge">${s.enabled ? '已启用' : '已暂停'}</span></div><p>${esc(s.prompt)}</p><div class="studio-schedule-meta"><span>${cadenceLabel(s)} · 上海时间</span><span>下次 ${dateTime(s.nextRunAt)}</span><span>最近 ${dateTime(s.lastRunAt)}${s.lastStatus ? ' · ' + esc(s.lastStatus) : ''}</span></div><small class="mono">${esc(s.cwd)}</small></div><div class="studio-schedule-actions"><button class="btn" data-studio="run-schedule" data-id="${s.id}">${ic('play')}现在运行</button><button class="btn" data-studio="toggle-schedule" data-id="${s.id}">${s.enabled ? '暂停' : '启用'}</button><button class="link" data-studio="edit-schedule" data-id="${s.id}">编辑</button>${s.lastSessionId ? `<button class="link" data-studio="open-chat" data-id="${s.lastSessionId}">查看结果</button>` : ''}<button class="link err-t" data-studio="delete-schedule" data-id="${s.id}">删除</button></div></div>`).join('')}</div>` : localEmpty('还没有定时任务', '创建每日简报、文件整理或项目检查。保存前可先编辑任务和运行时间。', '<button class="btn" data-studio="morning-brief">起草每日简报</button>')}</div>`;
    ensureData();
  }
  function scheduleForm(schedule = {}) {
    modal(`<form id="studioScheduleForm"><h3>${schedule.id ? '编辑定时任务' : '新建定时任务'}</h3>${field('任务名称', 'name', schedule.name, 'required maxlength="100"')}${textarea('交给 Claude 的任务', 'prompt', schedule.prompt, 5)}${field('工作文件夹', 'cwd', schedule.cwd || currentPath(), 'required')}<button type="button" class="btn" id="studioPickSchedule">选择文件夹</button><div class="studio-form-grid"><label class="studio-field">频率<select name="cadence">${[['once', '只运行一次'], ['daily', '每天'], ['weekdays', '工作日'], ['weekly', '每周']].map(([v, t]) => `<option value="${v}" ${(schedule.cadence || 'daily') === v ? 'selected' : ''}>${t}</option>`).join('')}</select></label>${field('运行时间 · 上海', 'time', schedule.time || '08:30', 'type="time" required')}${field('日期', 'date', schedule.date || shanghaiDate(), 'type="date"')}<label class="studio-field" id="studioWeekdayLabel">每周<select name="weekday">${DAY_NAMES.map((name, i) => `<option value="${i}" ${Number(schedule.weekday ?? 1) === i ? 'selected' : ''}>${name}</option>`).join('')}</select></label><label class="studio-field">模型<select name="model">${['sonnet', 'opus', 'haiku'].map(m => `<option value="${m}" ${(schedule.model || 'sonnet') === m ? 'selected' : ''}>Claude ${m[0].toUpperCase() + m.slice(1)}</option>`).join('')}</select></label></div><label class="studio-check"><input name="enabled" type="checkbox" ${schedule.enabled === false ? '' : 'checked'}>保存后启用此任务</label><p class="muted small">应用关闭时不会执行。使用官方订阅，需要先完成登录。</p>${buttons}</form>`, root => {
      const form = root.querySelector('form'), cadence = form.elements.cadence;
      const update = () => { form.elements.date.closest('label').hidden = cadence.value !== 'once'; root.querySelector('#studioWeekdayLabel').hidden = cadence.value !== 'weekly'; }; cadence.onchange = update; update();
      root.querySelector('#studioPickSchedule').onclick = guarded(async () => { const p = await pickDir(form.elements.cwd.value); if (p) form.elements.cwd.value = p; });
      form.onsubmit = guarded(async e => {
        e.preventDefault(); const body = Object.fromEntries(new FormData(form)); body.enabled = form.elements.enabled.checked; body.weekday = Number(body.weekday); body.name = body.name.trim(); body.prompt = body.prompt.trim(); body.cwd = body.cwd.trim();
        if (!body.name || !body.prompt || !body.cwd || !/^\d{2}:\d{2}$/.test(body.time)) throw new Error('请填写名称、任务内容、工作文件夹和有效时间');
        if (body.cadence === 'once' && !body.date) throw new Error('请选择运行日期');
        const button = form.querySelector('[type="submit"]'); button.disabled = true;
        try { await api('/api/studio/schedules' + (schedule.id ? '/' + schedule.id : ''), { method: schedule.id ? 'PATCH' : 'POST', body }); await loadStudio(); root.close(); toast('定时任务已保存'); } finally { button.disabled = false; }
      });
    });
  }

  // Global instructions, imported memory, real skills and MCP config are persisted on the server.
  function captureCustomization() {
    const form = $('#studioCustomizationForm'); if (!form) return studio.draft || {};
    return { ...(studio.draft || {}), instructions: form.elements.instructions.value, memory: form.elements.memory.value, language: form.elements.language.value };
  }
  async function saveCustomization(patch = {}) {
    studio.draft = { ...captureCustomization(), ...patch };
    await api('/api/studio/customization', { method: 'PATCH', body: studio.draft }); await loadStudio(true); toast('自定义设置已保存');
  }
  function renderCustomize() {
    const c = studio.draft || studio.data?.customization || {}, skills = c.skills || [];
    $('#viewCustomize').innerHTML = `<div class="studio-page studio-customize">${pageHeader('Customize · 自定义', '配置全局说明、记忆、Skills 和实际 MCP 扩展。保存后用于后续对话。')}${errorBox()}<form class="card" id="studioCustomizationForm"><div class="card-h"><h3>${ic('brain')}说明与记忆</h3></div>${textarea('全局说明', 'instructions', c.instructions, 5)}<div class="studio-field-head"><b>记忆</b><button type="button" class="link" data-studio="import-memory">从本地文本导入</button></div>${textarea('供 Claude 持续参考的背景与偏好', 'memory', c.memory, 6)}<label class="studio-field">回复语言<select name="language">${[['auto', '跟随对话'], ['zh-CN', '简体中文'], ['en', 'English'], ['ja', '日本語']].map(([v, t]) => `<option value="${v}" ${(c.language || 'auto') === v ? 'selected' : ''}>${t}</option>`).join('')}</select></label><div class="foot"><button type="submit" class="btn primary">保存说明与记忆</button></div></form><section class="card"><div class="card-h"><h3>${ic('bolt')}Skills</h3><button class="btn" data-studio="new-skill">${ic('plus')}添加 Skill</button></div><p class="muted small">启用的 Skill 内容会作为任务说明传给 Claude。</p><div class="studio-skill-list">${skills.map(s => `<div class="studio-skill"><label class="studio-check"><input type="checkbox" data-skill-toggle="${esc(s.id)}" ${s.enabled ? 'checked' : ''}><b>${esc(s.name)}</b></label><p>${esc((s.content || '').slice(0, 180))}</p><button class="link" data-studio="edit-skill" data-id="${esc(s.id)}">编辑</button><button class="link err-t" data-studio="delete-skill" data-id="${esc(s.id)}">删除</button></div>`).join('') || '<div class="sh-empty">没有添加 Skill。可以从现有说明中创建。</div>'}</div></section><section class="card" id="studioAppsSection"><div class="card-h"><h3>${ic('globe')}Apps 与扩展 · MCP</h3></div><p class="muted small">添加真实 MCP 服务配置，Claude Code 会在后续对话中加载。支持 stdio、HTTP / SSE 服务；配置仅保存在本机。</p><label class="studio-field">mcpServers JSON<textarea id="studioMcpJson" rows="8" spellcheck="false" class="mono">${esc(JSON.stringify(c.mcpServers || {}, null, 2))}</textarea></label><div class="foot"><a class="btn" href="https://code.claude.com/docs/en/mcp" target="_blank" rel="noopener noreferrer">官方配置说明 ↗</a><button class="btn primary" data-studio="save-mcp">保存扩展配置</button></div></section></div>`;
    $('#studioCustomizationForm').onsubmit = guarded(async e => { e.preventDefault(); await saveCustomization(); });
    $('#studioCustomizationForm').oninput = () => { studio.draft = captureCustomization(); };
    const chrome = document.createElement('div'); chrome.className = 'studio-chrome-setting';
    chrome.innerHTML = `<label class="studio-check"><input type="checkbox" data-chrome-enabled ${c.chromeEnabled ? 'checked' : ''}>启用 Claude in Chrome</label><p class="muted small">需要在 Chrome 中安装官方扩展并完成登录。启用后，后续对话会请求 Claude Code 的浏览器集成。</p><a class="link" href="https://code.claude.com/docs/en/chrome" target="_blank" rel="noopener noreferrer">官方安装与使用说明 ↗</a>`;
    $('#studioAppsSection').querySelector('.card-h').after(chrome);
    ensureData();
  }
  function skillForm(skill = {}) {
    modal(`<form id="studioSkillForm"><h3>${skill.id ? '编辑 Skill' : '添加 Skill'}</h3>${field('名称', 'name', skill.name, 'required maxlength="100"')}${textarea('Skill 说明', 'content', skill.content, 10)}<label class="studio-check"><input type="checkbox" name="enabled" ${skill.enabled === false ? '' : 'checked'}>启用</label>${buttons}</form>`, root => {
      root.querySelector('form').onsubmit = guarded(async e => { e.preventDefault(); const form = e.currentTarget, name = form.elements.name.value.trim(), content = form.elements.content.value.trim(); if (!name || !content) throw new Error('请填写 Skill 名称与说明'); const next = { id: skill.id || crypto.randomUUID(), name, content, enabled: form.elements.enabled.checked }; const list = [...(captureCustomization().skills || [])], i = list.findIndex(s => s.id === next.id); if (i < 0) list.push(next); else list[i] = next; await saveCustomization({ skills: list }); root.close(); });
    });
  }
  function importMemoryForm() {
    modal(`<form><h3>导入记忆</h3><p class="muted small">输入本地 UTF-8 文本或 Markdown 文件路径。导入内容会追加到记忆。</p>${field('本地文件路径', 'path', '', 'required placeholder="C:\\path\\memory.md"')}${buttons}</form>`, root => {
      root.querySelector('form').onsubmit = guarded(async e => { e.preventDefault(); const path = e.currentTarget.elements.path.value.trim(); if (!path) throw new Error('请输入记忆文件路径'); await saveCustomization(); await api('/api/studio/memory/import', { method: 'POST', body: { path } }); await loadStudio(true); root.close(); showView('customize'); toast('记忆已导入'); });
    });
  }

  // Right panel: real tool activity, output files, chosen folders and applied instructions.
  let panelFrame = 0, outputTimer = 0;
  function queueContext() { if (!panelFrame) panelFrame = requestAnimationFrame(() => { panelFrame = 0; renderContext(); }); }
  async function loadOutputs(force = false) {
    const path = currentPath(); if (!path || (!force && studio.outputPath === path)) return;
    studio.outputPath = path; studio.outputError = '';
    try { const r = await api('/api/studio/artifacts?path=' + encodeURIComponent(path)); if (currentPath() === path) studio.outputs = r.artifacts || []; }
    catch (e) { studio.outputError = e.message; studio.outputs = []; }
    renderContext();
  }
  function renderContext() {
    const box = $('#studioContextBody'); if (!box) return;
    document.querySelectorAll('[data-context-tab]').forEach(b => b.classList.toggle('on', b.dataset.contextTab === studio.contextTab));
    const project = projectFor(currentPath()), messages = state.messages || [], assistant = [...messages].reverse().find(m => m.role === 'assistant'), busy = !!state.cur && state.busy.has(state.cur.id);
    if (studio.contextTab === 'progress') {
      const tools = (assistant?.blocks || []).filter(b => b.type === 'tool').slice(-20).map(b => ({ b }));
      box.innerHTML = `<div class="studio-context-heading"><h3>${busy ? '正在处理' : assistant?.error ? '任务中断' : assistant?.done ? '本轮已完成' : '等待新任务'}</h3><small>${state.cur ? esc(state.cur.title) : '发送消息后显示实际任务进度'}</small></div>${assistant?.error ? `<div class="account-error">${esc(assistant.error)}</div>` : ''}${tools.length ? `<div class="studio-progress-list">${tools.map(({ b }) => { const meta = toolMeta(b.name), running = b.status === 'running', failed = b.status === 'error'; return `<div class="studio-progress ${running ? 'running' : failed ? 'failed' : ''}"><span>${ic(running ? 'clock' : failed ? 'warn' : 'check')}</span><div><b>${esc(meta.label)}</b><small>${esc(String(b.input ? meta.sum(b.input) || '' : '').split('\n')[0].slice(0, 120))}</small><em>${running ? '进行中' : failed ? '失败' : '已完成'}</em></div></div>`; }).join('')}</div>` : '<div class="studio-context-empty">工具调用开始后，会在这里显示实际步骤和执行状态。</div>'}`;
    } else if (studio.contextTab === 'outputs') {
      box.innerHTML = `<div class="studio-context-heading"><h3>工作区成果</h3><button class="link" data-studio="refresh-outputs">刷新</button><small class="mono">${esc(currentPath())}</small></div>${studio.outputError ? `<div class="account-error">${esc(studio.outputError)}</div>` : ''}${studio.outputs.length ? `<div class="studio-output-list">${studio.outputs.slice(0, 60).map(a => `<button data-artifact="${esc(a.path)}">${ic(a.kind === 'image' ? 'image' : a.kind === 'web' ? 'globe' : 'file')}<span><b>${esc(a.name)}</b><small>${fmtSize(a.size || 0)} · ${dateTime(a.mtime)}</small></span></button>`).join('')}</div>` : '<div class="studio-context-empty">工作区中尚未发现成果。完成任务后刷新查看。</div>'}<button class="btn" data-studio="all-outputs">打开 Artifacts</button>`;
      if (studio.outputPath !== currentPath()) loadOutputs();
    } else {
      const c = studio.data?.customization || {}, enabled = (c.skills || []).filter(s => s.enabled), contextDirs = state.cur?.contextDirs || cfg.contextDirs || [];
      box.innerHTML = `<div class="studio-context-heading"><h3>任务上下文</h3><small>当前对话使用的文件夹与说明</small></div><section><h4>工作文件夹</h4><p class="mono small">${esc(currentPath())}</p><button class="btn" data-studio="context-folder">更改工作文件夹</button></section><section><h4>附加上下文文件夹</h4>${contextDirs.map(path => `<div class="studio-context-directory">${ic('folder')}<span>${esc(path)}</span><button data-studio="remove-context" data-path="${esc(path)}" title="移除文件夹">${ic('x')}</button></div>`).join('') || '<p class="muted small">尚未添加</p>'}<button class="btn" data-studio="add-context">${ic('plus')}添加文件夹</button></section>${project ? `<section><h4>项目 · ${esc(project.name)}</h4><div class="studio-prose">${esc(project.instructions || '未设置项目说明')}</div></section>` : ''}<section><h4>全局说明</h4><div class="studio-prose">${esc(c.instructions || '未设置')}</div></section><section><h4>记忆</h4><div class="studio-prose">${esc(c.memory || '未导入')}</div></section><section><h4>已启用 Skills</h4>${enabled.map(s => `<span class="account-badge">${esc(s.name)}</span>`).join(' ') || '<small class="muted">无</small>'}</section><section><h4>MCP 扩展</h4><small>${esc(Object.keys(c.mcpServers || {}).join('、') || '未配置')}</small></section><div class="studio-inline-actions"><button class="btn" data-studio="customize">编辑自定义设置</button>${state.cur ? '<button class="btn" data-studio="fork-chat">从此对话创建分支</button>' : ''}</div>`;
      if (state.cur) { const label = document.createElement('label'); label.className = 'studio-check studio-session-memory'; label.innerHTML = `<input type="checkbox" data-session-memory ${state.cur.memoryEnabled !== false ? 'checked' : ''} ${busy ? 'disabled' : ''}>此会话使用记忆`; const memoryTitle = [...box.querySelectorAll('h4')].find(el => el.textContent === '记忆'); memoryTitle?.after(label); if (state.cur.memoryEnabled === false && memoryTitle) memoryTitle.parentElement.querySelector('.studio-prose').textContent = '此会话已停用存储的记忆。对话记录仍会保存。'; }
    }
  }

  // Account menu items open real internal surfaces or official support pages.
  function accountMenu(anchor) {
    const email = vs.account?.auth?.email || 'Claude 官方账号';
    const rows = [['settings', 'gear', '设置'], ['usage', 'activity', '用量'], ['language', 'globe', '语言'], ['apps', 'bolt', 'Apps 与扩展'], ['plans', 'spark', '订阅方案'], ['help', 'question', '帮助'], ['feedback', 'bug', '反馈'], ['changelog', 'history', '更新记录'], ['logout', 'x', '退出官方账号']];
    showMenu(anchor, `<div class="mh">${esc(email)}</div>${rows.map(([id, icon, label]) => `<button class="mi" data-v="${id}">${ic(icon)}<span class="tx">${label}</span></button>`).join('')}`, guarded(async id => {
      if (id === 'settings') showView('settings');
      else if (id === 'usage') { showView('settings'); document.getElementById('s-account')?.scrollIntoView({ behavior: 'smooth' }); await loadAccount(true); }
      else if (id === 'language') { showView('customize'); $('#studioCustomizationForm')?.elements.language.focus(); }
      else if (id === 'apps') { showView('customize'); $('#studioAppsSection')?.scrollIntoView({ behavior: 'smooth' }); }
      else if (id === 'changelog') modal('<h3>Claude Studio 0.3.0</h3><div class="studio-prose">官方订阅登录与实时限额\n本地 Projects 与 Artifacts\n上海时区定时任务\n全局说明、记忆、Skills 和 MCP\n任务进度、输出与上下文面板\n会话全文搜索与导航历史</div><div class="foot"><a class="btn" href="https://code.claude.com/docs/en/changelog" target="_blank" rel="noopener noreferrer">Claude Code 更新记录 ↗</a><button class="btn" data-close>关闭</button></div>');
      else if (id === 'logout') modal('<h3>退出官方账号？</h3><p>会话和本地项目会保留。退出后需要重新登录才能使用官方订阅。</p><div class="foot"><button class="btn" data-close>取消</button><button class="btn danger" id="studioLogout">退出账号</button></div>', root => { root.querySelector('#studioLogout').onclick = guarded(async () => { await api('/api/account/logout', { method: 'POST' }); await loadAccount(true); root.close(); toast('已退出官方账号'); }); });
      else { const links = { plans: 'https://claude.ai/upgrade', help: 'https://support.claude.com/', feedback: 'https://support.claude.com/' }; window.open(links[id], '_blank', 'noopener,noreferrer'); }
    }));
  }

  async function handleAction(e) {
    const action = e.target.closest('[data-studio]')?.dataset.studio, id = e.target.closest('[data-id]')?.dataset.id;
    const project = studio.data?.projects?.find(p => p.id === id), schedule = studio.data?.schedules?.find(s => s.id === id);
    if (action === 'refresh') await loadStudio();
    else if (action === 'new-project') projectForm();
    else if (action === 'edit-project') projectForm(project);
    else if (action === 'delete-project') modal(`<h3>删除项目？</h3><p>将移除「${esc(project.name)}」的项目设置。文件夹和对话保留。</p><div class="foot"><button class="btn" data-close>取消</button><button class="btn danger" id="studioDelete">删除项目</button></div>`, root => { root.querySelector('#studioDelete').onclick = guarded(async () => { await api('/api/studio/projects/' + id, { method: 'DELETE' }); studio.projectId = null; await loadStudio(); root.close(); }); });
    else if (action === 'project-chat') { await openProject(project.path); queueContext(); }
    else if (action === 'project-files') { showView('files'); await setRoot(project.path); }
    else if (action === 'project-artifacts') { showView('artifacts'); await scanArtifacts(project.path, project.id); }
    else if (action === 'open-chat') { showView('chat'); await openSession(id); queueContext(); }
    else if (action === 'pick-artifacts') { const p = await pickDir(studio.artifactPath || currentPath()); if (p) await scanArtifacts(p); }
    else if (action === 'scan-artifacts') await scanArtifacts();
    else if (action === 'new-schedule') scheduleForm();
    else if (action === 'morning-brief') { showView('scheduled'); scheduleForm({ name: '每日项目简报', prompt: '检查当前项目的文件与最新变更，用中文生成今日工作简报：当前进展、待办事项、风险和下一步。把简报保存到 outputs 目录的 Markdown 文件中。', cadence: 'daily', time: '08:30', enabled: false }); }
    else if (action === 'edit-schedule') scheduleForm(schedule);
    else if (action === 'toggle-schedule') { await api('/api/studio/schedules/' + id, { method: 'PATCH', body: { enabled: !schedule.enabled } }); await loadStudio(); }
    else if (action === 'run-schedule') { const r = await api('/api/studio/schedules/' + id + '/run', { method: 'POST' }); await loadStudio(); const sid = r.session?.id || r.sessionId || r.id; if (sid) { showView('chat'); await openSession(sid); } toast('任务已启动'); }
    else if (action === 'delete-schedule') modal(`<h3>删除定时任务？</h3><p>${esc(schedule.name)}</p><div class="foot"><button class="btn" data-close>取消</button><button class="btn danger" id="studioDelete">删除</button></div>`, root => { root.querySelector('#studioDelete').onclick = guarded(async () => { await api('/api/studio/schedules/' + id, { method: 'DELETE' }); await loadStudio(); root.close(); }); });
    else if (action === 'customize') showView('customize');
    else if (action === 'new-skill') skillForm();
    else if (action === 'edit-skill') skillForm((captureCustomization().skills || []).find(s => s.id === id));
    else if (action === 'delete-skill') await saveCustomization({ skills: (captureCustomization().skills || []).filter(s => s.id !== id) });
    else if (action === 'import-memory') importMemoryForm();
    else if (action === 'save-mcp') { let servers; try { servers = JSON.parse($('#studioMcpJson').value); } catch { throw new Error('MCP 配置不是有效 JSON'); } if (!servers || Array.isArray(servers) || typeof servers !== 'object') throw new Error('mcpServers 必须是 JSON 对象'); await saveCustomization({ mcpServers: servers }); }
    else if (action === 'refresh-outputs') await loadOutputs(true);
    else if (action === 'all-outputs') { showView('artifacts'); await scanArtifacts(currentPath()); }
    else if (action === 'context-folder') { const p = await pickDir(currentPath()); if (p) { await setWorkDir(p); studio.outputPath = ''; renderContext(); } }
    else if (action === 'add-context' || action === 'remove-context') {
      let dirs = [...(state.cur?.contextDirs || cfg.contextDirs || [])];
      if (action === 'add-context') { const path = await pickDir(currentPath()); if (!path) return; if (!dirs.some(p => normPath(p) === normPath(path))) dirs.push(path); }
      else { const path = e.target.closest('[data-path]')?.dataset.path; dirs = dirs.filter(p => normPath(p) !== normPath(path)); }
      if (state.cur) { const r = await api('/api/sessions/' + state.cur.id, { method: 'PATCH', body: { contextDirs: dirs } }); Object.assign(state.cur, r.session || r, { contextDirs: dirs }); }
      else { cfg.contextDirs = dirs; saveCfg(); }
      renderContext();
    }
    else if (action === 'fork-chat' && state.cur) { const r = await api('/api/sessions/' + state.cur.id + '/fork', { method: 'POST', body: {} }); showView('chat'); await openSession(r.session.id); toast('已创建对话分支'); }
    const projectButton = e.target.closest('[data-project]'); if (projectButton) { studio.projectId = projectButton.dataset.project; renderProjects(); }
    const artifact = e.target.closest('[data-artifact]'); if (artifact) await previewArtifact(artifact.dataset.artifact);
    const filter = e.target.closest('[data-artifact-filter]'); if (filter) { studio.artifactFilter = filter.dataset.artifactFilter; renderArtifacts(); }
    const tab = e.target.closest('[data-context-tab]'); if (tab) { studio.contextTab = tab.dataset.contextTab; renderContext(); }
  }
  document.addEventListener('click', guarded(handleAction));
  document.addEventListener('change', guarded(async e => {
    const id = e.target.dataset.skillToggle;
    if (id) await saveCustomization({ skills: (captureCustomization().skills || []).map(s => s.id === id ? { ...s, enabled: e.target.checked } : s) });
    if (e.target.matches('[data-chrome-enabled]')) await saveCustomization({ chromeEnabled: e.target.checked });
    if (e.target.matches('[data-session-memory]') && state.cur) { const r = await api('/api/sessions/' + state.cur.id, { method: 'PATCH', body: { memoryEnabled: e.target.checked } }); Object.assign(state.cur, r.session || r); renderContext(); }
  }));

  Object.assign(P, { calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18M8 14h1M13 14h1M8 18h1"/>', back: '<path d="m14 6-6 6 6 6"/>', forward: '<path d="m10 6 6 6-6 6"/>' });
  VIEWS.push('projects', 'artifacts', 'scheduled', 'customize');
  Object.assign(VIEW_NAMES, { projects: 'Projects · 项目', artifacts: 'Artifacts · 成果', scheduled: 'Scheduled · 定时任务', customize: 'Customize · 自定义' });
  Object.assign(NAV_ICONS, { projects: 'folder', artifacts: 'file', scheduled: 'calendar', customize: 'gear' });
  Object.assign(RENDER, { projects: renderProjects, artifacts: () => { renderArtifacts(); if (!studio.artifactPath && !studio.artifactLoading) scanArtifacts(); }, scheduled: renderScheduled, customize: renderCustomize });
  document.querySelectorAll('.rail .nav').forEach(b => { const v = b.dataset.view; b.innerHTML = ic(NAV_ICONS[v]) + `<span>${esc({ home: '首页', chat: '对话', agent: 'Agent 执行', files: '项目文件', settings: '设置', projects: 'Projects', artifacts: 'Artifacts', scheduled: 'Scheduled', customize: 'Customize' }[v] || v)}</span>`; b.onclick = () => showView(v); });
  $('#studioBack').innerHTML = ic('back'); $('#studioForward').innerHTML = ic('forward'); $('#studioNavToggle').innerHTML = ic('side'); $('#studioContextToggle').innerHTML = ic('list'); $('#studioContextClose').innerHTML = ic('x'); $('#studioAccount').innerHTML = '<img src="/assets/face.webp" alt=""><span>账号菜单</span>';
  $('#studioAccount').onclick = e => accountMenu(e.currentTarget); $('#footSettings').onclick = e => accountMenu(e.currentTarget);
  $('#studioNavToggle').onclick = () => { if (matchMedia('(max-width: 1280px)').matches) document.body.classList.toggle('studio-nav-expanded'); else { document.body.classList.toggle('studio-nav-collapsed'); cfg.studioNavCollapsed = document.body.classList.contains('studio-nav-collapsed'); saveCfg(); } };
  document.body.classList.toggle('studio-nav-collapsed', !!cfg.studioNavCollapsed);
  $('#studioContextToggle').onclick = () => { if (matchMedia('(max-width: 1280px)').matches) { document.body.classList.toggle('studio-context-open'); document.body.classList.remove('studio-context-hidden'); } else { document.body.classList.toggle('studio-context-hidden'); document.body.classList.remove('studio-context-open'); } queueContext(); };
  $('#studioContextClose').onclick = () => document.body.classList.remove('studio-context-open');
  const baseShowView = showView;
  function historyButtons() { $('#studioBack').disabled = studio.historyPos <= 0; $('#studioForward').disabled = studio.historyPos >= studio.history.length - 1; }
  showView = function(v) { baseShowView(v); if (!studio.navigating && studio.history[studio.historyPos] !== currentView) { studio.history.splice(studio.historyPos + 1); studio.history.push(currentView); studio.historyPos = studio.history.length - 1; } historyButtons(); queueContext(); if (currentView === 'home') mountHomeActions(); };
  function historyMove(delta) { const pos = studio.historyPos + delta; if (pos < 0 || pos >= studio.history.length) return; studio.historyPos = pos; studio.navigating = true; showView(studio.history[pos]); studio.navigating = false; }
  $('#studioBack').onclick = () => historyMove(-1); $('#studioForward').onclick = () => historyMove(1); historyButtons();
  function mountHomeActions() { const home = $('#viewHome .home-main'); if (!home || home.querySelector('.studio-home-actions')) return; const box = document.createElement('div'); box.className = 'studio-home-actions'; box.innerHTML = `<button data-studio="customize">${ic('gear')}自定义 Claude<small>说明、Skills 与 Apps</small></button><button data-studio="morning-brief">${ic('calendar')}每日简报<small>先编辑，再决定启用</small></button><button data-studio="import-memory">${ic('brain')}导入记忆<small>本地文本与偏好</small></button>`; home.querySelector('.quick')?.after(box); }
  window.onStudioHome = mountHomeActions; window.onStudioContext = queueContext;
  const baseReady = window.onAppReady; window.onAppReady = () => { baseReady?.(); mountHomeActions(); loadStudio().catch(() => {}); queueContext(); };
  const baseEvent = window.onServerEvent; window.onServerEvent = e => { baseEvent?.(e); if (e.type === 'studio' || e.type === 'schedule') loadStudio().catch(() => {}); queueMicrotask(queueContext); if (e.type === 'turn_end') { clearTimeout(outputTimer); outputTimer = setTimeout(() => { loadOutputs(true); loadStudio().catch(() => {}); }, 700); } };
  const baseRenderAll = renderAll; renderAll = function() { baseRenderAll(); queueContext(); };
  const baseRenderSessions = renderSessions;
  function renderSearchResults() {
    const saved = studio.searchResults; if (!saved || saved.q !== state.filter.trim()) return;
    const hits = saved.hits.filter(s => state.sessions.some(x => x.id === s.id));
    $('#sessList').innerHTML = hits.length ? `<div class="group-title">全文搜索 · ${hits.length} 个对话</div>` + hits.map(s => `<div class="sess ${s.id === state.cur?.id ? 'on' : ''}" data-id="${s.id}"><span class="t">${esc(state.sessions.find(x => x.id === s.id)?.title || s.title || '对话')}</span>${state.busy.has(s.id) ? '<span class="dot"></span>' : ''}${s.snippet ? `<small class="studio-search-snippet">${esc(s.snippet)}</small>` : ''}</div>`).join('') : '<div class="group-title">没有匹配的对话</div>';
  }
  renderSessions = function() { baseRenderSessions(); renderSearchResults(); };
  const baseSearch = $('#searchInput').oninput;
  $('#searchInput').oninput = debounce(guarded(async e => {
    baseSearch?.(e); const q = e.target.value.trim(), seq = ++studio.searchSeq; if (!q) return;
    const r = await api('/api/studio/search?q=' + encodeURIComponent(q)); if (seq !== studio.searchSeq || e.target.value.trim() !== q) return;
    const hits = r.sessions || (r.results || []).map(s => ({ ...state.sessions.find(x => x.id === (s.sessionId || s.id)), ...s, id: s.sessionId || s.id }));
    studio.searchResults = { q, hits }; renderSearchResults();
  }), 220);
  if (!(window.SpeechRecognition || window.webkitSpeechRecognition)) { $('#micBtn').disabled = false; $('#micBtn').onclick = () => { input.focus(); modal('<h3>语音输入</h3><p>当前桌面运行环境未提供浏览器语音识别。请在消息输入框中按 <kbd>Win + H</kbd> 使用 Windows 语音键入。</p><div class="foot"><button class="btn" data-close>知道了</button></div>'); }; }
  // If initialization completed before this script loaded, attach immediately as well.
  if (currentView) { mountHomeActions(); loadStudio().catch(() => {}); queueContext(); }
})();
