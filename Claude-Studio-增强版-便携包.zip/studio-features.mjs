import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { randomUUID, createHash } from 'node:crypto';

const VERSION = '0.3.0';
const ZONE_OFFSET = 8 * 60 * 60 * 1000; // Asia/Shanghai: UTC+08:00, no daylight saving.
const POLL_MS = 15_000;
const LATE_GRACE_MS = 60_000;
const CADENCES = new Set(['once', 'daily', 'weekdays', 'weekly']);
const MODELS = new Set(['sonnet', 'opus', 'haiku']);
const OMIT_DIRS = new Set(['node_modules', '.git', 'target', '.cache', '.venv', 'venv']);
const ARTIFACT_EXTS = new Set(['html', 'htm', 'svg', 'png', 'jpg', 'jpeg', 'webp', 'gif', 'avif', 'pdf', 'md', 'txt', 'docx', 'pptx', 'xlsx', 'csv', 'tsv', 'mp4', 'webm', 'mov', 'mp3', 'wav', 'ogg', 'm4a', 'flac', 'json', 'tex', 'js', 'mjs', 'ts', 'tsx', 'jsx', 'py', 'css', 'rs', 'cpp', 'c', 'cs', 'ps1', 'sql', 'yaml', 'yml']);
const OMIT_FILES = new Set(['package.json', 'package-lock.json', 'tsconfig.json', 'settings.json', 'sessions.json', 'features.json', 'official-limits.json']);

class InputError extends Error {
  constructor(message, status = 400) { super(message); this.status = status; }
}
const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
const clone = value => structuredClone(value);
const pathKey = value => process.platform === 'win32' ? path.resolve(value).toLowerCase() : path.resolve(value);
const inside = (parent, child) => { const rel = path.relative(pathKey(parent), pathKey(child)); return rel === '' || (!rel.startsWith('..' + path.sep) && rel !== '..' && !path.isAbsolute(rel)); };

function object(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new InputError('请求内容必须是 JSON 对象。');
  return value;
}
function text(value, label, limit, required = false) {
  if (typeof value !== 'string') throw new InputError(`${label}必须是文本。`);
  if (value.length > limit) throw new InputError(`${label}不能超过 ${limit} 个字符。`);
  if (value.includes('\0')) throw new InputError(`${label}包含无效字符。`);
  if (required && !value.trim()) throw new InputError(`${label}不能为空。`);
  return required ? value.trim() : value;
}
function bool(value, label) {
  if (typeof value !== 'boolean') throw new InputError(`${label}必须是布尔值。`);
  return value;
}
async function realDirectory(value) {
  text(value, '目录', 4096, true);
  const resolved = path.resolve(value);
  try {
    const actual = await fsp.realpath(resolved);
    if (!(await fsp.stat(actual)).isDirectory()) throw new Error('not a directory');
    return actual;
  } catch { throw new InputError('目录不存在或无法访问。'); }
}
function dateParts(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new InputError('日期格式应为 YYYY-MM-DD。');
  const [year, month, day] = value.split('-').map(Number);
  const check = new Date(Date.UTC(year, month - 1, day));
  if (year < 2000 || year > 2100 || check.getUTCFullYear() !== year || check.getUTCMonth() !== month - 1 || check.getUTCDate() !== day) throw new InputError('日期无效。');
  return { year, month, day };
}
function clockParts(value) {
  if (typeof value !== 'string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(value)) throw new InputError('时间格式应为 HH:mm。');
  const [hour, minute] = value.split(':').map(Number);
  return { hour, minute };
}

// All calendar operations use UTC getters on an offset date, independent of the host timezone.
export function nextScheduleRun(schedule, after = Date.now()) {
  if (!schedule.enabled) return null;
  const { hour, minute } = clockParts(schedule.time);
  if (schedule.cadence === 'once') {
    const { year, month, day } = dateParts(schedule.date);
    const candidate = Date.UTC(year, month - 1, day, hour, minute) - ZONE_OFFSET;
    return candidate > after ? candidate : null;
  }
  const local = new Date(after + ZONE_OFFSET);
  for (let offset = 0; offset < 8; offset++) {
    const candidateLocal = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate() + offset, hour, minute);
    const weekday = new Date(candidateLocal).getUTCDay();
    if (schedule.cadence === 'weekdays' && (weekday === 0 || weekday === 6)) continue;
    if (schedule.cadence === 'weekly' && weekday !== schedule.weekday) continue;
    const candidate = candidateLocal - ZONE_OFFSET;
    if (candidate > after) return candidate;
  }
  return null;
}

function safeError(error) {
  return String(error?.message || error || '任务执行失败。')
    .replace(/sk-[\w-]+/g, '[redacted]')
    .replace(/(Bearer\s+|(?:access_token|refresh_token|api_key|auth_token)["\s:=]+)[^\s,"}]+/gi, '$1[redacted]').slice(0, 400);
}
function artifactKind(ext) {
  if (['png', 'jpg', 'jpeg', 'webp', 'gif', 'avif', 'svg'].includes(ext)) return 'image';
  if (['mp4', 'webm', 'mov'].includes(ext)) return 'video';
  if (['mp3', 'wav', 'ogg'].includes(ext)) return 'audio';
  if (['html', 'htm'].includes(ext)) return 'web';
  return 'document';
}

function mcpServersInput(value) {
  object(value);
  const entries = Object.entries(value);
  if (entries.length > 50) throw new InputError('最多配置 50 个 MCP 服务。');
  const map = {};
  const strings = (input, label, limit = 4096) => {
    object(input);
    if (Object.keys(input).length > 100) throw new InputError(`${label}最多包含 100 项。`);
    return Object.fromEntries(Object.entries(input).map(([key, item]) => [text(key, `${label}名称`, 256, true), text(item, label, limit)]));
  };
  for (const [name, raw] of entries) {
    if (!/^[\w-]{1,128}$/.test(name) || ['__proto__', 'constructor', 'prototype'].includes(name)) throw new InputError('MCP 服务名称只能包含字母、数字、下划线和短横线。');
    object(raw);
    const type = raw.type || (raw.url ? 'http' : 'stdio');
    if (!['stdio', 'http', 'sse'].includes(type)) throw new InputError('MCP 类型应为 stdio、http 或 sse。');
    const server = { type };
    if (type === 'stdio') {
      server.command = text(raw.command, 'MCP 命令', 4096, true);
      if (own(raw, 'args')) {
        if (!Array.isArray(raw.args) || raw.args.length > 100) throw new InputError('MCP 参数应为最多 100 项的文本数组。');
        server.args = raw.args.map(arg => text(arg, 'MCP 参数', 4096));
      }
      if (own(raw, 'env')) server.env = strings(raw.env, 'MCP 环境变量');
    } else {
      server.url = text(raw.url, 'MCP URL', 4096, true);
      let target;
      try { target = new URL(server.url); } catch { throw new InputError('MCP URL 无效。'); }
      if (!['http:', 'https:'].includes(target.protocol)) throw new InputError('MCP URL 必须使用 HTTP 或 HTTPS。');
      if (own(raw, 'headers')) server.headers = strings(raw.headers, 'MCP 请求头');
    }
    map[name] = server;
  }
  if (JSON.stringify(map).length > 200000) throw new InputError('MCP 配置不能超过 200000 个字符。');
  return map;
}

export function createStudioFeatures({ dataDir, getSessions = () => [], onScheduleRun, onChange = () => {} }) {
  if (typeof dataDir !== 'string' || !dataDir) throw new Error('Studio features requires dataDir.');
  fs.mkdirSync(dataDir, { recursive: true });
  const stateFile = path.join(dataDir, 'features.json');
  const defaults = { version: VERSION, projects: [], schedules: [], customization: { instructions: '', memory: '', language: 'zh-CN', skills: [], mcpServers: {}, chromeEnabled: false }, activity: [] };
  let state = clone(defaults);
  if (fs.existsSync(stateFile)) {
    if (fs.statSync(stateFile).size > 3 * 1024 * 1024) throw new Error('features.json 超过允许大小，请先备份并检查文件。');
    let saved;
    try { saved = JSON.parse(fs.readFileSync(stateFile, 'utf8')); }
    catch { throw new Error('features.json 无法解析；原文件已保留，请备份后修复。'); }
    if (!saved || typeof saved !== 'object' || !Array.isArray(saved.projects) || !Array.isArray(saved.schedules)) throw new Error('features.json 格式无效；原文件已保留。');
    state = { ...defaults, ...saved, version: VERSION, customization: { ...defaults.customization, ...saved.customization }, activity: Array.isArray(saved.activity) ? saved.activity.slice(0, 200) : [] };
    if (!Array.isArray(state.customization.skills)) state.customization.skills = [];
  }
  let transactionQueue = Promise.resolve();
  let interval = null, ticking = false, closed = false;
  const activeRuns = new Set();
  const snapshot = () => clone({ ...state, version: VERSION });
  function notify() { try { onChange(snapshot()); } catch {} }
  function activity(draft, type, title, extra = {}) {
    draft.activity.unshift({ id: randomUUID(), type, title, at: Date.now(), ...extra });
    draft.activity = draft.activity.slice(0, 200);
  }
  async function persist(draft) {
    const temporary = stateFile + '.tmp-' + randomUUID();
    try {
      await fsp.writeFile(temporary, JSON.stringify(draft, null, 2), { mode: 0o600 });
      await fsp.rename(temporary, stateFile);
    } finally { await fsp.unlink(temporary).catch(() => {}); }
  }
  function mutate(change) {
    const operation = transactionQueue.then(async () => {
      const draft = clone(state);
      const result = await change(draft);
      await persist(draft);
      state = draft;
      notify();
      return clone(result);
    });
    transactionQueue = operation.catch(() => {});
    return operation;
  }
  function find(draft, collection, id) {
    const item = draft[collection].find(value => value.id === id);
    if (!item) throw new InputError('未找到该项目或任务。', 404);
    return item;
  }
  async function projectInput(input, existing) {
    object(input);
    const result = existing ? { ...existing } : { id: randomUUID(), name: '', path: '', description: '', instructions: '', createdAt: Date.now() };
    if (own(input, 'name')) result.name = text(input.name, '项目名称', 120, true);
    if (own(input, 'path')) result.path = await realDirectory(input.path);
    if (own(input, 'description')) result.description = text(input.description, '项目说明', 2000);
    if (own(input, 'instructions')) result.instructions = text(input.instructions, '项目指令', 16000);
    if (!result.name || !result.path) throw new InputError('项目需要名称和实际工作目录。');
    return result;
  }
  async function scheduleInput(input, existing) {
    object(input);
    const result = existing ? { ...existing } : { id: randomUUID(), name: '', prompt: '', cwd: '', model: 'sonnet', cadence: 'daily', time: '09:00', date: '', weekday: 1, enabled: true, nextRunAt: null, lastRunAt: null, lastStatus: null, lastSessionId: null, createdAt: Date.now(), timezone: 'Asia/Shanghai' };
    if (own(input, 'name')) result.name = text(input.name, '任务名称', 120, true);
    if (own(input, 'prompt')) result.prompt = text(input.prompt, '任务内容', 16000, true);
    if (own(input, 'cwd')) result.cwd = await realDirectory(input.cwd);
    if (own(input, 'model')) { if (!MODELS.has(input.model)) throw new InputError('模型应为 sonnet、opus 或 haiku。'); result.model = input.model; }
    if (own(input, 'cadence')) { if (!CADENCES.has(input.cadence)) throw new InputError('不支持该重复方式。'); result.cadence = input.cadence; }
    if (own(input, 'time')) { clockParts(input.time); result.time = input.time; }
    if (own(input, 'date')) { if (input.date !== '') dateParts(input.date); result.date = input.date; }
    if (own(input, 'weekday')) { if (!Number.isInteger(input.weekday) || input.weekday < 0 || input.weekday > 6) throw new InputError('星期必须在 0 到 6 之间。'); result.weekday = input.weekday; }
    if (own(input, 'enabled')) result.enabled = bool(input.enabled, '启用状态');
    if (!result.name || !result.prompt || !result.cwd) throw new InputError('任务需要名称、内容和实际工作目录。');
    if (result.cadence === 'once') dateParts(result.date);
    const timingChanged = !existing || ['cadence', 'time', 'date', 'weekday', 'enabled'].some(key => own(input, key) && input[key] !== existing[key]);
    if (timingChanged) result.nextRunAt = nextScheduleRun(result);
    if (result.enabled && result.cadence === 'once' && timingChanged && result.nextRunAt === null) throw new InputError('一次性任务的时间必须晚于现在（北京时间）。');
    result.timezone = 'Asia/Shanghai';
    return result;
  }
  function customizationInput(input, existing) {
    object(input);
    const result = { ...existing };
    for (const [key, label, limit] of [['instructions', '个人指令', 20000], ['memory', '记忆', 100000], ['language', '语言', 64]]) {
      if (own(input, key)) result[key] = text(input[key], label, limit, key === 'language');
    }
    if (own(input, 'skills')) {
      if (!Array.isArray(input.skills) || input.skills.length > 50) throw new InputError('技能必须是数组，且最多 50 个。');
      const ids = new Set();
      let total = 0;
      result.skills = input.skills.map(skill => {
        object(skill);
        const id = own(skill, 'id') ? text(skill.id, '技能 ID', 128, true) : randomUUID();
        if (ids.has(id)) throw new InputError('技能 ID 不能重复。');
        ids.add(id);
        const content = text(skill.content, '技能内容', 32000, true);
        total += content.length;
        return { id, name: text(skill.name, '技能名称', 120, true), content, enabled: own(skill, 'enabled') ? bool(skill.enabled, '技能启用状态') : true };
      });
      if (total > 200000) throw new InputError('技能内容合计不能超过 200000 个字符。');
    }
    if (own(input, 'mcpServers')) result.mcpServers = mcpServersInput(input.mcpServers);
    if (own(input, 'chromeEnabled')) result.chromeEnabled = bool(input.chromeEnabled, '浏览器集成');
    return result;
  }

  async function runSchedule(id, automatic = false, expectedRunAt = null) {
    if (typeof onScheduleRun !== 'function') throw new InputError('任务执行服务尚未连接。', 503);
    if (activeRuns.has(id)) throw new InputError('这个任务正在启动，请稍后再试。', 409);
    activeRuns.add(id);
    let schedule;
    try {
      schedule = await mutate(draft => {
        const item = find(draft, 'schedules', id);
        if (automatic && (!item.enabled || item.nextRunAt !== expectedRunAt || item.nextRunAt > Date.now())) return null;
        const now = Date.now();
        item.lastRunAt = now;
        item.lastStatus = 'running';
        item.lastError = null;
        // Consume the occurrence before dispatch, so a restart cannot repeat a claimed run.
        if (automatic) {
          item.nextRunAt = nextScheduleRun(item, now);
          if (item.cadence === 'once') item.enabled = false;
        }
        activity(draft, 'schedule_run', item.name, { scheduleId: id, status: 'running', automatic });
        return item;
      });
      if (!schedule) return null;
      await realDirectory(schedule.cwd);
      const started = await onScheduleRun(clone(schedule));
      const sessionId = typeof started === 'string' ? started : started?.sessionId;
      if (typeof sessionId !== 'string' || !sessionId || sessionId.length > 256) throw new Error('任务执行器没有返回有效的会话 ID。');
      const updated = await mutate(draft => {
        const item = draft.schedules.find(value => value.id === id);
        if (item) { item.lastStatus = 'started'; item.lastSessionId = sessionId; item.lastError = null; }
        activity(draft, 'schedule_started', schedule.name, { scheduleId: id, sessionId, status: 'started', automatic });
        return item || schedule;
      });
      return { schedule: updated, sessionId };
    } catch (error) {
      if (schedule) await mutate(draft => {
        const item = draft.schedules.find(value => value.id === id);
        if (item) { item.lastStatus = 'failed'; item.lastError = safeError(error); }
        activity(draft, 'schedule_failed', schedule.name, { scheduleId: id, status: 'failed', error: safeError(error), automatic });
        return null;
      }).catch(() => {});
      throw error;
    } finally { activeRuns.delete(id); }
  }
  async function tick() {
    if (ticking || closed) return;
    ticking = true;
    try {
      const due = state.schedules.filter(item => item.enabled && Number.isFinite(item.nextRunAt) && item.nextRunAt <= Date.now()).slice(0, 10);
      for (const scheduled of due) {
        if (closed) break;
        if (Date.now() - scheduled.nextRunAt > LATE_GRACE_MS) {
          await mutate(draft => {
            const item = draft.schedules.find(value => value.id === scheduled.id);
            if (!item || !item.enabled || item.nextRunAt !== scheduled.nextRunAt) return null;
            item.lastStatus = 'skipped';
            item.nextRunAt = nextScheduleRun(item);
            if (item.cadence === 'once') item.enabled = false;
            activity(draft, 'schedule_skipped', item.name, { scheduleId: item.id, status: 'skipped' });
            return null;
          });
        } else await runSchedule(scheduled.id, true, scheduled.nextRunAt).catch(() => {});
      }
    } catch {} finally { ticking = false; }
  }

  async function artifacts(url) {
    const requestedProject = url.searchParams.get('projectId');
    const requestedPath = url.searchParams.get('path');
    let roots = [];
    if (requestedProject) {
      const project = state.projects.find(item => item.id === requestedProject);
      if (!project) throw new InputError('项目不存在。', 404);
      roots = [{ path: await realDirectory(project.path), projectId: project.id }];
    } else if (requestedPath) {
      const actual = await realDirectory(requestedPath);
      roots = [{ path: actual, projectId: state.projects.find(item => pathKey(item.path) === pathKey(actual))?.id || null }];
    } else {
      roots = state.projects.map(item => ({ path: item.path, projectId: item.id }));
      const sessions = getSessions();
      for (const session of (Array.isArray(sessions) ? sessions : Object.values(sessions || {}))) {
        if (typeof session?.cwd === 'string' && !roots.some(root => pathKey(root.path) === pathKey(session.cwd))) roots.push({ path: session.cwd, projectId: null });
      }
      roots = roots.slice(0, 20);
    }
    const result = [], seen = new Set();
    let inspected = 0;
    const add = async (filename, projectId) => {
      const name = path.basename(filename), ext = path.extname(name).slice(1).toLowerCase();
      if (!ARTIFACT_EXTS.has(ext) || name.startsWith('.') || OMIT_FILES.has(name.toLowerCase()) || /(?:credentials|secrets|access[-_]?token|refresh[-_]?token)/i.test(name)) return;
      const key = pathKey(filename);
      if (seen.has(key)) return;
      try {
        const stat = await fsp.lstat(filename);
        if (!stat.isFile() || stat.isSymbolicLink()) return;
        seen.add(key);
        result.push({ id: createHash('sha256').update(key).digest('hex').slice(0, 24), name, path: filename, ext, size: stat.size, mtime: stat.mtimeMs, projectId, kind: artifactKind(ext) });
      } catch {}
    };
    const walk = async (directory, projectId, depth) => {
      if (depth > 5 || result.length >= 2000 || inspected >= 10000) return;
      let entries;
      try {
        const stat = await fsp.lstat(directory);
        if (!stat.isDirectory() || stat.isSymbolicLink()) return;
        entries = await fsp.readdir(directory, { withFileTypes: true });
      } catch { return; }
      for (const entry of entries) {
        if (++inspected > 10000 || result.length >= 2000) break;
        if (entry.isSymbolicLink()) continue;
        const filename = path.join(directory, entry.name);
        if (entry.isFile()) await add(filename, projectId);
        else if (entry.isDirectory() && !entry.name.startsWith('.') && !OMIT_DIRS.has(entry.name.toLowerCase())) await walk(filename, projectId, depth + 1);
      }
    };
    for (const root of roots) {
      if (result.length >= 2000 || inspected >= 10000) break;
      let entries;
      try { entries = await fsp.readdir(root.path, { withFileTypes: true }); } catch { continue; }
      for (const entry of entries) {
        if (++inspected > 10000 || result.length >= 2000) break;
        if (entry.isFile() && !entry.isSymbolicLink()) await add(path.join(root.path, entry.name), root.projectId);
      }
      await walk(path.join(root.path, 'outputs'), root.projectId, 0);
    }
    return { artifacts: result.sort((a, b) => b.mtime - a.mtime), scannedAt: Date.now(), truncated: result.length >= 2000 || inspected >= 10000 };
  }

  async function handle(req, res, url, readBody, json) {
    if (!url.pathname.startsWith('/api/studio/')) return false;
    const parts = url.pathname.slice('/api/studio/'.length).split('/').filter(Boolean);
    const method = req.method;
    const reply = (code, value) => { json(res, code, value); return true; };
    try {
      if (parts[0] === 'state' && parts.length === 1 && method === 'GET') return reply(200, snapshot());
      if (parts[0] === 'artifacts' && parts.length === 1 && method === 'GET') return reply(200, await artifacts(url));
      if (parts[0] === 'projects' && parts.length <= 2) {
        if (parts.length === 1 && method === 'GET') return reply(200, { projects: clone(state.projects) });
        if (parts.length === 1 && method === 'POST') {
          const input = await readBody(req);
          const project = await mutate(async draft => {
            if (draft.projects.length >= 100) throw new InputError('最多保存 100 个项目。');
            const item = await projectInput(input);
            if (draft.projects.some(existing => pathKey(existing.path) === pathKey(item.path))) throw new InputError('这个目录已经加入项目。', 409);
            draft.projects.push(item); activity(draft, 'project_created', item.name, { projectId: item.id }); return item;
          });
          return reply(201, { project });
        }
        if (parts.length === 2 && ['PATCH', 'PUT'].includes(method)) {
          const input = await readBody(req);
          const project = await mutate(async draft => {
            const existing = find(draft, 'projects', parts[1]);
            const item = await projectInput(input, existing);
            if (draft.projects.some(other => other.id !== item.id && pathKey(other.path) === pathKey(item.path))) throw new InputError('这个目录已经加入项目。', 409);
            Object.assign(existing, item); activity(draft, 'project_updated', item.name, { projectId: item.id }); return item;
          });
          return reply(200, { project });
        }
        if (parts.length === 2 && method === 'DELETE') {
          await mutate(draft => { const item = find(draft, 'projects', parts[1]); draft.projects = draft.projects.filter(project => project.id !== item.id); activity(draft, 'project_deleted', item.name, { projectId: item.id }); return null; });
          return reply(200, { ok: true });
        }
      }
      if (parts[0] === 'schedules') {
        if (parts.length === 1 && method === 'GET') return reply(200, { schedules: clone(state.schedules), timezone: 'Asia/Shanghai' });
        if (parts.length === 1 && method === 'POST') {
          const input = await readBody(req);
          const schedule = await mutate(async draft => {
            if (draft.schedules.length >= 100) throw new InputError('最多保存 100 个计划任务。');
            const item = await scheduleInput(input); draft.schedules.push(item); activity(draft, 'schedule_created', item.name, { scheduleId: item.id }); return item;
          });
          return reply(201, { schedule });
        }
        if (parts.length === 2 && ['PATCH', 'PUT'].includes(method)) {
          const input = await readBody(req);
          const schedule = await mutate(async draft => { const item = find(draft, 'schedules', parts[1]); Object.assign(item, await scheduleInput(input, item)); activity(draft, 'schedule_updated', item.name, { scheduleId: item.id }); return item; });
          return reply(200, { schedule });
        }
        if (parts.length === 2 && method === 'DELETE') {
          await mutate(draft => { const item = find(draft, 'schedules', parts[1]); draft.schedules = draft.schedules.filter(schedule => schedule.id !== item.id); activity(draft, 'schedule_deleted', item.name, { scheduleId: item.id }); return null; });
          return reply(200, { ok: true });
        }
        if (parts.length === 3 && parts[2] === 'run' && method === 'POST') return reply(200, await runSchedule(parts[1]));
      }
      if (parts[0] === 'customization' && parts.length === 1) {
        if (method === 'GET') return reply(200, { customization: clone(state.customization) });
        if (method === 'PATCH') {
          const input = await readBody(req);
          const customization = await mutate(draft => { draft.customization = customizationInput(input, draft.customization); activity(draft, 'customization_updated', '更新个性化设置'); return draft.customization; });
          return reply(200, { customization });
        }
      }
      if (parts[0] === 'memory' && parts[1] === 'import' && parts.length === 2 && method === 'POST') {
        const input = object(await readBody(req));
        const filename = path.resolve(text(input.path, '文件路径', 4096, true));
        if (!['.txt', '.md', '.json'].includes(path.extname(filename).toLowerCase())) throw new InputError('请选择 TXT、Markdown 或 JSON 文件。');
        let handle;
        let memory;
        try {
          handle = await fsp.open(filename, 'r');
          const stat = await handle.stat();
          if (!stat.isFile() || stat.size > 1024 * 1024) throw new InputError('记忆文件必须是小于 1 MB 的文本文件。');
          // Read at most 1 MB even if the file grows after stat.
          const buffer = Buffer.alloc(Math.min(stat.size + 1, 1024 * 1024 + 1));
          const { bytesRead } = await handle.read(buffer, 0, buffer.length, 0);
          if (bytesRead > 1024 * 1024) throw new InputError('记忆文件不能超过 1 MB。');
          memory = new TextDecoder('utf-8', { fatal: true }).decode(buffer.subarray(0, bytesRead)).replace(/^\uFEFF/, '');
          if (path.extname(filename).toLowerCase() === '.json') {
            const parsed = JSON.parse(memory);
            memory = typeof parsed === 'string' ? parsed : (typeof parsed?.memory === 'string' ? parsed.memory : JSON.stringify(parsed, null, 2));
          }
          memory = text(memory, '记忆', 100000);
        } catch (error) { if (error instanceof InputError) throw error; throw new InputError('无法读取文件，请检查路径、JSON 格式和 UTF-8 编码。'); }
        finally { await handle?.close().catch(() => {}); }
        const customization = await mutate(draft => { draft.customization.memory = memory; activity(draft, 'memory_imported', '导入记忆文件'); return draft.customization; });
        return reply(200, { customization });
      }
      return reply(404, { error: '未找到该 Studio 功能接口。' });
    } catch (error) {
      if (error instanceof SyntaxError) return reply(400, { error: '请求必须包含有效的 JSON。' });
      return reply(error instanceof InputError ? error.status : 500, { error: error instanceof InputError ? error.message : safeError(error) });
    }
  }

  function getSystemPrompt(cwd, { useMemory = true } = {}) {
    const blocks = [];
    const custom = state.customization;
    const clipped = (value, limit) => value.length <= limit ? value : value.slice(0, limit) + '\n[Content trimmed to fit context.]';
    if (custom.language && custom.language !== 'auto') blocks.push(`Preferred response language: ${custom.language}`);
    if (custom.instructions?.trim()) blocks.push(`User preferences and instructions:\n${clipped(custom.instructions, 6000)}`);
    if (cwd) {
      let actual = path.resolve(cwd);
      try { actual = fs.realpathSync(actual); } catch {}
      const project = state.projects.filter(item => inside(item.path, actual)).sort((a, b) => b.path.length - a.path.length)[0];
      if (project?.instructions?.trim()) blocks.push(`Project instructions (${project.name}):\n${clipped(project.instructions, 6000)}`);
    }
    const skills = (custom.skills || []).filter(skill => skill.enabled && skill.content?.trim());
    const skillLimit = Math.min(6000, Math.floor(23000 / Math.max(skills.length, 1)));
    for (const skill of skills) blocks.push(`User skill: ${skill.name}\n${clipped(skill.content, skillLimit)}`);
    if (useMemory && custom.memory?.trim()) blocks.push(`User-provided memory and background:\n${clipped(custom.memory, 10000)}`);
    return blocks.join('\n\n').slice(0, 48000);
  }
  function start() {
    if (interval || closed) return;
    interval = setInterval(() => { void tick(); }, POLL_MS);
    interval.unref?.();
    void tick();
  }
  async function close() {
    closed = true;
    clearInterval(interval);
    interval = null;
    await transactionQueue;
  }
  const getMcpConfig = () => clone(state.customization.mcpServers || {});
  const getChromeEnabled = () => state.customization.chromeEnabled === true;
  const getRevision = () => createHash('sha256').update(JSON.stringify({ customization: state.customization, projects: state.projects.map(item => ({ path: item.path, name: item.name, instructions: item.instructions })) })).digest('hex').slice(0, 16);
  async function recordScheduleResult(id, sessionId, error) {
    try {
      await mutate(draft => {
        const item = draft.schedules.find(s => s.id === id && s.lastSessionId === sessionId);
        if (!item) return null;
        item.lastStatus = error ? 'failed' : 'completed'; item.lastEndedAt = Date.now(); item.lastError = error ? safeError(error) : null;
        activity(draft, 'schedule_finished', item.name, { scheduleId: id, sessionId, status: item.lastStatus, ...(error ? { error: safeError(error) } : {}) });
        return item;
      });
    } catch {}
  }
  return { handle, start, close, getSystemPrompt, getMcpConfig, getChromeEnabled, getRevision, recordScheduleResult };
}
