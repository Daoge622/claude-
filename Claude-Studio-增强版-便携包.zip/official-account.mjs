// Official subscription access is delegated to Claude Code, including credential storage.
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';

const WINDOW_TYPES = new Set(['five_hour', 'seven_day', 'seven_day_opus', 'seven_day_sonnet', 'seven_day_oauth_apps', 'seven_day_overage_included', 'overage']);
const AUTH_HOSTS = new Set(['claude.ai', 'console.anthropic.com', 'platform.claude.com']);

export function officialEnv(configDir, env = process.env) {
  const clean = { ...env };
  for (const name of Object.keys(clean)) {
    if (/^(ANTHROPIC_|CLAUDE_CODE_(?:OAUTH_TOKEN|USE_|SUBAGENT_MODEL|API_KEY|CUSTOM_MODEL)|CLAUDE_CONFIG_DIR$|CLAUDECODE$)/i.test(name)) delete clean[name];
  }
  return { ...clean, CLAUDE_CONFIG_DIR: configDir };
}

// Launch a native executable without cmd.exe argument interpolation (including empty settings sources).
export function findClaude(env = process.env) {
  const win = process.platform === 'win32';
  const dirs = (env.PATH || env.Path || '').split(path.delimiter).filter(Boolean).map(p => p.replace(/^"|"$/g, ''));
  for (const dir of dirs) {
    const candidates = win
      ? [path.join(dir, 'claude.exe'), path.join(dir, 'node_modules', '@anthropic-ai', 'claude-code', 'bin', 'claude.exe')]
      : [path.join(dir, 'claude')];
    for (const candidate of candidates) if (fs.existsSync(candidate)) return candidate;
  }
  throw new Error('未找到 Claude Code CLI，请先安装官方 Claude Code。');
}

export function normalizeRateLimits(info, now = Date.now()) {
  if (!info || typeof info !== 'object') return [];
  const result = [];
  const window = (type, data, status) => {
    if (!WINDOW_TYPES.has(type) || !data || typeof data !== 'object') return;
    const utilization = data.utilization;
    const resets = data.resetsAt;
    result.push({ type, status: status || (typeof utilization === 'number' && utilization >= 1 ? 'rejected' : 'allowed'),
      usedPercent: typeof utilization === 'number' && Number.isFinite(utilization) && utilization >= 0 ? utilization * 100 : null,
      resetsAt: typeof resets === 'number' && Number.isFinite(resets) && resets > 0 ? resets * 1000 : null, updatedAt: now });
  };
  for (const [type, data] of Object.entries(info.unifiedWindows || {})) window(type, data);
  // The top-level value describes the currently limiting window. Prefer the complete official windows.
  if (!result.some(w => w.type === info.rateLimitType)) window(info.rateLimitType, info, info.status);
  else if (info.status) result.find(w => w.type === info.rateLimitType).status = info.status;
  return result;
}

function safeError(value) {
  return String(value || '').replace(/sk-[\w-]+/g, '[redacted]').replace(/(Bearer\s+|(?:access_token|refresh_token|api_key|auth_token)["\s:=]+)[^\s,"}]+/gi, '$1[redacted]').slice(0, 600);
}

export function createOfficialAccount({ dataDir, onChange = () => {}, spawnCli = spawn, executable = findClaude }) {
  const configDir = path.join(dataDir, 'official-claude');
  const limitsFile = path.join(dataDir, 'official-limits.json');
  fs.mkdirSync(configDir, { recursive: true });
  // User/project relay settings are excluded; CLAUDE.md, tools and explicit Studio permissions still apply.
  const settingsArgs = ['--setting-sources', '', '--settings', JSON.stringify({ forceLoginMethod: 'claudeai', showThinkingSummaries: true })];
  let auth = { loggedIn: false, authMethod: 'none' }, authAt = 0, authPromise = null, error = null;
  let login = { status: 'idle' }, loginChild = null;
  let windows = [], updatedAt = null, usageError = null, usageAt = 0, usagePromise = null;
  let epoch = 0, logoutPending = false;
  const children = new Set();
  try {
    const saved = JSON.parse(fs.readFileSync(limitsFile, 'utf8'));
    windows = (saved.windows || []).filter(w => WINDOW_TYPES.has(w.type) && typeof w.updatedAt === 'number');
    updatedAt = saved.updatedAt || null;
  } catch {}

  function snapshot() {
    return { mode: 'official', isolated: true, ready: !logoutPending && login.status !== 'pending' && hasSubscriptionAuth(),
      auth, login: { ...login }, limits: { source: 'claude-code', updatedAt, windows: windows.filter(w => !w.resetsAt || w.resetsAt > Date.now()), ...(usageError ? { error: usageError } : {}) },
      usageUrl: 'https://claude.ai/settings/usage', ...(error ? { error } : {}) };
  }
  function hasSubscriptionAuth() { return !!auth.loggedIn && ['claude.ai', 'oauth_token'].includes(auth.authMethod) && (!auth.apiProvider || auth.apiProvider === 'firstParty'); }
  const changed = () => onChange(snapshot());
  function launch(args, opts = {}) {
    const child = spawnCli(executable(), [...settingsArgs, ...args], { cwd: configDir, env: officialEnv(configDir), windowsHide: true, ...opts });
    children.add(child); child.once('close', () => children.delete(child)); child.once('error', () => children.delete(child)); return child;
  }
  async function status(refresh = false) {
    if (authPromise) return authPromise;
    if (!refresh && authAt && Date.now() - authAt < 15000) return snapshot();
    const requestEpoch = epoch;
    const pending = new Promise(resolve => {
      let child, out = '', err = '', settled = false, timer;
      const finish = (code, failure) => {
        if (settled) return; settled = true; clearTimeout(timer);
        if (requestEpoch !== epoch) { resolve(snapshot()); return; }
        try {
          const parsed = JSON.parse(out);
          auth = { loggedIn: code === 0 && parsed.loggedIn === true, authMethod: typeof parsed.authMethod === 'string' ? parsed.authMethod : 'none', apiProvider: typeof parsed.apiProvider === 'string' ? parsed.apiProvider : null,
            ...(typeof parsed.email === 'string' ? { email: parsed.email } : {}), ...(typeof parsed.subscriptionType === 'string' ? { subscriptionType: parsed.subscriptionType } : {}) };
          error = code === 0 || code === 1 ? null : '无法检查官方登录状态。';
        } catch { auth = { loggedIn: false, authMethod: 'none' }; error = safeError(failure || err || '无法读取官方登录状态。'); }
        authAt = Date.now(); resolve(snapshot());
      };
      try {
        child = launch(['auth', 'status']);
        child.stdout.on('data', d => { out = (out + d).slice(-20000); });
        child.stderr.on('data', d => { err = (err + d).slice(-2000); });
        child.on('error', e => finish(-1, e.message));
        child.on('close', code => finish(code));
        timer = setTimeout(() => { child.kill(); finish(-1, '检查官方登录状态超时。'); }, 20000);
      } catch (e) { finish(-1, e.message); }
    });
    authPromise = pending;
    try { return await pending; } finally { if (authPromise === pending) authPromise = null; }
  }
  async function startLogin() {
    if (loginChild) return snapshot();
    const requestEpoch = ++epoch;
    authPromise = null; usagePromise = null; authAt = 0; usageAt = 0; auth = { loggedIn: false, authMethod: 'none' };
    windows = []; updatedAt = null;
    try { fs.unlinkSync(limitsFile); } catch {}
    login = { status: 'pending' }; error = null; changed();
    let child, timer, buffer = '', settled = false;
    const finish = async (code, failure) => {
      if (settled) return; settled = true; clearTimeout(timer);
      if (requestEpoch !== epoch) return;
      loginChild = null;
      const account = await status(true);
      if (requestEpoch !== epoch) return;
      login = hasSubscriptionAuth() ? { status: 'complete' } : { status: 'error', error: safeError(failure || (code === 0 ? '登录尚未完成，请重试官方登录。' : '官方登录未完成或已取消，请重试。')) };
      if (hasSubscriptionAuth()) await refreshUsage(true);
      if (requestEpoch !== epoch) return;
      changed();
    };
    try {
      child = launch(['auth', 'login', '--claudeai']); loginChild = child;
      const output = d => {
        if (requestEpoch !== epoch) return;
        buffer = (buffer + d.toString()).slice(-16000);
        for (const match of buffer.matchAll(/https:\/\/[^\s<>"\x1b]+/g)) {
          try {
            const url = new URL(match[0]);
            if (AUTH_HOSTS.has(url.hostname) && !url.port && !url.username && !url.password && url.pathname === '/oauth/authorize' && login.url !== url.href) { login.url = url.href; changed(); }
          } catch {}
        }
      };
      child.stdout.on('data', output); child.stderr.on('data', output);
      child.on('error', e => finish(-1, e.message));
      child.on('close', code => finish(code));
      timer = setTimeout(() => { child.kill(); finish(-1, '官方登录超时，请重新登录。'); }, 10 * 60 * 1000);
    } catch (e) { await finish(-1, e.message); }
    return snapshot();
  }
  function submitCode(code) {
    if (!loginChild?.stdin?.writable) throw new Error('没有正在进行的官方登录。');
    if (typeof code !== 'string' || !code.trim() || code.length > 4096 || /[\r\n]/.test(code)) throw new Error('请输入浏览器返回的单行授权码。');
    loginChild.stdin.write(code.trim() + '\n');
    return snapshot();
  }
  function acceptRateLimit(info) {
    const updates = normalizeRateLimits(info);
    if (!updates.length) return;
    for (const update of updates) { const i = windows.findIndex(w => w.type === update.type); if (i < 0) windows.push(update); else windows[i] = update; }
    updatedAt = Date.now();
    fs.writeFileSync(limitsFile + '.tmp', JSON.stringify({ updatedAt, windows }));
    fs.renameSync(limitsFile + '.tmp', limitsFile);
    changed();
  }
  // Claude Code 2.1.283: local get_usage control request, no user/model message and no token charge.
  async function refreshUsage(force = false) {
    if (usagePromise) return usagePromise;
    if (!snapshot().ready || (!force && usageAt && Date.now() - usageAt < 60000)) return snapshot();
    const requestEpoch = epoch;
    const pending = new Promise(resolve => {
      let child, buffer = '', usage = null, settled = false, timer;
      const finish = (code, failure) => {
        if (settled) return; settled = true; clearTimeout(timer);
        if (requestEpoch !== epoch) { resolve(snapshot()); return; }
        usageAt = Date.now();
        if (code === 0 && usage) {
          if (typeof usage.subscription_type === 'string') auth.subscriptionType = usage.subscription_type;
          if (usage.rate_limits_available && usage.rate_limits) {
            const now = Date.now(), fresh = [];
            for (const type of WINDOW_TYPES) {
              const raw = usage.rate_limits[type]; if (!raw || typeof raw !== 'object') continue;
              const usedPercent = typeof raw.utilization === 'number' && Number.isFinite(raw.utilization) && raw.utilization >= 0 ? raw.utilization : null;
              const reset = typeof raw.resets_at === 'string' ? Date.parse(raw.resets_at) : NaN;
              fresh.push({ type, usedPercent, resetsAt: Number.isFinite(reset) ? reset : null, status: usedPercent >= 100 ? 'rejected' : 'allowed', updatedAt: now });
            }
            windows = fresh; updatedAt = now; usageError = null;
            fs.writeFileSync(limitsFile + '.tmp', JSON.stringify({ updatedAt, windows }));
            fs.renameSync(limitsFile + '.tmp', limitsFile);
          } else usageError = '官方暂未返回可读取的订阅限额，可打开官方 Usage 页面查看。';
        } else usageError = safeError(failure || '无法刷新官方限额，请稍后重试或打开官方 Usage 页面。');
        changed(); resolve(snapshot());
      };
      try {
        child = launch(['--print', '--input-format', 'stream-json', '--output-format', 'stream-json', '--verbose', '--no-session-persistence']);
        child.stdout.on('data', d => {
          buffer += d.toString(); let index;
          while ((index = buffer.indexOf('\n')) >= 0) {
            const line = buffer.slice(0, index); buffer = buffer.slice(index + 1);
            try { const m = JSON.parse(line); if (m.type === 'control_response' && m.response?.request_id === 'studio-usage' && m.response?.subtype === 'success') usage = m.response.response; } catch {}
          }
          if (buffer.length > 1024 * 1024) { child.kill(); finish(-1, '官方 CLI 返回的数据过大。'); }
        });
        // Never forward raw stderr or CLI credential payloads to the browser.
        child.stderr.on('data', () => {});
        child.on('error', e => finish(-1, e.message)); child.on('close', code => finish(code));
        timer = setTimeout(() => { child.kill(); finish(-1, '刷新官方限额超时，请重试。'); }, 25000);
        child.stdin.end(JSON.stringify({ type: 'control_request', request_id: 'studio-init', request: { subtype: 'initialize', hooks: {} } }) + '\n'
          + JSON.stringify({ type: 'control_request', request_id: 'studio-usage', request: { subtype: 'get_usage', skip_behaviors: true } }) + '\n');
      } catch (e) { finish(-1, e.message); }
    });
    usagePromise = pending;
    try { return await pending; } finally { if (usagePromise === pending) usagePromise = null; }
  }
  async function getAccount(refresh = false) { await status(refresh); await refreshUsage(refresh); return snapshot(); }
  async function logout() {
    ++epoch; logoutPending = true; authPromise = null; usagePromise = null;
    if (loginChild) { const child = loginChild; loginChild = null; child.kill(); }
    const result = await new Promise(resolve => {
      let child, timer, settled = false;
      const finish = code => { if (settled) return; settled = true; clearTimeout(timer); resolve(code); };
      try { child = launch(['auth', 'logout']); child.stdout.on('data', () => {}); child.stderr.on('data', () => {}); child.on('error', () => finish(-1)); child.on('close', finish); timer = setTimeout(() => { child.kill(); finish(-1); }, 20000); }
      catch { finish(-1); }
    });
    logoutPending = false;
    if (result !== 0) throw new Error('官方登出失败，请重试。');
    auth = { loggedIn: false, authMethod: 'none' }; authAt = Date.now(); login = { status: 'idle' }; windows = []; updatedAt = null; usageError = null; usageAt = 0;
    try { fs.unlinkSync(limitsFile); } catch {}
    changed(); return snapshot();
  }
  return { configDir, settingsArgs, env: () => officialEnv(configDir), executable, status, getAccount, refreshUsage, snapshot, startLogin, submitCode, acceptRateLimit, logout,
    close: () => { ++epoch; for (const child of children) child.kill(); } };
}
