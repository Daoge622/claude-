// Reads user-selected official exports and local Claude Code transcripts, without cloud cookies/tokens.
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { inflateRawSync } from 'node:zlib';

const MAX_BYTES = 128 * 1024 * 1024;
const hash = text => crypto.createHash('sha256').update(text).digest('hex');
const epoch = (value, fallback = Date.now()) => { const parsed = typeof value === 'number' ? value : Date.parse(value); return Number.isFinite(parsed) ? parsed : fallback; };
const title = text => String(text || '导入的对话').replace(/\s+/g, ' ').slice(0, 120);
function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) { crc ^= byte; for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0); }
  return (crc ^ 0xffffffff) >>> 0;
}
function zipConversations(buffer) {
  let end = -1;
  for (let i = buffer.length - 22; i >= Math.max(0, buffer.length - 65557); i--) {
    if (buffer.readUInt32LE(i) === 0x06054b50 && i + 22 + buffer.readUInt16LE(i + 20) === buffer.length) { end = i; break; }
  }
  if (end < 0) throw new Error('ZIP 文件不完整。');
  if (buffer.readUInt16LE(end + 4) || buffer.readUInt16LE(end + 6)) throw new Error('不支持分卷 ZIP。');
  const count = buffer.readUInt16LE(end + 10), offset = buffer.readUInt32LE(end + 16);
  if (count === 65535 || offset === 0xffffffff) throw new Error('导出包过大，请选择解压后的 conversations.json。');
  let cursor = offset, found = null;
  for (let i = 0; i < count; i++) {
    if (cursor + 46 > end || buffer.readUInt32LE(cursor) !== 0x02014b50) throw new Error('ZIP 文件索引无效。');
    const flags = buffer.readUInt16LE(cursor + 8), method = buffer.readUInt16LE(cursor + 10);
    const checksum = buffer.readUInt32LE(cursor + 16), compressed = buffer.readUInt32LE(cursor + 20), size = buffer.readUInt32LE(cursor + 24);
    const nameLength = buffer.readUInt16LE(cursor + 28), extraLength = buffer.readUInt16LE(cursor + 30), commentLength = buffer.readUInt16LE(cursor + 32), local = buffer.readUInt32LE(cursor + 42);
    if (cursor + 46 + nameLength + extraLength + commentLength > end) throw new Error('ZIP 文件索引截断。');
    const name = buffer.subarray(cursor + 46, cursor + 46 + nameLength).toString('utf8').replace(/\\/g, '/');
    if (name.split('/').at(-1)?.toLowerCase() === 'conversations.json') {
      if (found) throw new Error('ZIP 中包含多个 conversations.json，请单独选择需要导入的 JSON。');
      if ((flags & 1) || ![0, 8].includes(method)) throw new Error('不支持加密或该压缩方式的 ZIP。');
      if (size > MAX_BYTES || compressed > MAX_BYTES || local + 30 > offset || buffer.readUInt32LE(local) !== 0x04034b50) throw new Error('导出记录过大或 ZIP 条目无效。');
      const start = local + 30 + buffer.readUInt16LE(local + 26) + buffer.readUInt16LE(local + 28);
      if (start + compressed > offset) throw new Error('ZIP 文件内容截断。');
      const input = buffer.subarray(start, start + compressed);
      const output = method === 0 ? Buffer.from(input) : inflateRawSync(input, { maxOutputLength: MAX_BYTES });
      if (output.length !== size || crc32(output) !== checksum) throw new Error('conversations.json 校验失败，请重新下载官方导出包。');
      found = output;
    }
    cursor += 46 + nameLength + extraLength + commentLength;
  }
  if (!found) throw new Error('ZIP 中没有 conversations.json，请选择官方聊天数据导出包。');
  return found;
}
function plain(content) {
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return '';
  return content.map(block => {
    if (typeof block === 'string') return block;
    if (block?.type === 'text') return block.text || '';
    if (block?.type === 'thinking') return '';
    if (block?.type === 'image') return '[历史图片：原文件未包含在文字记录中]';
    if (block?.type === 'document') return block.text || block.source?.data && block.source?.type === 'text' ? String(block.text || block.source.data) : '[历史文档]';
    return '';
  }).filter(Boolean).join('\n');
}
function message(raw, fallback, index) {
  if (!raw || typeof raw !== 'object') return null;
  const role = ['human', 'user'].includes(raw.sender || raw.role) ? 'user' : (raw.sender || raw.role) === 'assistant' ? 'assistant' : null;
  if (!role) return null;
  let text = typeof raw.text === 'string' && raw.text ? raw.text : plain(raw.content);
  for (const attachment of [...(Array.isArray(raw.attachments) ? raw.attachments : []), ...(Array.isArray(raw.files) ? raw.files : [])]) {
    const name = attachment.file_name || attachment.filename || attachment.name || '附件';
    const extracted = attachment.extracted_content || attachment.text;
    text += `\n[历史附件：${name}${typeof extracted === 'string' && extracted ? '\n' + extracted : '，原始文件需另行提供'}]`;
  }
  if (!text.trim()) return null;
  const at = epoch(raw.created_at || raw.timestamp, fallback + index);
  const sourceMessageId = typeof raw.uuid === 'string' ? raw.uuid : typeof raw.id === 'string' ? raw.id : hash(role + '\0' + at + '\0' + text);
  return role === 'user' ? { role, text, at, sourceMessageId, importedMessage: true, attachments: [] }
    : { role, blocks: [{ type: 'text', text }], startedAt: at, done: true, sourceMessageId, importedMessage: true, ...(typeof raw.model === 'string' ? { model: raw.model } : {}) };
}
export function parseClaudeExport(buffer, filename = 'conversations.json') {
  if (!Buffer.isBuffer(buffer) || buffer.length > MAX_BYTES) throw new Error('导入文件最多支持 128 MB。');
  const json = /\.zip$/i.test(filename) || buffer.length >= 4 && buffer.readUInt32LE(0) === 0x04034b50 ? zipConversations(buffer) : buffer;
  let parsed; try { parsed = JSON.parse(json.toString('utf8').replace(/^\uFEFF/, '')); } catch { throw new Error('无法解析聊天记录，请选择官方 ZIP 或 conversations.json。'); }
  const records = Array.isArray(parsed) ? parsed : parsed?.conversations;
  if (!Array.isArray(records) || records.length > 10000) throw new Error('导出数据必须包含 conversations 数组，且最多支持 10000 个对话。');
  const normalized = [];
  for (const raw of records) {
    if (!raw || typeof raw !== 'object') throw new Error('导出数据中存在无效对话。');
    const sourceMessages = raw.chat_messages || raw.messages;
    if (!Array.isArray(sourceMessages) || sourceMessages.length > 20000) throw new Error('导出数据缺少 chat_messages，或单个对话消息过多。');
    const createdAt = epoch(raw.created_at || raw.createdAt, 0);
    const seen = new Set();
    const messages = sourceMessages.map((m, i) => message(m, createdAt, i)).filter(m => m && !seen.has(m.sourceMessageId) && (seen.add(m.sourceMessageId), true));
    if (!messages.length) continue;
    const sourceId = typeof raw.uuid === 'string' && raw.uuid ? raw.uuid : typeof raw.id === 'string' && raw.id ? raw.id : hash(String(raw.name || raw.title || '') + createdAt + messages[0].sourceMessageId);
    const updatedAt = epoch(raw.updated_at || raw.updatedAt, Math.max(...messages.map(m => m.at || m.startedAt || createdAt)));
    normalized.push({ historySource: 'claude-web', historySourceId: sourceId, title: title(raw.name || raw.title || messages[0].text), createdAt, updatedAt,
      messages, ...( /^[\da-f-]{36}$/i.test(sourceId) ? { historyUrl: 'https://claude.ai/chat/' + sourceId } : {}) });
  }
  return normalized;
}
export async function readClaudeExport({ path: file, filename, data }) {
  let buffer;
  if (file) {
    if (typeof file !== 'string' || !/\.(zip|json)$/i.test(file)) throw new Error('请选择 ZIP 或 JSON 文件。');
    const stat = await fs.stat(file); if (!stat.isFile() || stat.size > MAX_BYTES) throw new Error('文件无效或超过 128 MB。');
    buffer = await fs.readFile(file); filename = path.basename(file);
  } else {
    if (typeof filename !== 'string' || !/\.(zip|json)$/i.test(filename) || typeof data !== 'string' || data.length > Math.ceil(MAX_BYTES * 4 / 3) + 4 || !/^[A-Za-z0-9+/]*={0,2}$/.test(data)) throw new Error('请选择有效的 ZIP 或 JSON 导出文件。');
    buffer = Buffer.from(data, 'base64');
  }
  return parseClaudeExport(buffer, filename);
}
export function parseCliTranscript(text, sourceFile) {
  const records = [];
  for (const line of text.split(/\r?\n/)) { if (!line.trim()) continue; try { records.push(JSON.parse(line)); } catch {} }
  const rows = records.filter(r => !r.isSidechain && ['user', 'assistant'].includes(r.type) && r.message);
  const first = rows.find(r => r.type === 'user'); if (!first) return null;
  // Internal verification chats are excluded from the user-facing history.
  if (String(first.cwd || '').replace(/\\/g, '/').endsWith('/work/checks/model-empty-workspace')) return null;
  const messages = [], seen = new Map(), tools = new Map();
  for (const row of rows) {
    const blocks = Array.isArray(row.message.content) ? row.message.content : [];
    for (const block of blocks) if (block.type === 'tool_result' && tools.has(block.tool_use_id)) {
      const tool = tools.get(block.tool_use_id); tool.result = plain(block.content) || (typeof block.content === 'string' ? block.content : ''); tool.status = block.is_error ? 'error' : 'done';
    }
    const converted = message({ ...row.message, uuid: row.uuid || row.message.id, timestamp: row.timestamp }, 0, messages.length);
    if (row.type === 'assistant') {
      const assistantBlocks = blocks.filter(b => ['text', 'tool_use'].includes(b.type)).map(b => b.type === 'text' ? { type: 'text', text: b.text || '' }
        : { type: 'tool', id: b.id, name: b.name, input: b.input || {}, status: 'done', result: null, startedAt: epoch(row.timestamp, 0) });
      if (!converted && assistantBlocks.length) {
        const at = epoch(row.timestamp, 0), id = row.uuid || row.message.id || hash(JSON.stringify(assistantBlocks));
        const m = { role: 'assistant', blocks: assistantBlocks, startedAt: at, done: true, sourceMessageId: id, importedMessage: true, model: row.message.model };
        for (const b of assistantBlocks) if (b.id) tools.set(b.id, b);
        if (!seen.has(id)) { seen.set(id, m); messages.push(m); } continue;
      }
      if (converted) { converted.blocks = assistantBlocks; converted.model = row.message.model; for (const b of assistantBlocks) if (b.id) tools.set(b.id, b); }
    }
    if (!converted) continue;
    const old = seen.get(converted.sourceMessageId);
    if (old) { if (converted.role === 'assistant') Object.assign(old, converted); continue; }
    seen.set(converted.sourceMessageId, converted); messages.push(converted);
  }
  if (!messages.length) return null;
  const sourceId = first.sessionId || path.basename(sourceFile, '.jsonl');
  const custom = [...records].reverse().find(r => r.type === 'custom-title' && typeof r.customTitle === 'string');
  const createdAt = Math.min(...messages.map(m => m.at || m.startedAt || 0)), updatedAt = Math.max(...messages.map(m => m.at || m.startedAt || 0));
  return { historySource: 'claude-code', historySourceId: sourceId, title: title(custom?.customTitle || first.message.content && plain(first.message.content)),
    cwd: typeof first.cwd === 'string' ? first.cwd : os.homedir(), createdAt, updatedAt, messages };
}
export async function scanCliHistory(roots) {
  const sessions = [], errors = []; let scanned = 0;
  for (const root of roots) {
    let projects; try { projects = await fs.readdir(root, { withFileTypes: true }); } catch (e) { if (e.code !== 'ENOENT') errors.push('无法读取历史目录：' + root); continue; }
    for (const project of projects) {
      if (!project.isDirectory() || project.isSymbolicLink()) continue;
      const directory = path.join(root, project.name); let files; try { files = await fs.readdir(directory, { withFileTypes: true }); } catch { continue; }
      for (const file of files) {
        if (!file.isFile() || !file.name.endsWith('.jsonl')) continue;
        if (++scanned > 1000) return { sessions, scanned, errors: [...errors, '历史文件超过 1000 个，本次已达到扫描上限。'] };
        try { const absolute = path.join(directory, file.name), stat = await fs.stat(absolute); if (stat.size > MAX_BYTES) { errors.push('记录文件过大：' + file.name); continue; }
          const session = parseCliTranscript(await fs.readFile(absolute, 'utf8'), absolute); if (session) sessions.push(session);
        } catch { errors.push('无法读取历史文件：' + file.name); }
      }
    }
  }
  return { sessions, scanned, errors };
}
