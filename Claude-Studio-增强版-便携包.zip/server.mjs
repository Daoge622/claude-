// Claude Studio — 本地 Web UI，后端驱动 Claude Code CLI（stream-json 协议）
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { spawn, execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createOfficialAccount } from './official-account.mjs';
import { createStudioFeatures } from './studio-features.mjs';
import { readClaudeExport, scanCliHistory } from './history-import.mjs';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(ROOT, 'public');
const DATA = process.env.CS_DATA || path.join(ROOT, 'data');
const UPLOADS = path.join(DATA, 'uploads');
const DB_FILE = path.join(DATA, 'sessions.json');
const PORT = Number(process.env.PORT || 4777);
const IS_WIN = process.platform === 'win32';
const official = createOfficialAccount({ dataDir: DATA, onChange: account => emit(null, { type: 'account', account }) });

fs.mkdirSync(UPLOADS, { recursive: true });

// ---------- 持久化 ----------
let db = { sessions: {} };
try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch {}
db.projects ||= {};
let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    fs.writeFileSync(DB_FILE + '.tmp', JSON.stringify(db));
    fs.renameSync(DB_FILE + '.tmp', DB_FILE);
  }, 300);
}

// 用量：input / output / cache read / cache write / 费用
function emptyUsage() { return { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, cost: 0, turns: 0 }; }
function addUsage(acc, m) {
  const u = m.usage;
  if (!u && !m.cost) return acc;
  acc.input += u?.input_tokens || 0;
  acc.output += u?.output_tokens || 0;
  acc.cacheRead += u?.cache_read_input_tokens || 0;
  acc.cacheWrite += u?.cache_creation_input_tokens || 0;
  acc.cost += m.cost || 0;
  acc.turns++;
  return acc;
}
function sessionUsage(s) {
  return s.messages.filter(m => m.role === 'assistant').reduce(addUsage, emptyUsage());
}

function summary(s) {
  return { id: s.id, title: s.title, pinned: !!s.pinned, cwd: s.cwd, contextDirs: s.contextDirs || [], memoryEnabled: s.memoryEnabled !== false, updatedAt: s.updatedAt, createdAt: s.createdAt, busy: !!procs.get(s.id)?.busy, usage: sessionUsage(s), scheduledTaskId: s.scheduledTaskId || null, historySource: s.historySource || 'studio', historySourceId: s.historySourceId || null, historyUrl: s.historyUrl || null };
}

// 合并 CLI result.usage（插话时一轮会有多个 result）
function mergeUsage(a, b) {
  if (!b) return a;
  if (!a) return { ...b };
  const out = { ...a };
  for (const k of ['input_tokens', 'output_tokens', 'cache_read_input_tokens', 'cache_creation_input_tokens']) out[k] = (a[k] || 0) + (b[k] || 0);
  return out;
}

function touchProject(cwd, at = Date.now()) {
  if (!cwd) return;
  const key = path.resolve(cwd).toLowerCase();
  const p = db.projects[key] ||= { path: path.resolve(cwd), name: path.basename(cwd) || cwd, createdAt: at };
  p.lastUsed = Math.max(p.lastUsed || 0, at);
}
// 旧数据：从已有会话回填最近项目
for (const s of Object.values(db.sessions)) touchProject(s.cwd, s.updatedAt || s.createdAt);

function projectList() {
  const counts = {};
  for (const s of Object.values(db.sessions)) if (s.cwd) { const k = path.resolve(s.cwd).toLowerCase(); counts[k] = (counts[k] || 0) + 1; }
  return Object.entries(db.projects)
    .map(([k, p]) => ({ ...p, sessions: counts[k] || 0, exists: fs.existsSync(p.path) }))
    .sort((a, b) => b.lastUsed - a.lastUsed);
}

function globalStats() {
  const total = emptyUsage();
  const byDay = {}, byModel = {};
  let sessions = 0, messages = 0;
  for (const s of Object.values(db.sessions)) {
    sessions++;
    for (const m of s.messages) {
      messages++;
      if (m.role !== 'assistant') continue;
      addUsage(total, m);
      const d = new Date(m.startedAt || s.createdAt);
      const day = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      addUsage(byDay[day] ||= emptyUsage(), m);
      addUsage(byModel[m.model || 'default'] ||= emptyUsage(), m);
    }
  }
  const denom = total.input + total.cacheRead + total.cacheWrite;
  return { total, hitRate: denom ? total.cacheRead / denom : 0, byDay, byModel, sessions, messages };
}

// ---------- SSE 广播 ----------
const clients = new Set();
function emit(sessionId, ev) {
  const line = `data: ${JSON.stringify({ sessionId, at: Date.now(), ...ev })}\n\n`;
  for (const res of clients) res.write(line);
}

// ---------- Claude 进程管理 ----------
const procs = new Map(); // sessionId -> { child, key, busy, pending: Map, turn }
const features = createStudioFeatures({ dataDir: DATA, getSessions: () => Object.values(db.sessions).map(summary),
  onChange: () => emit(null, { type: 'studio' }),
  onScheduleRun: async schedule => {
    if (!(await official.status(true)).ready) throw new Error('请先在设置中登录官方 Claude 订阅账号。');
    const s = { id: crypto.randomUUID(), title: schedule.name, cwd: schedule.cwd, scheduledTaskId: schedule.id, createdAt: Date.now(), updatedAt: Date.now(), messages: [], claudeSessionId: null };
    db.sessions[s.id] = s; touchProject(s.cwd); save();
    beginMessage(s, { text: schedule.prompt, model: schedule.model || 'sonnet', effort: 'medium', permissionMode: 'default' });
    return { sessionId: s.id };
  } });

const DEFAULT_PROMPT = 'Follow the language and style of the user request. Explain relevant tool actions briefly before using tools.';

function buildArgs(s, opts) {
  const args = ['-p', '--input-format', 'stream-json', '--output-format', 'stream-json',
    '--verbose', '--include-partial-messages', '--permission-prompt-tool', 'stdio', '--replay-user-messages'];
  if (opts.model) args.push('--model', opts.model);
  if (opts.effort) args.push('--effort', opts.effort);
  if (opts.permissionMode === 'bypassPermissions') args.push('--dangerously-skip-permissions');
  else if (opts.permissionMode) args.push('--permission-mode', opts.permissionMode);
  if (s.claudeSessionId && s.claudeProvider === 'official') args.push('--resume', s.claudeSessionId);
  args.push(...official.settingsArgs);
  args.push('--append-system-prompt', features.getSystemPrompt(s.cwd, { useMemory: s.memoryEnabled !== false }) || DEFAULT_PROMPT);
  for (const dir of s.contextDirs || []) args.push('--add-dir', dir);
  const mcpServers = features.getMcpConfig?.() || {};
  if (Object.keys(mcpServers).length) args.push('--mcp-config', JSON.stringify({ mcpServers }), '--strict-mcp-config');
  if (features.getChromeEnabled()) args.push('--chrome');
  return args;
}

function ensureProc(s, opts) {
  const key = [opts.model, opts.effort, opts.permissionMode, s.cwd, s.memoryEnabled !== false, JSON.stringify(s.contextDirs || []), features.getRevision?.() || features.getSystemPrompt(s.cwd)].join('|');
  const existing = procs.get(s.id);
  if (existing && existing.key === key && existing.child.exitCode === null) return existing;
  if (existing) killProc(s.id);

  const args = buildArgs(s, opts);
  const child = spawn(official.executable(), args, {
    cwd: s.cwd, env: { ...official.env(), CLAUDE_CODE_ENTRYPOINT: 'claude-studio' },
    windowsHide: true,
  });
  // costBase：result.total_cost_usd 是进程级累计值，按差值算每轮费用
  // sent / acked：写入 stdin 的用户消息数 / CLI 回显（--replay-user-messages）确认已消费的数，用于判断插话是否还有下一轮
  const p = { child, key, busy: false, pending: new Map(), turn: null, buf: '', stderr: '', costBase: 0, sent: 0, acked: 0, replaySeen: false };
  procs.set(s.id, p);

  child.stdout.setEncoding('utf8');
  child.stdout.on('data', chunk => {
    p.buf += chunk;
    let i;
    while ((i = p.buf.indexOf('\n')) >= 0) {
      const line = p.buf.slice(0, i).trim();
      p.buf = p.buf.slice(i + 1);
      if (!line) continue;
      let msg;
      try { msg = JSON.parse(line); } catch { continue; }
      try { handleMessage(s, p, msg); } catch (e) { console.error('handle error', e); }
    }
  });
  child.stderr.setEncoding('utf8');
  child.stderr.on('data', d => { p.stderr = (p.stderr + d).slice(-4000); });
  child.on('exit', code => {
    if (procs.get(s.id) === p) procs.delete(s.id);
    if (p.busy) {
      finishTurn(s, p, { error: code ? `Claude 进程异常退出 (code ${code})\n${p.stderr.trim()}` : null });
    }
  });
  child.on('error', err => {
    if (p.busy) finishTurn(s, p, { error: '无法启动 claude：' + err.message });
  });
  return p;
}

function killProc(id) {
  const p = procs.get(id);
  if (!p) return;
  procs.delete(id);
  try {
    if (IS_WIN) execSync(`taskkill /pid ${p.child.pid} /T /F`, { stdio: 'ignore' });
    else p.child.kill('SIGTERM');
  } catch {}
}

function send(p, obj) {
  if (p.child.stdin.writable) p.child.stdin.write(JSON.stringify(obj) + '\n');
}

// 当前轮次的 assistant 消息
function curMsg(s) {
  const m = s.messages[s.messages.length - 1];
  return m && m.role === 'assistant' ? m : null;
}

function toolResultText(content) {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) return content.map(c => c.type === 'text' ? c.text : c.type === 'image' ? '[图片]' : '').join('\n');
  return JSON.stringify(content);
}

function handleMessage(s, p, msg) {
  if (msg.type === 'rate_limit_event') { official.acceptRateLimit(msg.rate_limit_info); return; }
  const m = curMsg(s);
  const t = p.turn;
  if (msg.type === 'system' && msg.subtype === 'init') {
    if (msg.session_id) { s.claudeSessionId = msg.session_id; s.claudeProvider = 'official'; save(); }
    if (m) m.model = msg.model || m.model;
    emit(s.id, { type: 'init', model: msg.model, tools: msg.tools?.length });
    return;
  }
  if (msg.type === 'user' && msg.isReplay) { p.acked++; p.replaySeen = true; return; }
  if (!m || !t) {
    if (msg.type === 'control_request') handleControl(s, p, msg);
    return;
  }
  // 子代理的消息只统计，不展开
  if (msg.parent_tool_use_id) {
    if (msg.type === 'stream_event') return;
    return;
  }

  if (msg.type === 'stream_event') {
    const e = msg.event;
    if (e.type === 'message_start') {
      t.indexMap = {};
      if (e.message?.model) { m.model = e.message.model; emit(s.id, { type: 'model', model: m.model }); }
    } else if (e.type === 'content_block_start') {
      const cb = e.content_block;
      let block;
      if (cb.type === 'thinking' || cb.type === 'redacted_thinking') block = { type: 'thinking', text: '', startedAt: Date.now() };
      else if (cb.type === 'text') block = { type: 'text', text: '' };
      else if (cb.type === 'tool_use' || cb.type === 'server_tool_use') block = { type: 'tool', id: cb.id, name: cb.name, input: null, inputJson: '', status: 'running', startedAt: Date.now() };
      else return;
      m.blocks.push(block);
      t.indexMap[e.index] = m.blocks.length - 1;
      emit(s.id, { type: 'block_start', index: m.blocks.length - 1, block });
    } else if (e.type === 'content_block_delta') {
      const bi = t.indexMap[e.index];
      const b = m.blocks[bi];
      if (!b) return;
      const d = e.delta;
      if (d.type === 'text_delta') { b.text += d.text; emit(s.id, { type: 'delta', index: bi, text: d.text }); }
      else if (d.type === 'thinking_delta' && d.thinking) { b.text += d.thinking; emit(s.id, { type: 'delta', index: bi, text: d.thinking }); }
      else if (d.type === 'input_json_delta') { b.inputJson += d.partial_json; }
    } else if (e.type === 'content_block_stop') {
      const bi = t.indexMap[e.index];
      const b = m.blocks[bi];
      if (b?.type === 'thinking') {
        b.durationMs = Date.now() - b.startedAt;
        emit(s.id, { type: 'block_stop', index: bi, durationMs: b.durationMs });
      }
      if (b?.type === 'tool' && b.inputJson) {
        try { b.input = JSON.parse(b.inputJson); emit(s.id, { type: 'tool_input', id: b.id, input: b.input }); } catch {}
      }
    } else if (e.type === 'message_delta' && e.usage) {
      const th = e.usage.output_tokens_details?.thinking_tokens;
      if (th) { m.thinkingTokens = (m.thinkingTokens || 0) + th; emit(s.id, { type: 'thinking_tokens', value: m.thinkingTokens }); }
    }
    return;
  }

  if (msg.type === 'assistant') {
    for (const c of msg.message?.content || []) {
      if (c.type === 'tool_use') {
        const b = m.blocks.find(x => x.type === 'tool' && x.id === c.id);
        if (b && !b.input) { b.input = c.input; emit(s.id, { type: 'tool_input', id: b.id, input: b.input }); }
      }
    }
    return;
  }

  if (msg.type === 'user') {
    const content = msg.message?.content;
    if (!Array.isArray(content)) return;
    for (const c of content) {
      if (c.type !== 'tool_result') continue;
      const b = m.blocks.find(x => x.type === 'tool' && x.id === c.tool_use_id);
      if (!b) continue;
      let text = toolResultText(c.content);
      if (text.length > 30000) text = text.slice(0, 30000) + '\n…(已截断)';
      b.result = text;
      b.status = c.is_error ? 'error' : 'done';
      b.endedAt = Date.now();
      emit(s.id, { type: 'tool_result', id: b.id, result: text, status: b.status, endedAt: b.endedAt });
    }
    return;
  }

  if (msg.type === 'control_request') { handleControl(s, p, msg); return; }

  if (msg.type === 'result') {
    if (typeof msg.total_cost_usd === 'number') {
      t.cost = (t.cost || 0) + Math.max(0, msg.total_cost_usd - p.costBase);
      p.costBase = msg.total_cost_usd;
    }
    t.usage = mergeUsage(t.usage, msg.usage);
    // 插话：CLI 在工具调用间隙到达的消息会并入当前回合（只出一个 result）；
    // 回合结束后才到达的会排成下一回合。以回显计数判断：还有未被消费的消息就不结束本轮
    const outstanding = p.sent - p.acked;
    if (outstanding > 0 && p.replaySeen && !msg.is_error) {
      emit(s.id, { type: 'turn_progress', cost: t.cost, usage: t.usage, queued: outstanding });
      return;
    }
    finishTurn(s, p, {
      cost: t.cost, usage: t.usage, durationMs: Date.now() - m.startedAt,
      error: msg.is_error ? (msg.result || msg.subtype || '出错了') : null,
    });
  }
}

function handleControl(s, p, msg) {
  const r = msg.request;
  if (r?.subtype !== 'can_use_tool') {
    send(p, { type: 'control_response', response: { subtype: 'success', request_id: msg.request_id, response: {} } });
    return;
  }
  const perm = { requestId: msg.request_id, tool: r.tool_name, input: r.input, description: r.description || '', suggestions: r.permission_suggestions || null, toolUseId: r.tool_use_id };
  p.pending.set(msg.request_id, perm);
  const m = curMsg(s);
  if (m) m.pendingPermission = perm;
  emit(s.id, { type: 'permission', ...perm });
}

function finishTurn(s, p, info) {
  const m = curMsg(s);
  const t = p.turn;
  p.busy = false;
  p.turn = null;
  if (m) {
    m.done = true;
    m.cost = info.cost ?? t?.cost;
    m.usage = info.usage ?? t?.usage;
    m.durationMs = info.durationMs ?? (Date.now() - m.startedAt);
    delete m.pendingPermission;
    for (const b of m.blocks) {
      if (b.type === 'tool' && b.status === 'running') { b.status = info.error ? 'error' : 'done'; b.endedAt ||= Date.now(); }
      if (b.type === 'thinking' && b.durationMs == null) b.durationMs = Date.now() - b.startedAt;
    }
    if (info.error) m.error = info.error;
  }
  s.updatedAt = Date.now();
  save();
  emit(s.id, { type: 'turn_end', cost: m?.cost, usage: m?.usage, durationMs: m?.durationMs, error: info.error || null, session: summary(s) });
  if (s.scheduledTaskId) void features.recordScheduleResult(s.scheduledTaskId, s.id, info.error || null);
}

// ---------- 附件 ----------
const IMAGE_TYPES = new Set(['image/png', 'image/jpeg', 'image/gif', 'image/webp']);

function saveAttachments(s, attachments) {
  const dir = path.join(UPLOADS, s.id);
  fs.mkdirSync(dir, { recursive: true });
  return (attachments || []).map(a => {
    const safe = a.name.replace(/[\\/:*?"<>|]/g, '_').slice(-120) || 'file';
    const fname = `${Date.now().toString(36)}-${crypto.randomBytes(3).toString('hex')}-${safe}`;
    const abs = path.join(dir, fname);
    const buf = Buffer.from(a.data, 'base64');
    fs.writeFileSync(abs, buf);
    return { name: a.name, type: a.type, size: buf.length, abs, url: `/uploads/${s.id}/${encodeURIComponent(fname)}`, isImage: IMAGE_TYPES.has(a.type), data: a.data };
  });
}

function buildUserContent(text, files) {
  const content = [];
  const others = [];
  for (const f of files) {
    if (f.isImage && f.size < 5 * 1024 * 1024) content.push({ type: 'image', source: { type: 'base64', media_type: f.type, data: f.data } });
    else others.push(f);
  }
  let full = text || '';
  if (others.length) {
    full += `\n\n[用户上传了 ${others.length} 个附件，已保存到本地，请按需读取]\n` + others.map(f => `- ${f.name}: ${f.abs}`).join('\n');
  }
  if (!full.trim()) full = '请查看我发送的图片。';
  content.push({ type: 'text', text: full });
  return content;
}

// ---------- HTTP ----------
function validateContextDirs(value) {
  try {
    if (!Array.isArray(value) || value.length > 10 || value.some(p => typeof p !== 'string' || !p.trim())) throw new Error('上下文目录最多添加 10 个有效文件夹。');
    return [...new Set(value.map(p => {
      const resolved = path.resolve(p);
      if (!fs.statSync(resolved).isDirectory()) throw new Error('上下文路径必须是文件夹：' + p);
      return resolved;
    }))];
  } catch { throw Object.assign(new Error('上下文目录无效，请选择最多 10 个存在的文件夹。'), { statusCode: 400 }); }
}
function copyBranchAttachments(source, branch) {
  const copied = new Map();
  const copy = attachment => {
    if (!attachment.url?.startsWith(`/uploads/${source.id}/`)) return;
    let filename; try { filename = decodeURIComponent(attachment.url.split('/').at(-1)); } catch { return; }
    if (!filename || filename !== path.basename(filename)) return;
    const original = path.join(UPLOADS, source.id, filename), target = path.join(UPLOADS, branch.id, filename);
    if (!fs.existsSync(original)) return;
    if (!copied.has(filename)) { fs.mkdirSync(path.dirname(target), { recursive: true }); fs.copyFileSync(original, target); copied.set(filename, true); }
    attachment.url = `/uploads/${branch.id}/${encodeURIComponent(filename)}`;
  };
  for (const message of branch.messages) {
    for (const attachment of message.attachments || []) copy(attachment);
    for (const block of message.blocks || []) for (const attachment of block.attachments || []) copy(attachment);
  }
}
function historyReference(s) {
  if (s.claudeProvider === 'official' || !s.messages.length) return '';
  const history = s.messages.filter(m => m.role === 'user' || m.role === 'assistant').slice(-24)
    .map(m => {
      const attachments = (m.attachments || []).map(a => {
        if (!a.url?.startsWith('/uploads/')) return '';
        try {
          const parts = a.url.split('/');
          const sessionId = parts[2], filename = decodeURIComponent(parts[3] || '');
          if (!/^[\w-]+$/.test(sessionId) || filename !== path.basename(filename)) return '';
          const file = path.join(UPLOADS, sessionId, filename);
          return fs.existsSync(file) ? `[历史附件 ${a.name}: ${file}]` : '';
        } catch { return ''; }
      }).filter(Boolean).join('\n');
      return `${m.role}: ${m.text || (m.blocks || []).filter(b => b.type === 'text').map(b => b.text || '').join('\n')}${attachments ? '\n' + attachments : ''}`;
    }).join('\n\n').slice(-30000);
  return history.trim() ? `[以下是本地保存的历史对话，供本轮续接参考]\n${history}\n[历史参考结束]\n\n` : '';
}
function mergeHistory(records) {
  const result = { imported: 0, updated: 0, unchanged: 0, skippedBusy: 0, sessions: [] };
  for (const record of records) {
    let existing = Object.values(db.sessions).find(s => s.historySource === record.historySource && s.historySourceId === record.historySourceId);
    if (!existing && record.historySource === 'claude-code') {
      // Studio already owns these CLI sessions; importing a second copy would duplicate them.
      if (Object.values(db.sessions).some(s => s.claudeSessionId === record.historySourceId)) { result.unchanged++; continue; }
    }
    if (existing && procs.get(existing.id)?.busy) { result.skippedBusy++; continue; }
    const snapshotHash = crypto.createHash('sha256').update(JSON.stringify({ title: record.title, messages: record.messages })).digest('hex');
    if (existing?.historySnapshotHash === snapshotHash) { result.unchanged++; continue; }
    if (existing) {
      const continuation = existing.messages.filter(m => !m.importedMessage);
      killProc(existing.id);
      existing.messages = [...record.messages, ...continuation]; existing.historySnapshotHash = snapshotHash;
      if (existing.title === existing.historyOriginalTitle) existing.title = record.title;
      existing.historyOriginalTitle = record.title;
      existing.updatedAt = Math.max(existing.updatedAt, record.updatedAt); existing.historyUrl = record.historyUrl || existing.historyUrl;
      existing.claudeSessionId = null; existing.claudeProvider = null; result.updated++;
    } else {
      let cwd = record.cwd || os.homedir(); try { if (!fs.statSync(cwd).isDirectory()) cwd = os.homedir(); } catch { cwd = os.homedir(); }
      existing = { ...record, id: crypto.randomUUID(), cwd, contextDirs: [], claudeSessionId: null, claudeProvider: null, historyOriginalTitle: record.title, historySnapshotHash: snapshotHash };
      db.sessions[existing.id] = existing; touchProject(cwd, record.updatedAt); result.imported++;
    }
    result.sessions.push(summary(existing)); emit(existing.id, { type: 'session', session: summary(existing) });
  }
  if (result.imported || result.updated) save();
  return result;
}
let historySync = null;
async function syncCliHistory() {
  if (historySync) return historySync;
  historySync = (async () => { const scan = await scanCliHistory([path.join(os.homedir(), '.claude', 'projects'), path.join(official.configDir, 'projects')]); return { ...mergeHistory(scan.sessions), scanned: scan.scanned, errors: scan.errors }; })();
  try { return await historySync; } finally { historySync = null; }
}
function beginMessage(s, body) {
  const reference = historyReference(s);
  const files = saveAttachments(s, body.attachments);
  const userMsg = { role: 'user', text: body.text || '', attachments: files.map(({ data, abs, ...f }) => f), at: Date.now() };
  s.messages.push(userMsg);
  if (s.title === '新对话') s.title = (body.text || files[0]?.name || '新对话').replace(/\s+/g, ' ').slice(0, 40);
  const asst = { role: 'assistant', blocks: [], startedAt: Date.now(), model: body.model, effort: body.effort, done: false };
  s.messages.push(asst); s.updatedAt = Date.now(); touchProject(s.cwd); save();
  const p = ensureProc(s, { model: body.model, effort: body.effort, permissionMode: body.permissionMode });
  p.busy = true; p.turn = { indexMap: {} }; p.sent++;
  send(p, { type: 'user', message: { role: 'user', content: buildUserContent(reference + (body.text || ''), files) } });
  emit(s.id, { type: 'turn_start', user: userMsg, assistant: asst, session: summary(s) });
  return s;
}
function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', c => { size += c.length; if (size > 200 * 1024 * 1024) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.ico': 'image/x-icon', '.json': 'application/json', '.pdf': 'application/pdf', '.mp4': 'video/mp4', '.webm': 'video/webm', '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.txt': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' };

function serveFile(res, file) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); res.end('not found'); return; }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    fs.createReadStream(file).pipe(res);
  });
}

function listDirs(p) {
  if (!p) {
    if (IS_WIN) {
      const drives = [];
      for (const l of 'CDEFGHIJ') { try { fs.accessSync(l + ':\\'); drives.push({ name: l + ':', path: l + ':\\' }); } catch {} }
      return { path: '', parent: null, dirs: drives };
    }
    p = '/';
  }
  const abs = path.resolve(p);
  const dirs = fs.readdirSync(abs, { withFileTypes: true })
    .filter(d => d.isDirectory() && !d.name.startsWith('.') && !d.name.startsWith('$'))
    .map(d => ({ name: d.name, path: path.join(abs, d.name) }))
    .sort((a, b) => a.name.localeCompare(b.name));
  const parent = path.dirname(abs);
  return { path: abs, parent: parent === abs ? (IS_WIN ? '' : null) : parent, dirs };
}

// ---------- Shell 任务 ----------
const jobs = new Map(); // id -> job
const JOB_OUTPUT_MAX = 256 * 1024;
function jobSummary(j) {
  return { id: j.id, cmd: j.cmd, cwd: j.cwd, shell: j.shell, sessionId: j.sessionId, startedAt: j.startedAt, endedAt: j.endedAt || null, code: j.code ?? null, running: !j.endedAt, size: j.size };
}
function shellSpawn(cmd, shell) {
  if (IS_WIN) {
    if (shell === 'cmd') return ['cmd.exe', ['/d', '/s', '/c', cmd]];
    // 用临时 .ps1 + -File：-EncodedCommand 在输出重定向时会把进度/错误写成 CLIXML
    const file = path.join(os.tmpdir(), `cs-job-${crypto.randomBytes(6).toString('hex')}.ps1`);
    fs.writeFileSync(file, '\ufeff' + `$ProgressPreference='SilentlyContinue'\n[Console]::OutputEncoding=[Text.Encoding]::UTF8\n$OutputEncoding=[Text.Encoding]::UTF8\n${cmd}\n`);
    return ['powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file], file];
  }
  return [process.env.SHELL || '/bin/sh', ['-c', cmd]];
}
function startJob({ cmd, cwd, shell, sessionId }) {
  shell ||= IS_WIN ? 'powershell' : 'sh';
  const [bin, args, tmpFile] = shellSpawn(cmd, shell);
  const j = { id: crypto.randomBytes(6).toString('hex'), cmd, cwd, shell, sessionId: sessionId || null, startedAt: Date.now(), output: '', size: 0 };
  const child = spawn(bin, args, { cwd, windowsHide: true, env: { ...process.env, FORCE_COLOR: '0' } });
  j.child = child;
  jobs.set(j.id, j);
  // 最多保留 50 个任务
  for (const [id, old] of jobs) { if (jobs.size <= 50) break; if (old.endedAt) jobs.delete(id); }
  // cmd 内建命令按系统代码页（中文 Windows 为 GBK）输出，其它程序多为 UTF-8：每块先按 UTF-8 严格解码，失败再用 GBK
  const decoders = {};
  const decode = (stream, d) => {
    const dec = decoders[stream] ||= { utf8: new TextDecoder('utf-8', { fatal: true }), gbk: IS_WIN ? new TextDecoder('gbk') : null };
    if (!dec.gbk) return d.toString('utf8');
    try { return dec.utf8.decode(d, { stream: true }); } catch { dec.utf8 = new TextDecoder('utf-8', { fatal: true }); return dec.gbk.decode(d, { stream: true }); }
  };
  const onData = stream => d => {
    const text = decode(stream, d);
    j.size += text.length;
    j.output = (j.output + text).slice(-JOB_OUTPUT_MAX);
    emit(null, { type: 'job_output', id: j.id, stream, data: text });
  };
  child.stdout.on('data', onData('stdout'));
  child.stderr.on('data', onData('stderr'));
  const end = (code, err) => {
    if (j.endedAt) return;
    j.endedAt = Date.now(); j.code = code; delete j.child;
    if (tmpFile) fs.rm(tmpFile, { force: true }, () => {});
    if (err) j.output += `\n[启动失败] ${err}`;
    emit(null, { type: 'job', job: jobSummary(j) });
  };
  child.on('exit', code => end(code));
  child.on('error', e => end(-1, e.message));
  emit(null, { type: 'job', job: jobSummary(j) });
  return j;
}
function killJob(j) {
  if (!j.child) return;
  try {
    if (IS_WIN) execSync(`taskkill /pid ${j.child.pid} /T /F`, { stdio: 'ignore' });
    else j.child.kill('SIGTERM');
  } catch {}
}

// ---------- 文件区 ----------
const TEXT_MAX = 512 * 1024;
const IMAGE_EXT = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.ico', '.bmp']);
function listEntries(p) {
  const abs = path.resolve(p);
  const entries = [];
  for (const d of fs.readdirSync(abs, { withFileTypes: true })) {
    const full = path.join(abs, d.name);
    let st = null;
    try { st = fs.statSync(full); } catch {}
    const dir = st ? st.isDirectory() : d.isDirectory();
    entries.push({ name: d.name, path: full, dir, size: dir ? null : st?.size ?? null, mtime: st?.mtimeMs ?? null, hidden: d.name.startsWith('.') || d.name.startsWith('$') });
  }
  entries.sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name));
  const parent = path.dirname(abs);
  return { path: abs, parent: parent === abs ? null : parent, entries };
}
function readFilePreview(p) {
  const abs = path.resolve(p);
  const st = fs.statSync(abs);
  if (!st.isFile()) return { error: '不是文件' };
  const ext = path.extname(abs).toLowerCase();
  const base = { path: abs, name: path.basename(abs), size: st.size, mtime: st.mtimeMs, ext };
  if (IMAGE_EXT.has(ext)) return { ...base, image: true };
  if (st.size > TEXT_MAX) return { ...base, tooLarge: true };
  const buf = fs.readFileSync(abs);
  if (buf.subarray(0, 8192).includes(0)) return { ...base, binary: true };
  return { ...base, text: buf.toString('utf8') };
}

// ---------- 原生选目录 ----------
function runCapture(bin, args, timeout = 10 * 60 * 1000) {
  return new Promise(resolve => {
    const c = spawn(bin, args, { windowsHide: false });
    let out = '', err = '';
    c.stdout.on('data', d => out += d);
    c.stderr.on('data', d => err += d);
    const timer = setTimeout(() => c.kill(), timeout);
    c.on('exit', code => { clearTimeout(timer); resolve({ code, out: out.trim(), err: err.trim() }); });
    c.on('error', e => { clearTimeout(timer); resolve({ code: -1, out: '', err: e.message }); });
  });
}
async function pickDir(initial) {
  if (IS_WIN) {
    const init = (initial || '').replace(/'/g, "''");
    const ps = `[Console]::OutputEncoding=[Text.Encoding]::UTF8
Add-Type -AssemblyName System.Windows.Forms
$d = New-Object System.Windows.Forms.FolderBrowserDialog
$d.Description = '选择工作目录'
$d.ShowNewFolderButton = $true
if ('${init}' -and (Test-Path -LiteralPath '${init}')) { $d.SelectedPath = '${init}' }
$f = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true; ShowInTaskbar = $false }
if ($d.ShowDialog($f) -eq 'OK') { $d.SelectedPath }`;
    const r = await runCapture('powershell.exe', ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(ps, 'utf16le').toString('base64')]);
    if (r.code !== 0) return { error: r.err || `powershell exit ${r.code}` };
    return r.out ? { path: r.out } : { cancelled: true };
  }
  if (process.platform === 'darwin') {
    const r = await runCapture('osascript', ['-e', 'POSIX path of (choose folder with prompt "选择工作目录")']);
    if (r.code !== 0) return /-128/.test(r.err) ? { cancelled: true } : { error: r.err };
    return { path: r.out.replace(/\/$/, '') || '/' };
  }
  return { unsupported: true };
}

// ---------- CLI 信息 ----------
let cliInfo = null;
async function getCliInfo(refresh) {
  if (cliInfo && !refresh) return cliInfo;
  const v = await runCapture(IS_WIN ? 'cmd.exe' : 'sh', IS_WIN ? ['/d', '/c', 'claude --version'] : ['-c', 'claude --version'], 20000);
  const w = await runCapture(IS_WIN ? 'where.exe' : 'sh', IS_WIN ? ['claude'] : ['-c', 'command -v claude'], 10000);
  cliInfo = {
    ok: v.code === 0, version: v.out || null, error: v.code === 0 ? null : (v.err || '未找到 claude'),
    paths: w.out ? w.out.split(/\r?\n/).filter(Boolean) : [],
    node: process.version, platform: process.platform, data: DATA, port: PORT, checkedAt: Date.now(),
  };
  return cliInfo;
}

// 仅允许本机同源访问：防止网页跨域 POST / DNS rebinding 触发执行
function allowedRequest(req) {
  const host = (req.headers.host || '').toLowerCase();
  if (host && !/^(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/.test(host)) return false;
  const origin = req.headers.origin;
  if (origin === 'null' && !['GET', 'HEAD'].includes(req.method)) return false;
  if (origin && origin !== 'null') {
    try {
      const o = new URL(origin);
      const local = ['127.0.0.1', 'localhost', '[::1]'].includes(o.hostname) && (o.port || '80') === String(PORT);
      if (!local && !/^(tauri:|https?:\/\/tauri\.localhost$)/.test(origin)) return false;
    } catch { return false; }
  }
  return true;
}

const server = http.createServer(async (req, res) => {
  if (!allowedRequest(req)) { res.writeHead(403); return res.end('forbidden'); }
  const url = new URL(req.url, 'http://localhost');
  const parts = url.pathname.split('/').filter(Boolean);
  try {
    if (url.pathname === '/api/history' && req.method === 'GET') {
      const records = Object.values(db.sessions).filter(s => s.historySource).map(summary).sort((a, b) => b.updatedAt - a.updatedAt);
      return json(res, 200, { sessions: records, counts: { official: records.filter(s => s.historySource === 'claude-web').length, cli: records.filter(s => s.historySource === 'claude-code').length }, exportUrl: 'https://claude.ai/settings/privacy', guideUrl: 'https://support.claude.com/en/articles/9450526-export-your-claude-data' });
    }
    if (url.pathname === '/api/history/import' && req.method === 'POST') {
      const body = await readBody(req);
      let records; try { records = await readClaudeExport(body); } catch (e) { return json(res, 400, { error: e.message }); }
      return json(res, 200, mergeHistory(records));
    }
    if (url.pathname === '/api/history/sync-cli' && req.method === 'POST') return json(res, 200, await syncCliHistory());
    if (parts[0] === 'api' && parts[1] === 'preview' && req.method === 'GET') {
      const directory = path.resolve(decodeURIComponent(parts[2] || ''));
      const relative = parts.slice(3).map(decodeURIComponent).join(path.sep);
      const target = path.resolve(directory, relative || 'index.html');
      const realDirectory = fs.realpathSync(directory);
      const realTarget = fs.realpathSync(target);
      const within = path.relative(realDirectory, realTarget);
      if (within.startsWith('..') || path.isAbsolute(within)) return json(res, 403, { error: '成果资源超出了预览文件夹。' });
      res.setHeader('Content-Security-Policy', "sandbox allow-scripts; default-src 'self' data: blob: https:; style-src 'self' 'unsafe-inline' https:; script-src 'self' 'unsafe-inline' https:; connect-src https:; frame-src 'none'; object-src 'none'; form-action 'none'");
      return serveFile(res, realTarget);
    }
    if (url.pathname === '/api/studio/search' && req.method === 'GET') {
      const q = (url.searchParams.get('q') || '').trim().toLowerCase().slice(0, 200);
      const matches = Object.values(db.sessions).filter(s => !q || (s.title + '\n' + s.cwd).toLowerCase().includes(q) || s.messages.some(m => (m.text || (m.blocks || []).filter(b => b.type === 'text').map(b => b.text || '').join('\n')).toLowerCase().includes(q)));
      return json(res, 200, { sessions: matches.sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 100).map(summary) });
    }
    if (await features.handle(req, res, url, readBody, json)) return;
    if (url.pathname === '/api/events') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
      res.write('retry: 2000\n\n');
      clients.add(res);
      const ping = setInterval(() => res.write(': ping\n\n'), 20000);
      req.on('close', () => { clearInterval(ping); clients.delete(res); });
      return;
    }
    if (url.pathname === '/api/state' && req.method === 'GET') {
      const list = Object.values(db.sessions).map(summary).sort((a, b) => b.updatedAt - a.updatedAt);
      return json(res, 200, { sessions: list, projects: projectList(), home: os.homedir(), platform: process.platform });
    }
    if (url.pathname === '/api/fs' && req.method === 'GET') {
      return json(res, 200, listDirs(url.searchParams.get('path') || ''));
    }
    // 桌面壳用来识别"端口上是不是兼容版本的 Claude Studio 服务"
    if (url.pathname === '/api/ping') {
      return json(res, 200, { app: 'claude-studio', api: 2, pid: process.pid });
    }
    if (url.pathname === '/api/stats' && req.method === 'GET') {
      return json(res, 200, globalStats());
    }
    if (url.pathname === '/api/cli' && req.method === 'GET') {
      return json(res, 200, await getCliInfo(url.searchParams.has('refresh')));
    }
    if (url.pathname === '/api/account' && req.method === 'GET') {
      return json(res, 200, await official.getAccount(url.searchParams.has('refresh')));
    }
    if (url.pathname === '/api/account/login' && req.method === 'POST') {
      if ([...procs.values()].some(p => p.busy)) return json(res, 409, { error: '请先停止正在进行的对话，再切换官方账号。' });
      for (const id of procs.keys()) killProc(id);
      return json(res, 200, await official.startLogin());
    }
    if (url.pathname === '/api/account/login/code' && req.method === 'POST') {
      const body = await readBody(req);
      try { return json(res, 200, official.submitCode(body.code)); } catch (e) { return json(res, 400, { error: e.message }); }
    }
    if (url.pathname === '/api/account/logout' && req.method === 'POST') {
      if ([...procs.values()].some(p => p.busy)) return json(res, 409, { error: '请先停止正在进行的对话，再退出官方账号。' });
      for (const id of procs.keys()) killProc(id);
      return json(res, 200, await official.logout());
    }
    if (url.pathname === '/api/pick-dir' && req.method === 'POST') {
      const body = await readBody(req);
      return json(res, 200, await pickDir(body.initial));
    }
    if (url.pathname === '/api/files' && req.method === 'GET') {
      const p = url.searchParams.get('path');
      if (!p) return json(res, 400, { error: '缺少 path' });
      try { return json(res, 200, listEntries(p)); } catch (e) { return json(res, 400, { error: e.message }); }
    }
    if (url.pathname === '/api/file' && req.method === 'GET') {
      const p = url.searchParams.get('path');
      if (!p) return json(res, 400, { error: '缺少 path' });
      if (url.searchParams.has('raw')) {
        if (/\.(html?|svg)$/i.test(p)) res.setHeader('Content-Security-Policy', "sandbox allow-scripts; default-src 'self' data: blob: https:; style-src 'self' 'unsafe-inline' https:; script-src 'self' 'unsafe-inline' https:; connect-src https:; frame-src 'none'; object-src 'none'; form-action 'none'");
        return serveFile(res, path.resolve(p));
      }
      try { return json(res, 200, readFilePreview(p)); } catch (e) { return json(res, 400, { error: e.message }); }
    }
    if (url.pathname === '/api/shell' && req.method === 'POST') {
      const body = await readBody(req);
      if (!body.cmd?.trim()) return json(res, 400, { error: '命令为空' });
      const cwd = body.cwd || os.homedir();
      if (!fs.existsSync(cwd)) return json(res, 400, { error: '目录不存在：' + cwd });
      return json(res, 200, { job: jobSummary(startJob({ cmd: body.cmd, cwd, shell: body.shell, sessionId: body.sessionId })) });
    }
    if (parts[0] === 'api' && parts[1] === 'jobs') {
      if (!parts[2] && req.method === 'GET') {
        return json(res, 200, { jobs: [...jobs.values()].map(jobSummary).sort((a, b) => b.startedAt - a.startedAt) });
      }
      const j = jobs.get(parts[2]);
      if (!j) return json(res, 404, { error: '任务不存在' });
      if (!parts[3] && req.method === 'GET') return json(res, 200, { job: jobSummary(j), output: j.output });
      if (parts[3] === 'kill' && req.method === 'POST') { killJob(j); return json(res, 200, { ok: true }); }
      if (!parts[3] && req.method === 'DELETE') { killJob(j); jobs.delete(j.id); return json(res, 200, { ok: true }); }
    }
    if (parts[0] === 'api' && parts[1] === 'sessions') {
      const id = parts[2];
      if (!id && req.method === 'POST') {
        const body = await readBody(req);
        const s = { id: crypto.randomUUID(), title: '新对话', cwd: body.cwd || os.homedir(), contextDirs: body.contextDirs ? validateContextDirs(body.contextDirs) : [], createdAt: Date.now(), updatedAt: Date.now(), messages: [], claudeSessionId: null };
        db.sessions[s.id] = s; touchProject(s.cwd); save();
        return json(res, 200, { session: summary(s) });
      }
      const s = db.sessions[id];
      if (!s) return json(res, 404, { error: '会话不存在' });
      const action = parts[3];
      if (!action && req.method === 'GET') {
        return json(res, 200, { session: summary(s), messages: s.messages });
      }
      if (!action && req.method === 'PATCH') {
        const body = await readBody(req);
        const contextDirs = 'contextDirs' in body ? validateContextDirs(body.contextDirs) : null;
        if ('memoryEnabled' in body && typeof body.memoryEnabled !== 'boolean') return json(res, 400, { error: '记忆开关必须是布尔值。' });
        if (typeof body.cwd === 'string') {
          try { if (!fs.statSync(body.cwd).isDirectory()) throw new Error(); } catch { return json(res, 400, { error: '工作文件夹不存在。' }); }
        }
        if (procs.get(s.id)?.busy && (contextDirs || 'memoryEnabled' in body || (typeof body.cwd === 'string' && body.cwd !== s.cwd))) return json(res, 409, { error: '请先停止当前任务，再更改上下文设置。' });
        if (typeof body.title === 'string') s.title = body.title.slice(0, 100);
        if (typeof body.pinned === 'boolean') s.pinned = body.pinned;
        if (typeof body.cwd === 'string' && body.cwd !== s.cwd) { s.cwd = body.cwd; touchProject(s.cwd); killProc(s.id); }
        if (contextDirs) { s.contextDirs = contextDirs; killProc(s.id); }
        if ('memoryEnabled' in body) { s.memoryEnabled = body.memoryEnabled; killProc(s.id); }
        save();
        emit(s.id, { type: 'session', session: summary(s) });
        return json(res, 200, { session: summary(s) });
      }
      if (!action && req.method === 'DELETE') {
        killProc(s.id);
        delete db.sessions[id]; save();
        fs.rm(path.join(UPLOADS, id), { recursive: true, force: true }, () => {});
        return json(res, 200, { ok: true });
      }
      if (action === 'fork' && req.method === 'POST') {
        const body = await readBody(req);
        const until = Number.isInteger(body.messageIndex) ? body.messageIndex + 1 : s.messages.length;
        if (until < 0 || until > s.messages.length) return json(res, 400, { error: '分支消息位置无效。' });
        const branch = { ...s, id: crypto.randomUUID(), title: (body.title || s.title + ' · 分支').slice(0, 100), messages: structuredClone(s.messages.slice(0, until)), createdAt: Date.now(), updatedAt: Date.now(), pinned: false, claudeSessionId: null, claudeProvider: null, scheduledTaskId: null };
        for (const m of branch.messages) { if (m.role === 'assistant' && !m.done) { m.done = true; m.error = '从此处创建分支。'; } delete m.pendingPermission; }
        copyBranchAttachments(s, branch);
        db.sessions[branch.id] = branch; save(); emit(branch.id, { type: 'session', session: summary(branch) });
        return json(res, 201, { session: summary(branch), messages: branch.messages });
      }
      if (action === 'send' && req.method === 'POST') {
        const body = await readBody(req);
        const account = await official.status();
        if (!account.ready) return json(res, 401, { error: '请在「设置 → 官方账号与限额」登录 Claude Pro 账号后再发送消息。' });
        if (body.model && !['sonnet', 'opus', 'haiku'].includes(body.model)) return json(res, 400, { error: '请选择官方 Claude 模型。' });
        if ('contextDirs' in body) s.contextDirs = validateContextDirs(body.contextDirs);
        const existing = procs.get(s.id);
        if (existing?.busy) {
          if (!body.interject) return json(res, 409, { error: '上一条消息还在处理中' });
          // 插话：直接写入 stdin，CLI 会在当前回合后接着处理；记入当前 assistant 消息
          const files = saveAttachments(s, body.attachments);
          const m = curMsg(s);
          const block = { type: 'interject', text: body.text || '', attachments: files.map(({ data, abs, ...f }) => f), at: Date.now() };
          if (m) { m.blocks.push(block); emit(s.id, { type: 'block_start', index: m.blocks.length - 1, block }); }
          existing.sent++;
          if (existing.turn) existing.turn.interjects = (existing.turn.interjects || 0) + 1;
          send(existing, { type: 'user', message: { role: 'user', content: buildUserContent(body.text, files) } });
          s.updatedAt = Date.now(); save();
          return json(res, 200, { ok: true, interjected: true, queued: existing.sent - existing.acked });
        }
        beginMessage(s, body);
        return json(res, 200, { ok: true });
      }
      if (action === 'stop' && req.method === 'POST') {
        const p = procs.get(s.id);
        if (p?.busy && p.turn?.interjects && p.sent > p.acked) {
          // 有排队插话时 interrupt 只停当前回合，直接结束进程（下次 --resume 续上）
          killProc(s.id); finishTurn(s, p, { error: '已停止生成' });
        } else if (p?.busy) {
          send(p, { type: 'control_request', request_id: crypto.randomUUID(), request: { subtype: 'interrupt' } });
          setTimeout(() => { if (p.busy) { killProc(s.id); finishTurn(s, p, { error: '已停止生成' }); } }, 3000);
        }
        return json(res, 200, { ok: true });
      }
      if (action === 'permission' && req.method === 'POST') {
        const body = await readBody(req);
        const p = procs.get(s.id);
        const perm = p?.pending.get(body.requestId);
        if (!perm) return json(res, 404, { error: '请求已失效' });
        p.pending.delete(body.requestId);
        let response;
        if (body.allow) {
          response = { behavior: 'allow', updatedInput: body.updatedInput || perm.input };
          if (body.always && perm.suggestions) response.updatedPermissions = perm.suggestions;
        } else {
          response = { behavior: 'deny', message: body.message || '用户拒绝了这次操作' };
        }
        send(p, { type: 'control_response', response: { subtype: 'success', request_id: body.requestId, response } });
        const m = curMsg(s);
        if (m) delete m.pendingPermission;
        emit(s.id, { type: 'permission_done', requestId: body.requestId, allow: !!body.allow });
        return json(res, 200, { ok: true });
      }
    }
    if (parts[0] === 'uploads') {
      const file = path.join(UPLOADS, ...parts.slice(1).map(decodeURIComponent));
      if (!file.startsWith(UPLOADS)) { res.writeHead(403); return res.end(); }
      return serveFile(res, file);
    }
    const rel = url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname.slice(1));
    const file = path.join(PUBLIC, rel);
    if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
    serveFile(res, file);
  } catch (e) {
    console.error(e);
    json(res, e.statusCode || 500, { error: e.message });
  }
});

// 重启后，把上次未完成的轮次标记结束
for (const s of Object.values(db.sessions)) {
  const m = s.messages[s.messages.length - 1];
  if (m?.role === 'assistant' && !m.done) { m.done = true; m.error = m.error || '服务重启，本轮已中断'; delete m.pendingPermission; }
}

server.listen(PORT, '127.0.0.1', () => {
  features.start();
  // Tests use isolated CS_DATA; the real desktop automatically indexes its local CLI history.
  if (path.resolve(DATA).toLowerCase() === path.join(os.homedir(), '.claude-studio', 'data').toLowerCase()) void syncCliHistory().catch(e => console.error('history sync:', e.message));
  const url = `http://localhost:${PORT}`;
  console.log(`\n  ✦ Claude Studio 已启动：${url}\n`);
  if (process.argv.includes('--open')) {
    const cmd = IS_WIN ? `start "" "${url}"` : process.platform === 'darwin' ? `open ${url}` : `xdg-open ${url}`;
    try { execSync(cmd, { stdio: 'ignore' }); } catch {}
  }
});
process.on('exit', () => { official.close(); void features.close(); for (const id of procs.keys()) killProc(id); for (const j of jobs.values()) killJob(j); });
process.on('SIGINT', () => process.exit(0));
